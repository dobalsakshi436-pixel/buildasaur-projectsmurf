export interface User {
  id: string;
  name: string;
  emailOrPhone: string;
  passwordHash: string;
  role: 'resident' | 'admin';
  preferredLanguage: string;
  locality: string;
  age?: number;
  gender?: string;
  emergencyContact?: string;
  createdAt: string;
}

export interface HealthAdvisory {
  id: string;
  title: string;
  titleHi?: string;
  titleMr?: string;
  titleGu?: string;
  locality: string; // e.g. "All Mira Bhayandar", "Bhayandar West", "Mira Road", "Kashimira", "Naya Nagar", "Uttan"
  category: 'outbreak' | 'monsoon' | 'vaccination' | 'maternal' | 'elderly' | 'general';
  severity: 'urgent' | 'warning' | 'info';
  date: string;
  medicalText: string;
  simpleText: string; // Plain language 5th-grade explanation
  simpleTextHi?: string;
  simpleTextMr?: string;
  simpleTextGu?: string;
  symptoms: string[];
  precautions: string[];
  actionHelpline: string;
}

export interface VaccinationCamp {
  id: string;
  name: string;
  locality: string; // e.g. "Bhayandar West", "Mira Road", "Kashimira", "Naya Nagar", "Golden Nest", "Uttan"
  address: string;
  landmark: string;
  date: string;
  timeRange: string; // e.g. "09:00 AM - 02:00 PM"
  targetGroup: 'all' | 'elderly' | 'children' | 'pregnant_women';
  vaccinesOffered: string[]; // e.g. ["Pneumococcal", "Flu / Influenza", "COVID Booster", "Td / Tetanus", "MMR", "Polio"]
  totalSlots: number;
  availableSlots: number;
  contactNumber: string;
  googleMapsUrl: string;
  status: 'upcoming' | 'ongoing' | 'completed';
}

export interface HospitalAppointmentSlot {
  slotId: string;
  time: string; // e.g. "10:30 AM"
  date: string; // e.g. "2026-08-31"
  doctorName: string;
  specialty: string;
  isAvailable: boolean;
}

export interface Hospital {
  id: string;
  name: string;
  type: 'Municipal Hospital (MBMC)' | 'Community Health Center' | 'Maternity Home' | 'Trust Hospital' | 'Private Hospital';
  locality: string;
  address: string;
  landmark: string;
  latitude: number;
  longitude: number;
  contactNumber: string;
  emergencyNumber: string;
  specialties: string[];
  facilities: string[]; // e.g. "ICU", "24x7 Casualty", "Free OPD", "Ayushman Bharat", "Maternity Ward"
  opdTimings: string;
  isFreeGovt: boolean;
  appointmentSlots: HospitalAppointmentSlot[];
}

export interface MedicineStockItem {
  medicineId: string;
  name: string;
  genericName: string;
  category: string; // e.g. "Fever & Pain", "Antibiotic", "Diabetes", "Blood Pressure", "Antacid", "Allergy"
  status: 'In Stock' | 'Low Stock' | 'Out of Stock';
  price: string;
  discountGovt?: string;
}

export interface Pharmacy {
  id: string;
  name: string;
  locality: string;
  address: string;
  contactNumber: string;
  timings: string;
  is24Hours: boolean;
  hasJanAushadhiScheme: boolean;
  distanceKm: number;
  inventory: MedicineStockItem[];
}

export interface MedicineInfo {
  name: string;
  genericName: string;
  category: string;
  simplePurpose: string;
  dosageNotes: string;
  commonSideEffects: string[];
  precautions: string[];
  requiresDoctorPrescription: boolean;
  disclaimer: string;
}

export interface Booking {
  id: string;
  tokenNumber: string; // e.g. "MBMC-CAMP-1042" or "MBMC-HOSP-3081"
  type: 'camp' | 'hospital';
  targetId: string; // camp id or hospital id
  targetName: string;
  slotDate: string;
  slotTime: string;
  specialtyOrVaccine?: string;
  doctorName?: string;
  userName: string;
  userPhone: string;
  userEmail?: string;
  userAge: number;
  userGender: string;
  userLocality: string;
  userId?: string; // if registered user
  status: 'confirmed' | 'attended' | 'cancelled' | 'no_show';
  createdAt: string;
}

export interface Feedback {
  id: string;
  name: string;
  phoneOrEmail: string;
  locality: string;
  category: 'camps' | 'hospitals' | 'medicine_availability' | 'translation' | 'general';
  rating: number;
  message: string;
  createdAt: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  timestamp: string;
  suggestedActions?: { label: string; action: string }[];
}
