import { Router, Request, Response } from 'express';
import { db } from '../db';
import { GoogleGenAI } from '@google/genai';
import { MedicineInfo } from '../types';

const router = Router();

let geminiClient: GoogleGenAI | null = null;
function getGemini(): GoogleGenAI | null {
  if (!geminiClient && process.env.GEMINI_API_KEY) {
    try {
      geminiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    } catch (e) {
      console.warn('Gemini client init warning:', e);
    }
  }
  return geminiClient;
}

// Helper to find matching medicine in directory
function findMatchingMedicine(rawText: string): MedicineInfo | null {
  const text = rawText.toLowerCase();
  const directory = db.getMedicinesDirectory();

  for (const [key, med] of Object.entries(directory)) {
    if (
      text.includes(key) ||
      text.includes(med.genericName.toLowerCase()) ||
      text.includes(med.name.toLowerCase()) ||
      (key === 'paracetamol' && (text.includes('dolo') || text.includes('calpol') || text.includes('crocin') || text.includes('pcm') || text.includes('650'))) ||
      (key === 'amoxicillin' && (text.includes('mox') || text.includes('novamox') || text.includes('amoxy'))) ||
      (key === 'metformin' && (text.includes('glycomet') || text.includes('glyciphage') || text.includes('sugar tab'))) ||
      (key === 'amlodipine' && (text.includes('amlong') || text.includes('stamlo') || text.includes('norvasc'))) ||
      (key === 'cetirizine' && (text.includes('cetzine') || text.includes('okacet') || text.includes('alerid') || text.includes('zyrtec'))) ||
      (key === 'pantoprazole' && (text.includes('pan 40') || text.includes('pantocid') || text.includes('pantodac') || text.includes('pantop'))) ||
      (key === 'ors' && (text.includes('electral') || text.includes('enerzal') || text.includes('rehydration') || text.includes('oral salt'))) ||
      (key === 'azithromycin' && (text.includes('azee') || text.includes('zithrox') || text.includes('azithral'))) ||
      (key === 'telmisartan' && (text.includes('telma') || text.includes('telpres') || text.includes('sartin'))) ||
      (key === 'folic_iron' && (text.includes('autrin') || text.includes('ifa') || text.includes('ferrous') || text.includes('folic')))
    ) {
      return med;
    }
  }

  return null;
}

// POST /api/scan-medicine
router.post('/', async (req: Request, res: Response) => {
  try {
    const { ocrText, targetLang = 'en', userQuery } = req.body;

    if (!ocrText || !ocrText.trim()) {
      return res.status(400).json({ error: 'Please provide scanned or typed text from the medicine strip.' });
    }

    const raw = ocrText.trim();
    const matched = findMatchingMedicine(raw);

    // If Gemini AI is available, generate dynamic plain-language summary for ANY medicine brand
    const ai = getGemini();
    if (ai) {
      try {
        const prompt = `You are a compassionate community health pharmacist at MBMC Mira Bhayandar assisting elderly people and mothers with low health literacy.
Analyze this text extracted from a medicine strip or box: "${raw}".
Target Language code: ${targetLang} (Translate the entire JSON response values into this target language so elderly residents understand easily!).

Return ONLY valid JSON matching this schema:
{
  "detectedMedicineName": "Brand and generic name detected",
  "category": "e.g. Fever relief / Blood pressure / Antibiotic",
  "simplePurpose": "2-3 simple sentences in plain 5th-grade words explaining what illness or discomfort this medicine is used for",
  "dosageNotes": "Common usage guidelines (e.g. with water after food, morning/night, warning not to crush)",
  "commonSideEffects": ["Side effect 1 in plain words", "Side effect 2", "Side effect 3"],
  "precautions": ["Important precaution 1", "Important precaution 2"],
  "requiresDoctorPrescription": true/false,
  "warningDisclaimer": "Crucial disclaimer to never start/stop without consulting a certified MBMC doctor or pharmacist."
}`;

        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
        });

        if (response.text) {
          const cleanedJson = response.text.replace(/```json/g, '').replace(/```/g, '').trim();
          const parsed = JSON.parse(cleanedJson);
          return res.json({
            success: true,
            source: 'gemini-ai-pharmacist',
            medicineInfo: parsed,
            rawExtractedText: raw,
          });
        }
      } catch (aiErr) {
        console.warn('Gemini OCR interpretation fallback to local directory:', aiErr);
      }
    }

    // Fallback using internal verified medicine directory
    if (matched) {
      return res.json({
        success: true,
        source: 'verified-mbmc-formulary',
        medicineInfo: {
          detectedMedicineName: matched.name,
          genericName: matched.genericName,
          category: matched.category,
          simplePurpose: matched.simplePurpose,
          dosageNotes: matched.dosageNotes,
          commonSideEffects: matched.commonSideEffects,
          precautions: matched.precautions,
          requiresDoctorPrescription: matched.requiresDoctorPrescription,
          warningDisclaimer: matched.disclaimer + ' Always verify with your local medical store pharmacist in Mira Bhayandar.',
        },
        rawExtractedText: raw,
      });
    }

    // If no direct match in top 10, return safe educational generic advice
    return res.json({
      success: true,
      source: 'general-health-scanner',
      medicineInfo: {
        detectedMedicineName: raw.slice(0, 40),
        category: 'Unverified Medicine Strip',
        simplePurpose: `Text detected: "${raw.slice(0, 60)}...". Please show this strip directly to the pharmacist at the nearest Jan Aushadhi Kendra or Temba / Indira Gandhi Hospital OPD.`,
        dosageNotes: 'Do not consume unknown tablets without showing the strip to a registered doctor or pharmacist.',
        commonSideEffects: ['Taking incorrect dosage can cause stomach irritation or allergic reactions'],
        precautions: ['Always check expiry date on the foil strip edge', 'Keep out of reach of young children', 'Store away from direct monsoon moisture and heat'],
        requiresDoctorPrescription: true,
        warningDisclaimer: 'Arogya Setu Scanner provides educational guidance only. Never self-medicate.',
      },
      rawExtractedText: raw,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Medicine scan failed' });
  }
});

export default router;
