import { Router, Response } from 'express';
import bcrypt from 'bcryptjs';
import { db } from '../db';
import { generateToken, AuthRequest, requireAuth } from '../auth';
import { User } from '../types';

const router = Router();

function sanitizeUser(user: User) {
  const { passwordHash, ...safeUser } = user;
  return safeUser;
}

// Signup
router.post('/signup', async (req, res: Response) => {
  try {
    const { name, emailOrPhone, password, preferredLanguage, locality, age, gender, emergencyContact } = req.body;

    if (!name || !emailOrPhone || !password) {
      return res.status(400).json({ error: 'Name, Email/Phone, and Password are required.' });
    }

    const existing = db.findUserByEmailOrPhone(emailOrPhone);
    if (existing) {
      return res.status(409).json({ error: 'An account with this phone number or email already exists.' });
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    const newUser: User = {
      id: `usr_${Date.now()}`,
      name: name.trim(),
      emailOrPhone: emailOrPhone.trim(),
      passwordHash,
      role: emailOrPhone.includes('admin@arogyasetu.mbmc.gov.in') ? 'admin' : 'resident',
      preferredLanguage: preferredLanguage || 'en',
      locality: locality || 'Mira Road East',
      age: age ? Number(age) : undefined,
      gender: gender || 'Not specified',
      emergencyContact: emergencyContact || '',
      createdAt: new Date().toISOString(),
    };

    db.addUser(newUser);
    const token = generateToken(newUser);

    res.cookie('arogya_token', token, {
      httpOnly: true,
      maxAge: 7 * 24 * 60 * 60 * 1000,
      sameSite: 'lax',
    });

    return res.status(201).json({
      message: 'Account created successfully',
      token,
      user: sanitizeUser(newUser),
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Internal server error during signup' });
  }
});

// Login
router.post('/login', async (req, res: Response) => {
  try {
    const { emailOrPhone, password } = req.body;

    if (!emailOrPhone || !password) {
      return res.status(400).json({ error: 'Please provide phone/email and password.' });
    }

    const user = db.findUserByEmailOrPhone(emailOrPhone);
    if (!user) {
      return res.status(401).json({ error: 'No account found with this phone number or email.' });
    }

    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) {
      return res.status(401).json({ error: 'Incorrect password. Please try again.' });
    }

    const token = generateToken(user);

    res.cookie('arogya_token', token, {
      httpOnly: true,
      maxAge: 7 * 24 * 60 * 60 * 1000,
      sameSite: 'lax',
    });

    return res.json({
      message: 'Login successful',
      token,
      user: sanitizeUser(user),
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Internal server error during login' });
  }
});

// Logout
router.post('/logout', (req, res: Response) => {
  res.clearCookie('arogya_token');
  return res.json({ message: 'Logged out successfully' });
});

// Get Current User
router.get('/me', (req: AuthRequest, res: Response) => {
  if (!req.user) {
    return res.json({ user: null });
  }
  const userBookings = db.getUserBookings(req.user.id);
  return res.json({
    user: sanitizeUser(req.user),
    bookingsCount: userBookings.length,
  });
});

// Update Profile
router.put('/profile', requireAuth, (req: AuthRequest, res: Response) => {
  if (!req.user) return res.status(401).json({ error: 'Unauthorized' });

  const { name, preferredLanguage, locality, age, gender, emergencyContact } = req.body;
  const updated = db.updateUser(req.user.id, {
    name: name || req.user.name,
    preferredLanguage: preferredLanguage || req.user.preferredLanguage,
    locality: locality || req.user.locality,
    age: age !== undefined ? Number(age) : req.user.age,
    gender: gender || req.user.gender,
    emergencyContact: emergencyContact !== undefined ? emergencyContact : req.user.emergencyContact,
  });

  if (!updated) return res.status(404).json({ error: 'User not found' });
  return res.json({ message: 'Profile updated successfully', user: sanitizeUser(updated) });
});

// Forgot Password Flow
router.post('/forgot-password', async (req, res: Response) => {
  const { emailOrPhone, newPassword } = req.body;
  if (!emailOrPhone) {
    return res.status(400).json({ error: 'Phone number or email is required.' });
  }

  const user = db.findUserByEmailOrPhone(emailOrPhone);
  if (!user) {
    return res.status(404).json({ error: 'No account registered with this phone number or email.' });
  }

  if (newPassword) {
    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(newPassword, salt);
    db.updateUser(user.id, { passwordHash });
    return res.json({ message: 'Password has been successfully updated. You can now login.' });
  }

  return res.json({
    message: 'OTP verification code sent to your registered phone number / email.',
    otpSimulation: '123456',
  });
});

export default router;
