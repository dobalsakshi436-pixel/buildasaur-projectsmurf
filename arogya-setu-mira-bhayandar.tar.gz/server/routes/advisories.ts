import { Router, Request, Response } from 'express';
import { db } from '../db';
import { AuthRequest, requireAdmin } from '../auth';
import { HealthAdvisory } from '../types';

const router = Router();

// GET all advisories with optional filters
router.get('/', (req: Request, res: Response) => {
  try {
    const { locality, category, search, lang } = req.query;
    let advisories = db.getAdvisories();

    if (locality && locality !== 'all') {
      const locStr = String(locality).toLowerCase();
      advisories = advisories.filter(
        (a) => a.locality.toLowerCase().includes(locStr) || a.locality.toLowerCase().includes('all')
      );
    }

    if (category && category !== 'all') {
      advisories = advisories.filter((a) => a.category === category);
    }

    if (search) {
      const q = String(search).toLowerCase();
      advisories = advisories.filter(
        (a) =>
          a.title.toLowerCase().includes(q) ||
          a.simpleText.toLowerCase().includes(q) ||
          a.medicalText.toLowerCase().includes(q) ||
          a.locality.toLowerCase().includes(q) ||
          a.symptoms.some((s) => s.toLowerCase().includes(q))
      );
    }

    return res.json({ advisories, total: advisories.length });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// GET single advisory
router.get('/:id', (req: Request, res: Response) => {
  const adv = db.getAdvisoryById(req.params.id);
  if (!adv) return res.status(404).json({ error: 'Advisory not found' });
  return res.json({ advisory: adv });
});

// Admin CREATE advisory
router.post('/', requireAdmin, (req: AuthRequest, res: Response) => {
  try {
    const { title, locality, category, severity, date, medicalText, simpleText, symptoms, precautions, actionHelpline } = req.body;
    if (!title || !locality || !medicalText || !simpleText) {
      return res.status(400).json({ error: 'Title, Locality, Medical Text, and Simple Text are required.' });
    }

    const newAdvisory: HealthAdvisory = {
      id: `adv_${Date.now()}`,
      title,
      locality,
      category: category || 'general',
      severity: severity || 'info',
      date: date || new Date().toISOString().split('T')[0],
      medicalText,
      simpleText,
      symptoms: Array.isArray(symptoms) ? symptoms : (symptoms ? String(symptoms).split(',').map((s) => s.trim()) : []),
      precautions: Array.isArray(precautions) ? precautions : (precautions ? String(precautions).split(',').map((p) => p.trim()) : []),
      actionHelpline: actionHelpline || '022-28112233 (MBMC Health Desk)',
    };

    const saved = db.addAdvisory(newAdvisory);
    return res.status(201).json({ message: 'Health Advisory published successfully', advisory: saved });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Admin UPDATE advisory
router.put('/:id', requireAdmin, (req: AuthRequest, res: Response) => {
  const updated = db.updateAdvisory(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: 'Advisory not found' });
  return res.json({ message: 'Advisory updated successfully', advisory: updated });
});

// Admin DELETE advisory
router.delete('/:id', requireAdmin, (req: AuthRequest, res: Response) => {
  const success = db.deleteAdvisory(req.params.id);
  if (!success) return res.status(404).json({ error: 'Advisory not found' });
  return res.json({ message: 'Advisory removed' });
});

export default router;
