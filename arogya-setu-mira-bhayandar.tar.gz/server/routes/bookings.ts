import { Router, Request, Response } from 'express';
import { db } from '../db';
import { AuthRequest, requireAdmin } from '../auth';
import { Booking } from '../types';

const router = Router();

// Helper to generate readable token
function generateTokenNumber(type: 'camp' | 'hospital'): string {
  const prefix = type === 'camp' ? 'MBMC-CAMP' : 'MBMC-HOSP';
  const randomNum = Math.floor(1000 + Math.random() * 9000);
  return `${prefix}-${randomNum}`;
}

// POST create a booking
router.post('/', (req: AuthRequest, res: Response) => {
  try {
    const {
      type,
      targetId,
      targetName,
      slotDate,
      slotTime,
      specialtyOrVaccine,
      doctorName,
      userName,
      userPhone,
      userEmail,
      userAge,
      userGender,
      userLocality,
    } = req.body;

    if (!type || !targetId || !targetName || !slotDate || !slotTime || !userName || !userPhone) {
      return res.status(400).json({ error: 'Please provide all required booking details.' });
    }

    const tokenNumber = generateTokenNumber(type);
    const userId = req.user ? req.user.id : undefined;

    const newBooking: Booking = {
      id: `bk_${Date.now()}`,
      tokenNumber,
      type,
      targetId,
      targetName,
      slotDate,
      slotTime,
      specialtyOrVaccine: specialtyOrVaccine || '',
      doctorName: doctorName || '',
      userName: userName.trim(),
      userPhone: userPhone.trim(),
      userEmail: userEmail ? userEmail.trim() : (req.user && req.user.emailOrPhone.includes('@') ? req.user.emailOrPhone : ''),
      userAge: userAge ? Number(userAge) : 30,
      userGender: userGender || 'Not specified',
      userLocality: userLocality || (req.user ? req.user.locality : 'Mira Road East'),
      userId,
      status: 'confirmed',
      createdAt: new Date().toISOString(),
    };

    const result = db.createBooking(newBooking);
    if (!result.success) {
      return res.status(400).json({ error: result.error || 'Failed to book slot' });
    }

    return res.status(201).json({
      message: 'Booking confirmed successfully! Keep your token safe.',
      booking: result.booking,
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// GET bookings for current user or lookup by phone / tokenNumber
router.get('/my-bookings', (req: AuthRequest, res: Response) => {
  try {
    const { phone, token } = req.query;

    if (req.user) {
      // logged-in user
      const userBookings = db.getUserBookings(req.user.id);
      return res.json({ bookings: userBookings });
    }

    if (token) {
      const match = db.getBookings().filter((b) => b.tokenNumber.toUpperCase() === String(token).toUpperCase());
      return res.json({ bookings: match });
    }

    if (phone) {
      const match = db.getUserBookings(String(phone));
      return res.json({ bookings: match });
    }

    return res.status(400).json({ error: 'Please log in or provide a phone number / token to look up bookings.' });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// GET single booking details by ID or token
router.get('/:idOrToken', (req: Request, res: Response) => {
  const query = req.params.idOrToken;
  const booking = db.getBookingById(query) || db.getBookings().find((b) => b.tokenNumber.toUpperCase() === query.toUpperCase());
  if (!booking) return res.status(404).json({ error: 'Booking token not found' });
  return res.json({ booking });
});

// POST cancel booking
router.post('/:id/cancel', (req: AuthRequest, res: Response) => {
  try {
    const booking = db.getBookingById(req.params.id);
    if (!booking) return res.status(404).json({ error: 'Booking not found' });

    // allow owner, phone match, or admin to cancel
    const isOwner = req.user && (req.user.id === booking.userId || req.user.role === 'admin');
    const phoneAuth = req.body.phone && req.body.phone === booking.userPhone;

    if (!isOwner && !phoneAuth) {
      return res.status(403).json({ error: 'You are not authorized to cancel this booking.' });
    }

    const updated = db.updateBookingStatus(booking.id, 'cancelled');
    return res.json({ message: 'Booking cancelled and slot released successfully', booking: updated });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Admin GET all bookings
router.get('/admin/all', requireAdmin, (req: AuthRequest, res: Response) => {
  const { status, type, locality } = req.query;
  let all = db.getBookings();

  if (status && status !== 'all') {
    all = all.filter((b) => b.status === status);
  }
  if (type && type !== 'all') {
    all = all.filter((b) => b.type === type);
  }
  if (locality && locality !== 'all') {
    all = all.filter((b) => b.userLocality.toLowerCase().includes(String(locality).toLowerCase()));
  }

  return res.json({ bookings: all, total: all.length });
});

// Admin UPDATE booking status
router.put('/admin/:id/status', requireAdmin, (req: AuthRequest, res: Response) => {
  const { status } = req.body;
  if (!status || !['confirmed', 'attended', 'cancelled', 'no_show'].includes(status)) {
    return res.status(400).json({ error: 'Valid status required (confirmed, attended, cancelled, no_show)' });
  }

  const updated = db.updateBookingStatus(req.params.id, status);
  if (!updated) return res.status(404).json({ error: 'Booking not found' });
  return res.json({ message: `Booking marked as ${status}`, booking: updated });
});

export default router;
