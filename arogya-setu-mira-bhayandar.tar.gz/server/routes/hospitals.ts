import { Router, Request, Response } from 'express';
import { db } from '../db';
import { AuthRequest, requireAdmin } from '../auth';
import { Hospital } from '../types';

const router = Router();

// GET all hospitals with optional filtering by specialty, locality, type
router.get('/', (req: Request, res: Response) => {
  try {
    const { locality, specialty, type, isFreeGovt, search } = req.query;
    let hospitals = db.getHospitals();

    if (locality && locality !== 'all') {
      const locStr = String(locality).toLowerCase();
      hospitals = hospitals.filter((h) => h.locality.toLowerCase().includes(locStr));
    }

    if (specialty && specialty !== 'all') {
      const specStr = String(specialty).toLowerCase();
      hospitals = hospitals.filter((h) =>
        h.specialties.some((s) => s.toLowerCase().includes(specStr))
      );
    }

    if (type && type !== 'all') {
      hospitals = hospitals.filter((h) => h.type === type);
    }

    if (isFreeGovt !== undefined && isFreeGovt !== 'all') {
      const boolVal = isFreeGovt === 'true';
      hospitals = hospitals.filter((h) => h.isFreeGovt === boolVal);
    }

    if (search) {
      const q = String(search).toLowerCase();
      hospitals = hospitals.filter(
        (h) =>
          h.name.toLowerCase().includes(q) ||
          h.address.toLowerCase().includes(q) ||
          h.specialties.some((s) => s.toLowerCase().includes(q)) ||
          h.facilities.some((f) => f.toLowerCase().includes(q))
      );
    }

    return res.json({ hospitals, total: hospitals.length });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// GET single hospital
router.get('/:id', (req: Request, res: Response) => {
  const hosp = db.getHospitalById(req.params.id);
  if (!hosp) return res.status(404).json({ error: 'Hospital not found' });
  return res.json({ hospital: hosp });
});

// Admin CREATE hospital
router.post('/', requireAdmin, (req: AuthRequest, res: Response) => {
  try {
    const { name, type, locality, address, landmark, latitude, longitude, contactNumber, emergencyNumber, specialties, facilities, opdTimings, isFreeGovt } = req.body;
    if (!name || !locality || !address) {
      return res.status(400).json({ error: 'Name, Locality, and Address are required.' });
    }

    const newHosp: Hospital = {
      id: `hosp_${Date.now()}`,
      name,
      type: type || 'Municipal Hospital (MBMC)',
      locality,
      address,
      landmark: landmark || '',
      latitude: Number(latitude) || 19.2812,
      longitude: Number(longitude) || 72.8561,
      contactNumber: contactNumber || '022-28112233',
      emergencyNumber: emergencyNumber || '108',
      specialties: Array.isArray(specialties) ? specialties : (specialties ? String(specialties).split(',').map((s) => s.trim()) : ['General Medicine']),
      facilities: Array.isArray(facilities) ? facilities : (facilities ? String(facilities).split(',').map((f) => f.trim()) : ['Free OPD']),
      opdTimings: opdTimings || 'Monday - Saturday: 9:00 AM - 1:00 PM',
      isFreeGovt: Boolean(isFreeGovt),
      appointmentSlots: [
        { slotId: `s_${Date.now()}_1`, time: '09:30 AM', date: new Date().toISOString().split('T')[0], doctorName: 'Duty Medical Officer', specialty: 'General Medicine', isAvailable: true },
        { slotId: `s_${Date.now()}_2`, time: '11:00 AM', date: new Date().toISOString().split('T')[0], doctorName: 'Duty Medical Officer', specialty: 'General Medicine', isAvailable: true },
      ],
    };

    const saved = db.addHospital(newHosp);
    return res.status(201).json({ message: 'Hospital added successfully', hospital: saved });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Admin UPDATE hospital or appointment slots
router.put('/:id', requireAdmin, (req: AuthRequest, res: Response) => {
  const updated = db.updateHospital(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: 'Hospital not found' });
  return res.json({ message: 'Hospital updated successfully', hospital: updated });
});

// Admin DELETE hospital
router.delete('/:id', requireAdmin, (req: AuthRequest, res: Response) => {
  const success = db.deleteHospital(req.params.id);
  if (!success) return res.status(404).json({ error: 'Hospital not found' });
  return res.json({ message: 'Hospital removed successfully' });
});

export default router;
