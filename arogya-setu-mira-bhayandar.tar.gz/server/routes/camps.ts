import { Router, Request, Response } from 'express';
import { db } from '../db';
import { AuthRequest, requireAdmin } from '../auth';
import { VaccinationCamp } from '../types';

const router = Router();

// GET all vaccination camps
router.get('/', (req: Request, res: Response) => {
  try {
    const { locality, targetGroup, search } = req.query;
    let camps = db.getCamps();

    if (locality && locality !== 'all') {
      const locStr = String(locality).toLowerCase();
      camps = camps.filter((c) => c.locality.toLowerCase().includes(locStr));
    }

    if (targetGroup && targetGroup !== 'all') {
      camps = camps.filter((c) => c.targetGroup === targetGroup || c.targetGroup === 'all');
    }

    if (search) {
      const q = String(search).toLowerCase();
      camps = camps.filter(
        (c) =>
          c.name.toLowerCase().includes(q) ||
          c.locality.toLowerCase().includes(q) ||
          c.address.toLowerCase().includes(q) ||
          c.vaccinesOffered.some((v) => v.toLowerCase().includes(q))
      );
    }

    return res.json({ camps, total: camps.length });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// GET single camp
router.get('/:id', (req: Request, res: Response) => {
  const camp = db.getCampById(req.params.id);
  if (!camp) return res.status(404).json({ error: 'Vaccination camp not found' });
  return res.json({ camp });
});

// Admin CREATE camp
router.post('/', requireAdmin, (req: AuthRequest, res: Response) => {
  try {
    const { name, locality, address, landmark, date, timeRange, targetGroup, vaccinesOffered, totalSlots, contactNumber, googleMapsUrl } = req.body;
    if (!name || !locality || !address || !date || !timeRange) {
      return res.status(400).json({ error: 'Name, Locality, Address, Date, and Time Range are required.' });
    }

    const slotsNum = Number(totalSlots) || 30;

    const newCamp: VaccinationCamp = {
      id: `camp_${Date.now()}`,
      name,
      locality,
      address,
      landmark: landmark || '',
      date,
      timeRange,
      targetGroup: targetGroup || 'all',
      vaccinesOffered: Array.isArray(vaccinesOffered) ? vaccinesOffered : (vaccinesOffered ? String(vaccinesOffered).split(',').map((v) => v.trim()) : ['General Immunization']),
      totalSlots: slotsNum,
      availableSlots: slotsNum,
      contactNumber: contactNumber || '022-28112233',
      googleMapsUrl: googleMapsUrl || `https://maps.google.com/?q=${encodeURIComponent(name + ' ' + address + ' Mira Bhayandar')}`,
      status: 'upcoming',
    };

    const saved = db.addCamp(newCamp);
    return res.status(201).json({ message: 'Vaccination Camp added successfully', camp: saved });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Admin UPDATE camp
router.put('/:id', requireAdmin, (req: AuthRequest, res: Response) => {
  const updated = db.updateCamp(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: 'Camp not found' });
  return res.json({ message: 'Camp updated successfully', camp: updated });
});

// Admin DELETE camp
router.delete('/:id', requireAdmin, (req: AuthRequest, res: Response) => {
  const success = db.deleteCamp(req.params.id);
  if (!success) return res.status(404).json({ error: 'Camp not found' });
  return res.json({ message: 'Camp deleted successfully' });
});

export default router;
