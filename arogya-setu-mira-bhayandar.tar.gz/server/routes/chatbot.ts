import { Router, Request, Response } from 'express';
import { GoogleGenAI } from '@google/genai';
import { db } from '../db';

const router = Router();

let geminiClient: GoogleGenAI | null = null;
function getGemini(): GoogleGenAI | null {
  if (!geminiClient && process.env.GEMINI_API_KEY) {
    try {
      geminiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    } catch (e) {
      console.warn('Gemini chatbot client init warning:', e);
    }
  }
  return geminiClient;
}

interface FaqRule {
  keywords: string[];
  response: string;
  responseHi?: string;
  responseMr?: string;
  suggestedActions?: { label: string; action: string }[];
}

const FAQ_RULES: FaqRule[] = [
  {
    keywords: ['dengue', 'malaria', 'mosquito', 'platelet', 'fever', 'ताप', 'बुखार'],
    response: 'Dengue & Malaria Alert: Symptoms include sudden high fever, headache behind the eyes, body pain, and red spots. 1) Drink plenty of fluids (ORS, coconut water). 2) Take ONLY Paracetamol for fever; avoid Brufen or Aspirin. 3) Visit Temba Hospital or Indira Gandhi Hospital for free CBC/platelet testing.',
    responseHi: 'डेंगू और मलेरिया: तेज बुखार, आंखों के पीछे दर्द और बदन दर्द इसके लक्षण हैं। केवल पैरासिटामोल लें, ब्रूफेन या एस्पिरिन न लें। खूब पानी व ओआरएस पिएं। मुफ्त खून और प्लेटलेट जांच के लिए इंदिरा गांधी या तेंभा अस्पताल जाएं।',
    responseMr: 'डेंग्यू व मलेरिया: अचानक ताप, डोकेदुखी, डोळ्यांमागे दुखणे आणि अशक्तपणा ही लक्षणे आहेत. फक्त पॅरासिटामॉल घ्या. भरपूर पाणी व ओआरएस प्या. मोफत तपासणीसाठी तेंभा किंवा इंदिरा गांधी रुग्णालयात जा.',
    suggestedActions: [
      { label: 'View Dengue Advisory', action: '/advisories' },
      { label: 'Find Nearby Hospitals', action: '/hospitals' },
      { label: 'Book Doctor OPD Slot', action: '/book-slot' },
    ],
  },
  {
    keywords: ['vaccine', 'vaccination', 'camp', 'camp booking', 'लस', 'लसीकरण', 'टीका', 'बूस्टर'],
    response: 'Free Vaccination Camps in Mira Bhayandar: MBMC conducts regular camps for senior citizen pneumonia/flu, childhood routine vaccines (Polio, MR, Pentavalent), and maternal tetanus. You can check upcoming dates and book a confirmed digital slot right now.',
    responseHi: 'मीरा भाईंदर में मुफ्त टीकाकरण शिविर: बुजुर्गों के लिए फ्लू/निमोनिया और बच्चों के लिए सभी आवश्यक टीके मुफ्त लगाए जा रहे हैं। आप तुरंत तारीख देखकर अपना स्लॉट बुक कर सकते हैं।',
    responseMr: 'मीरा भाईंदर मोफत लसीकरण: ज्येष्ठ नागरिकांसाठी फ्लू/न्यूमोनिया आणि लहान मुलांसाठी सर्व नियमित लसी महापालिकेच्या केंद्रांवर मोफत उपलब्ध आहेत. तुम्ही लगेच ऑनलाइन टोकन बुक करू शकता.',
    suggestedActions: [
      { label: 'View Upcoming Camps', action: '/camps' },
      { label: 'Book Camp Slot', action: '/book-slot' },
    ],
  },
  {
    keywords: ['hospital', 'clinic', 'doctor', 'opd', 'temba', 'indira gandhi', 'रुग्णालय', 'दवाखाना', 'अस्पताल'],
    response: 'Major MBMC Health Centers: 1) Bharat Ratna Indira Gandhi Municipal Hospital (Mira Road - 022-28114400) 2) Temba Municipal General Hospital (Bhayandar West - 022-28191244) 3) Naya Nagar UPHC (022-28117890) 4) Kashimira CHC Trauma Center (022-28456677). Emergency Ambulance: Call 108.',
    responseHi: 'प्रमुख सरकारी अस्पताल: १) इंदिरा गांधी सिविल अस्पताल (मीरा रोड) २) तेंभा जनरल अस्पताल (भाईंदर वेस्ट) ३) नया नगर प्राथमिक स्वास्थ्य केंद्र ४) काशिमीरा ट्रामा सेंटर। इमरजेंसी एम्बुलेंस: 108 पर कॉल करें।',
    responseMr: 'प्रमुख महापालिका रुग्णालये: १) इंदिरा गांधी रुग्णालय (मीरा रोड) २) तेंभा रुग्णालय (भाईंदर पश्चिम) ३) नया नगर आरोग्य केंद्र ४) काशिमीरा आरोग्य केंद्र. मोफत रुग्णवाहिका: १०८ डायल करा.',
    suggestedActions: [
      { label: 'Open Hospital Map', action: '/hospitals' },
      { label: 'Call Emergency 108', action: 'tel:108' },
    ],
  },
  {
    keywords: ['medicine', 'pharmacy', 'chemist', 'dolo', 'paracetamol', 'jan aushadhi', 'औषध', 'दवा', 'केमिस्ट'],
    response: 'Find Subsidized Medicines: Check live stock at Pradhan Mantri Jan Aushadhi Kendra (Mira Road Station East) offering 50-80% discount on generic medicines, and 24x7 Noble Chemist (Bhayandar West) / Wellness Forever (Beverly Park).',
    responseHi: 'किफायती दवाएं: प्रधानमंत्री जन औषधि केंद्र (मीरा रोड स्टेशन) पर ५०-८०% छूट पर जेनेरिक दवाएं उपलब्ध हैं। आप हमारे मेडिसिन ट्रैकर से नजदीकी दुकान में स्टॉक चेक कर सकते हैं।',
    responseMr: 'स्वस्त औषधे: जन औषधी केंद्र (मीरा रोड स्टेशन) येथे ५० ते ८० टक्के सवलतीत जेनेरिक औषधे मिळतात. २४ तास सुरू असणारे केमिस्ट पाहण्यासाठी मेडिसिन सर्च वापरा.',
    suggestedActions: [
      { label: 'Search Medicine Stock', action: '/pharmacies' },
      { label: 'Scan Medicine Strip', action: '/scan-medicine' },
    ],
  },
  {
    keywords: ['helpline', 'emergency', 'contact', 'number', 'phone', 'मदत', 'हेल्पलाइन'],
    response: 'Emergency & Health Helplines for Mira Bhayandar: • Ambulance: 108 (Toll-Free) • MBMC Health Dept: 022-28112233 • Senior Citizen Helpline: 14567 • Women Helpline: 1091 / 181 • National Health Portal: 104.',
    responseHi: 'आपातकालीन हेल्पलाइन नंबर: • एम्बुलेंस: 108 • मीरा भाईंदर स्वास्थ्य विभाग: 022-28112233 • वरिष्ठ नागरिक हेल्पलाइन: 14567 • महिला सुरक्षा: 1091 / 181 • महाराष्ट्र स्वास्थ्य: 104.',
    responseMr: 'तातडीचे दूरध्वनी क्रमांक: • रुग्णवाहिका: १०८ • मनपा आरोग्य विभाग: ०२२-२८११२२३३ • ज्येष्ठ नागरिक: १४५६७ • महिला मदत कक्ष: १०९१ • आरोग्य सहाय्यता: १०४.',
    suggestedActions: [
      { label: 'View Contact & Helplines', action: '/about' },
      { label: 'Emergency 108', action: 'tel:108' },
    ],
  },
];

router.post('/', async (req: Request, res: Response) => {
  try {
    const { message, lang = 'en', conversationHistory = [] } = req.body;

    if (!message || !message.trim()) {
      return res.status(400).json({ error: 'Message cannot be empty.' });
    }

    const userText = message.trim();
    const lower = userText.toLowerCase();

    // 1. Check Rule-based FAQ Matching first
    for (const rule of FAQ_RULES) {
      if (rule.keywords.some((kw) => lower.includes(kw.toLowerCase()))) {
        let reply = rule.response;
        if (lang === 'hi' && rule.responseHi) reply = rule.responseHi;
        if (lang === 'mr' && rule.responseMr) reply = rule.responseMr;

        return res.json({
          reply,
          suggestedActions: rule.suggestedActions || [],
          source: 'faq-rule-engine',
        });
      }
    }

    // 2. If Gemini AI is configured, use it for personalized conversational answers grounded in Mira Bhayandar health context
    const ai = getGemini();
    if (ai) {
      try {
        const prompt = `You are "Arogya Mitra", a warm, respectful, and reliable community health assistant for Mira Bhayandar Municipal Corporation (MBMC).
The user is asking: "${userText}".
Target language: ${lang} (Respond in the language requested by the user, using simple, clear, and reassuring words suitable for elderly people and women).
Health context:
- Municipal Hospitals: Bharat Ratna Indira Gandhi Hospital (Mira Road), Temba General Hospital (Bhayandar West).
- Community Health Centers: Naya Nagar UPHC, Kashimira CHC, Uttan PHC.
- Emergency Ambulance: 108
- Always include a gentle reminder that for severe symptoms, the resident should consult an MBMC doctor immediately.
Keep answer under 3-4 short, readable sentences.`;

        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: prompt,
        });

        if (response.text) {
          return res.json({
            reply: response.text.trim(),
            suggestedActions: [
              { label: 'Find Nearby Hospitals', action: '/hospitals' },
              { label: 'Book Health Slot', action: '/book-slot' },
              { label: 'Vaccination Camps', action: '/camps' },
            ],
            source: 'gemini-health-bot',
          });
        }
      } catch (aiErr) {
        console.warn('Gemini chatbot fallback triggered:', aiErr);
      }
    }

    // 3. Helpful default fallback
    const defaultReplies: Record<string, string> = {
      hi: 'नमस्ते! मैं आरोग्य सेतु मीरा भाईंदर सहायक हूँ। आप मुझसे डेंगू/मलेरिया के लक्षण, टीकाकरण शिविर, नजदीकी अस्पताल (तेंभा / इंदिरा गांधी) और जन औषधि केंद्र के बारे में पूछ सकते हैं।',
      mr: 'नमस्कार! मी आरोग्य सेतू मीरा भाईंदर सहाय्यक आहे. आपण मला डेंग्यूची लक्षणे, लसीकरण शिबिरे, महापालिका दवाखाने (तेंभा / इंदिरा गांधी) व औषध दुकानांविषयी विचारू शकता.',
      gu: 'નમસ્તે! હું આરોગ્ય સેતુ સહાયક છું. તમે મને તાવ/ડેન્ગ્યુ, રસીકરણ કેમ્પ, નજીકની હોસ્પિટલ અને દવાઓ વિશે પૂછી શકો છો.',
      en: 'Hello! I am your Arogya Setu Mira Bhayandar Health Assistant. You can ask me about dengue/malaria symptoms, upcoming vaccination camps, municipal hospital OPD timings, or medicine stock in nearby stores.',
    };

    return res.json({
      reply: defaultReplies[lang] || defaultReplies.en,
      suggestedActions: [
        { label: 'Dengue & Fever Care', action: '/advisories' },
        { label: 'Vaccination Camps', action: '/camps' },
        { label: 'Hospitals & OPD', action: '/hospitals' },
        { label: 'Medicine Availability', action: '/pharmacies' },
      ],
      source: 'default-health-assistant',
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Chatbot service error' });
  }
});

export default router;
