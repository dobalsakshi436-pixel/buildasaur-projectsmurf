import { Router, Request, Response } from 'express';
import { db } from '../db';
import { AuthRequest, requireAdmin } from '../auth';
import { Feedback } from '../types';

const router = Router();

// POST submit feedback
router.post('/', (req: Request, res: Response) => {
  try {
    const { name, phoneOrEmail, locality, category, rating, message } = req.body;

    if (!name || !message) {
      return res.status(400).json({ error: 'Name and message are required.' });
    }

    const newFeedback: Feedback = {
      id: `fb_${Date.now()}`,
      name: name.trim(),
      phoneOrEmail: phoneOrEmail ? phoneOrEmail.trim() : 'Anonymous',
      locality: locality || 'Mira Road',
      category: category || 'general',
      rating: Number(rating) || 5,
      message: message.trim(),
      createdAt: new Date().toISOString(),
    };

    const saved = db.addFeedback(newFeedback);
    return res.status(201).json({ message: 'Thank you for your feedback! It helps improve health services for all citizens.', feedback: saved });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Admin GET all feedback
router.get('/all', requireAdmin, (req: AuthRequest, res: Response) => {
  const feedbacks = db.getFeedback();
  return res.json({ feedback: feedbacks, total: feedbacks.length });
});

export default router;
