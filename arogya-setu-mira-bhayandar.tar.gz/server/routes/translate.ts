import { Router, Request, Response } from 'express';
import { GoogleGenAI } from '@google/genai';

const router = Router();

// Full 100+ languages catalog with code, native name, and english name
export const SUPPORTED_LANGUAGES = [
  // Primary local languages
  { code: 'hi', name: 'Hindi', native: 'हिन्दी', isPinned: true },
  { code: 'mr', name: 'Marathi', native: 'मराठी', isPinned: true },
  { code: 'gu', name: 'Gujarati', native: 'ગુજરાતી', isPinned: true },
  { code: 'en', name: 'English', native: 'English', isPinned: true },

  // Major Indian regional languages
  { code: 'ur', name: 'Urdu', native: 'اردو' },
  { code: 'bn', name: 'Bengali', native: 'বাংলা' },
  { code: 'ta', name: 'Tamil', native: 'தமிழ்' },
  { code: 'te', name: 'Telugu', native: 'తెలుగు' },
  { code: 'kn', name: 'Kannada', native: 'ಕನ್ನಡ' },
  { code: 'ml', name: 'Malayalam', native: 'മലയാളം' },
  { code: 'pa', name: 'Punjabi', native: 'ਪੰਜਾਬੀ' },
  { code: 'or', name: 'Odia', native: 'ଓଡ଼ିଆ' },
  { code: 'as', name: 'Assamese', native: 'অসমীয়া' },
  { code: 'sa', name: 'Sanskrit', native: 'संस्कृतम्' },
  { code: 'sd', name: 'Sindhi', native: 'سنڌي' },
  { code: 'ne', name: 'Nepali', native: 'नेपाली' },
  { code: 'kok', name: 'Konkani', native: 'कोंकणी' },

  // Global & World Languages (100+)
  { code: 'af', name: 'Afrikaans', native: 'Afrikaans' },
  { code: 'sq', name: 'Albanian', native: 'Shqip' },
  { code: 'am', name: 'Amharic', native: 'አማርኛ' },
  { code: 'ar', name: 'Arabic', native: 'العربية' },
  { code: 'hy', name: 'Armenian', native: 'Հայերեն' },
  { code: 'az', name: 'Azerbaijani', native: 'Azərbaycan dili' },
  { code: 'eu', name: 'Basque', native: 'Euskara' },
  { code: 'be', name: 'Belarusian', native: 'Беларуская' },
  { code: 'bs', name: 'Bosnian', native: 'Bosanski' },
  { code: 'bg', name: 'Bulgarian', native: 'Български' },
  { code: 'ca', name: 'Catalan', native: 'Català' },
  { code: 'ceb', name: 'Cebuano', native: 'Cebuano' },
  { code: 'zh', name: 'Chinese (Simplified)', native: '简体中文' },
  { code: 'zh-TW', name: 'Chinese (Traditional)', native: '繁體中文' },
  { code: 'co', name: 'Corsican', native: 'Corsu' },
  { code: 'hr', name: 'Croatian', native: 'Hrvatski' },
  { code: 'cs', name: 'Czech', native: 'Čeština' },
  { code: 'da', name: 'Danish', native: 'Dansk' },
  { code: 'nl', name: 'Dutch', native: 'Nederlands' },
  { code: 'eo', name: 'Esperanto', native: 'Esperanto' },
  { code: 'et', name: 'Estonian', native: 'Eesti' },
  { code: 'tl', name: 'Filipino / Tagalog', native: 'Filipino' },
  { code: 'fi', name: 'Finnish', native: 'Suomi' },
  { code: 'fr', name: 'French', native: 'Français' },
  { code: 'fy', name: 'Frisian', native: 'Frysk' },
  { code: 'gl', name: 'Galician', native: 'Galego' },
  { code: 'ka', name: 'Georgian', native: 'ქართული' },
  { code: 'de', name: 'German', native: 'Deutsch' },
  { code: 'el', name: 'Greek', native: 'Ελληνικά' },
  { code: 'ht', name: 'Haitian Creole', native: 'Kreyòl ayisyen' },
  { code: 'ha', name: 'Hausa', native: 'Hausa' },
  { code: 'haw', name: 'Hawaiian', native: 'ʻŌlelo Hawaiʻi' },
  { code: 'he', name: 'Hebrew', native: 'עברית' },
  { code: 'hmn', name: 'Hmong', native: 'Hmoob' },
  { code: 'hu', name: 'Hungarian', native: 'Magyar' },
  { code: 'is', name: 'Icelandic', native: 'Íslenska' },
  { code: 'ig', name: 'Igbo', native: 'Asụsụ Igbo' },
  { code: 'id', name: 'Indonesian', native: 'Bahasa Indonesia' },
  { code: 'ga', name: 'Irish', native: 'Gaeilge' },
  { code: 'it', name: 'Italian', native: 'Italiano' },
  { code: 'ja', name: 'Japanese', native: '日本語' },
  { code: 'jv', name: 'Javanese', native: 'Basa Jawa' },
  { code: 'kk', name: 'Kazakh', native: 'Қазақ тілі' },
  { code: 'km', name: 'Khmer', native: 'ភាសាខ្មែរ' },
  { code: 'ko', name: 'Korean', native: '한국어' },
  { code: 'ku', name: 'Kurdish', native: 'Kurdî' },
  { code: 'ky', name: 'Kyrgyz', native: 'Кыргызча' },
  { code: 'lo', name: 'Lao', native: 'ພາສາລາວ' },
  { code: 'la', name: 'Latin', native: 'Latina' },
  { code: 'lv', name: 'Latvian', native: 'Latviešu' },
  { code: 'lt', name: 'Lithuanian', native: 'Lietuvių' },
  { code: 'lb', name: 'Luxembourgish', native: 'Lëtzebuergesch' },
  { code: 'mk', name: 'Macedonian', native: 'Македонски' },
  { code: 'mg', name: 'Malagasy', native: 'Malagasy' },
  { code: 'ms', name: 'Malay', native: 'Bahasa Melayu' },
  { code: 'mt', name: 'Maltese', native: 'Malti' },
  { code: 'mi', name: 'Maori', native: 'Te Reo Māori' },
  { code: 'mn', name: 'Mongolian', native: 'Монгол хэл' },
  { code: 'my', name: 'Myanmar (Burmese)', native: 'မြန်မာစာ' },
  { code: 'no', name: 'Norwegian', native: 'Norsk' },
  { code: 'ps', name: 'Pashto', native: 'پښتو' },
  { code: 'fa', name: 'Persian', native: 'فارسی' },
  { code: 'pl', name: 'Polish', native: 'Polski' },
  { code: 'pt', name: 'Portuguese', native: 'Português' },
  { code: 'ro', name: 'Romanian', native: 'Română' },
  { code: 'ru', name: 'Russian', native: 'Русский' },
  { code: 'sm', name: 'Samoan', native: 'Gagana Samoa' },
  { code: 'gd', name: 'Scots Gaelic', native: 'Gàidhlig' },
  { code: 'sr', name: 'Serbian', native: 'Српски' },
  { code: 'st', name: 'Sesotho', native: 'Sesotho' },
  { code: 'sn', name: 'Shona', native: 'chiShona' },
  { code: 'si', name: 'Sinhala', native: 'සිංහල' },
  { code: 'sk', name: 'Slovak', native: 'Slovenčina' },
  { code: 'sl', name: 'Slovenian', native: 'Slovenščina' },
  { code: 'so', name: 'Somali', native: 'Soomaaliga' },
  { code: 'es', name: 'Spanish', native: 'Español' },
  { code: 'su', name: 'Sundanese', native: 'Basa Sunda' },
  { code: 'sw', name: 'Swahili', native: 'Kiswahili' },
  { code: 'sv', name: 'Swedish', native: 'Svenska' },
  { code: 'tg', name: 'Tajik', native: 'Тоҷикӣ' },
  { code: 'th', name: 'Thai', native: 'ไทย' },
  { code: 'tr', name: 'Turkish', native: 'Türkçe' },
  { code: 'uk', name: 'Ukrainian', native: 'Українська' },
  { code: 'uz', name: 'Uzbek', native: 'Oʻzbekcha' },
  { code: 'vi', name: 'Vietnamese', native: 'Tiếng Việt' },
  { code: 'cy', name: 'Welsh', native: 'Cymraeg' },
  { code: 'xh', name: 'Xhosa', native: 'isiXhosa' },
  { code: 'yi', name: 'Yiddish', native: 'ייִדיש' },
  { code: 'yo', name: 'Yoruba', native: 'Yorùbá' },
  { code: 'zu', name: 'Zulu', native: 'isiZulu' },
];

let geminiClient: GoogleGenAI | null = null;
function getGemini(): GoogleGenAI | null {
  if (!geminiClient && process.env.GEMINI_API_KEY) {
    try {
      geminiClient = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
    } catch (e) {
      console.warn('Gemini client init warning:', e);
    }
  }
  return geminiClient;
}

// GET all supported languages
router.get('/languages', (req: Request, res: Response) => {
  return res.json({ languages: SUPPORTED_LANGUAGES, count: SUPPORTED_LANGUAGES.length });
});

// POST translate text
router.post('/', async (req: Request, res: Response) => {
  try {
    const { text, sourceLang = 'auto', targetLang = 'hi' } = req.body;

    if (!text || !text.trim()) {
      return res.status(400).json({ error: 'Text to translate is required' });
    }

    const trimmedText = text.trim();
    const targetObj = SUPPORTED_LANGUAGES.find((l) => l.code === targetLang) || { name: targetLang };

    // 1. If source and target are identical
    if (sourceLang === targetLang) {
      return res.json({
        translatedText: trimmedText,
        detectedSource: sourceLang,
        targetLang,
        provider: 'direct',
      });
    }

    // 2. Try Gemini AI translation if API key is present
    const ai = getGemini();
    if (ai) {
      try {
        const response = await ai.models.generateContent({
          model: 'gemini-2.5-flash',
          contents: `You are a medical & community health translator for Mira Bhayandar residents (especially elderly citizens and lower-income women).
Translate the following text accurately into ${targetObj.name} (${targetLang}).
Keep medical terms easy to understand, clear, and compassionate. Return ONLY the translated string without quotes, notes, or explanations:

"${trimmedText}"`,
        });

        if (response.text) {
          return res.json({
            translatedText: response.text.trim(),
            detectedSource: sourceLang === 'auto' ? 'auto-detected' : sourceLang,
            targetLang,
            provider: 'gemini-health-engine',
          });
        }
      } catch (geminiErr) {
        console.warn('Gemini translation fallback triggered:', geminiErr);
      }
    }

    // 3. Free LibreTranslate / MyMemory public fallback
    try {
      const srcCode = sourceLang === 'auto' ? 'en' : sourceLang;
      const url = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(trimmedText.slice(0, 500))}&langpair=${srcCode}|${targetLang}`;
      const apiRes = await fetch(url);
      if (apiRes.ok) {
        const data: any = await apiRes.json();
        if (data && data.responseData && data.responseData.translatedText) {
          const rawResult = data.responseData.translatedText;
          // Check if mymemory returned valid match
          if (!rawResult.includes('MYMEMORY WARNING') && !rawResult.includes('QUERY LENGTH LIMIT')) {
            return res.json({
              translatedText: rawResult,
              detectedSource: sourceLang,
              targetLang,
              provider: 'mymemory-open-service',
            });
          }
        }
      }
    } catch (apiErr) {
      console.warn('Free API fallback failed:', apiErr);
    }

    // 4. Offline Phrase & Health dictionary fallback for zero failure
    const commonPhrases: Record<string, Record<string, string>> = {
      'take 1 tablet after meals': {
        hi: 'खाने के बाद 1 गोली लें',
        mr: 'जेवणानंतर 1 गोळी घ्या',
        gu: 'જમ્યા પછી 1 ગોળી લો',
        ur: 'کھانے کے بعد 1 گولی لیں',
      },
      'where is the vaccination camp?': {
        hi: 'टीकाकरण शिविर कहाँ है?',
        mr: 'लसीकरण शिबीर कुठे आहे?',
        gu: 'રસીકરણ કેમ્પ ક્યાં છે?',
        ur: 'ویکسینیشن کیمپ کہاں ہے؟',
      },
      'i have fever and headache': {
        hi: 'मुझे बुखार और सिरदर्द है',
        mr: 'मला ताप आणि डोकेदुखी आहे',
        gu: 'મને તાવ અને માથાનો દુખાવો છે',
        ur: 'مجھے بخار اور سر میں درد ہے',
      },
      'drink boiled water': {
        hi: 'उबला हुआ पानी पिएं',
        mr: 'उकळलेले पाणी प्या',
        gu: 'ઉકાળેલું પાણી પીવો',
        ur: 'ابلا ہوا پانی پئیں',
      },
    };

    const lower = trimmedText.toLowerCase();
    for (const [key, transMap] of Object.entries(commonPhrases)) {
      if (lower.includes(key) && transMap[targetLang]) {
        return res.json({
          translatedText: transMap[targetLang],
          detectedSource: sourceLang,
          targetLang,
          provider: 'offline-health-dictionary',
        });
      }
    }

    // Default polite translation echo
    return res.json({
      translatedText: trimmedText,
      detectedSource: sourceLang,
      targetLang,
      note: 'Translated text preview (configure Gemini API key for deep dialect translation)',
      provider: 'local-fallback',
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message || 'Translation service error' });
  }
});

export default router;
