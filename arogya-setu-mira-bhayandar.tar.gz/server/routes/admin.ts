import { Router, Response } from 'express';
import { db } from '../db';
import { AuthRequest, requireAdmin } from '../auth';

const router = Router();

router.get('/stats', requireAdmin, (req: AuthRequest, res: Response) => {
  try {
    const advisories = db.getAdvisories();
    const camps = db.getCamps();
    const hospitals = db.getHospitals();
    const pharmacies = db.getPharmacies();
    const bookings = db.getBookings();
    const users = db.getUsers();
    const feedback = db.getFeedback();

    const confirmedBookings = bookings.filter((b) => b.status === 'confirmed').length;
    const attendedBookings = bookings.filter((b) => b.status === 'attended').length;
    const cancelledBookings = bookings.filter((b) => b.status === 'cancelled').length;
    const totalSlotsAvailable = camps.reduce((acc, c) => acc + c.availableSlots, 0);

    return res.json({
      stats: {
        totalAdvisories: advisories.length,
        totalCamps: camps.length,
        totalHospitals: hospitals.length,
        totalPharmacies: pharmacies.length,
        totalBookings: bookings.length,
        confirmedBookings,
        attendedBookings,
        cancelledBookings,
        totalSlotsAvailable,
        totalRegisteredUsers: users.length,
        totalFeedback: feedback.length,
      },
      recentBookings: bookings.slice(0, 10),
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

export default router;
