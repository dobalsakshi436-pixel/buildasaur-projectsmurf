import { Router, Request, Response } from 'express';
import { db } from '../db';
import { AuthRequest, requireAdmin } from '../auth';

const router = Router();

// GET pharmacies with search by medicine name or locality
router.get('/', (req: Request, res: Response) => {
  try {
    const { medicine, locality, is24Hours, hasJanAushadhi } = req.query;
    let pharmacies = db.getPharmacies();
    const directory = db.getMedicinesDirectory();

    if (locality && locality !== 'all') {
      const locStr = String(locality).toLowerCase();
      pharmacies = pharmacies.filter((p) => p.locality.toLowerCase().includes(locStr));
    }

    if (is24Hours === 'true') {
      pharmacies = pharmacies.filter((p) => p.is24Hours);
    }

    if (hasJanAushadhi === 'true') {
      pharmacies = pharmacies.filter((p) => p.hasJanAushadhiScheme);
    }

    let results = pharmacies;

    // Filter or highlight matching medicines
    if (medicine) {
      const medQuery = String(medicine).toLowerCase().trim();
      results = pharmacies.map((pharm) => {
        const matchingItems = pharm.inventory.filter(
          (item) =>
            item.name.toLowerCase().includes(medQuery) ||
            item.genericName.toLowerCase().includes(medQuery) ||
            item.category.toLowerCase().includes(medQuery) ||
            item.medicineId.toLowerCase().includes(medQuery)
        );

        return {
          ...pharm,
          matchingItems,
          hasMatch: matchingItems.length > 0,
        };
      }).filter((p) => p.hasMatch);
    }

    return res.json({
      pharmacies: results,
      total: results.length,
      availableMedicinesList: Object.values(directory).map((m) => ({
        id: m.name.toLowerCase().replace(/[^a-z0-9]/g, '_'),
        name: m.name,
        category: m.category,
        genericName: m.genericName,
      })),
    });
  } catch (err: any) {
    return res.status(500).json({ error: err.message });
  }
});

// Admin UPDATE pharmacy or medicine stock
router.put('/:id', requireAdmin, (req: AuthRequest, res: Response) => {
  const updated = db.updatePharmacy(req.params.id, req.body);
  if (!updated) return res.status(404).json({ error: 'Pharmacy not found' });
  return res.json({ message: 'Pharmacy stock updated successfully', pharmacy: updated });
});

export default router;
