import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';
import {
  User,
  HealthAdvisory,
  VaccinationCamp,
  Hospital,
  Pharmacy,
  MedicineInfo,
  Booking,
  Feedback,
} from './types';

interface DatabaseSchema {
  users: User[];
  advisories: HealthAdvisory[];
  camps: VaccinationCamp[];
  hospitals: Hospital[];
  pharmacies: Pharmacy[];
  medicinesDirectory: Record<string, MedicineInfo>;
  bookings: Booking[];
  feedback: Feedback[];
}

const DATA_DIR = path.join(process.cwd(), 'server', 'data');
const DB_FILE = path.join(DATA_DIR, 'store.json');

function hashPasswordSync(password: string): string {
  const salt = bcrypt.genSaltSync(10);
  return bcrypt.hashSync(password, salt);
}

function getInitialSeedData(): DatabaseSchema {
  const adminPasswordHash = hashPasswordSync('admin123');
  const user1PasswordHash = hashPasswordSync('user123');
  const user2PasswordHash = hashPasswordSync('user123');

  const users: User[] = [
    {
      id: 'usr_admin',
      name: 'MBMC Health Admin',
      emailOrPhone: 'admin@arogyasetu.mbmc.gov.in',
      passwordHash: adminPasswordHash,
      role: 'admin',
      preferredLanguage: 'mr',
      locality: 'Bhayandar West',
      age: 42,
      gender: 'Male',
      emergencyContact: '022-28112233',
      createdAt: '2026-08-01T09:00:00Z',
    },
    {
      id: 'usr_sarita',
      name: 'Sarita Sharma',
      emailOrPhone: '9820123456',
      passwordHash: user1PasswordHash,
      role: 'resident',
      preferredLanguage: 'hi',
      locality: 'Mira Road East',
      age: 63,
      gender: 'Female',
      emergencyContact: '9820987654',
      createdAt: '2026-08-10T10:30:00Z',
    },
    {
      id: 'usr_fatima',
      name: 'Fatima Sheikh',
      emailOrPhone: '9892345678',
      passwordHash: user2PasswordHash,
      role: 'resident',
      preferredLanguage: 'ur',
      locality: 'Naya Nagar',
      age: 38,
      gender: 'Female',
      emergencyContact: '9892001122',
      createdAt: '2026-08-15T14:15:00Z',
    },
  ];

  const advisories: HealthAdvisory[] = [
    {
      id: 'adv_dengue_aug26',
      title: 'Monsoon Dengue & Malaria Alert in Mira Road & Kashimira',
      titleHi: 'मीरा रोड और काशीमीरा में मानसून डेंगू और मलेरिया अलर्ट',
      titleMr: 'मीरा रोड आणि काशिमीरा परिसरात डेंग्यू व मलेरिया साथीचा इशारा',
      titleGu: 'મીરા રોડ અને કાશીમીરામાં ડેન્ગ્યુ અને મેલેરિયા ચેતવણી',
      locality: 'Mira Road East & Kashimira',
      category: 'outbreak',
      severity: 'urgent',
      date: '2026-08-28',
      medicalText: 'The MBMC Health Dept has observed a 15% increase in Vector-Borne Dengue NS1 antigen and Plasmodium vivax cases in low-lying residential sectors. Immediate source reduction of stagnant water containers, indoor residual pyrethrum spraying, and prompt fever testing via peripheral blood smear/ELISA is strongly advised.',
      simpleText: 'Heavy rains have left standing water where mosquitoes breed. If you or your elders have a sudden high fever, severe headache, behind-the-eye pain, or body rash, visit the nearest MBMC municipal clinic immediately. Empty all coolers, coconut shells, and water drums every Sunday.',
      simpleTextHi: 'भारी बारिश के कारण जमा पानी में मच्छर पनप रहे हैं। अगर तेज बुखार, सिरदर्द, आंखों के पीछे दर्द या शरीर पर दाने हों, तो तुरंत नजदीकी नगरपालिका दवाखाने जाएं। घर के आसपास गमलों और बर्तनों में पानी न जमने दें।',
      simpleTextMr: 'पावसामुळे साचलेल्या पाण्यात डासांची पैदास होत आहे. अचानक ताप, अंगदुखी किंवा डोकेदुखी असल्यास ताबडतोब जवळच्या महापालिका दवाखान्यात मोफत तपासणी करा. घरात व आजूबाजूला पाणी साचू देऊ नका.',
      simpleTextGu: 'વરસાદના કારણે ભરાયેલા પાણીમાં મચ્છર થાય છે. જો અચાનક તાવ, માથાનો દુખાવો કે શરીરે કળતર થાય તો તરત પાલિકા દવાખાને જાવ. ઘર પાસે પાણી ભરાવા ન દો.',
      symptoms: ['Sudden high fever', 'Pain behind eyes', 'Severe joint & muscle ache', 'Skin rash', 'Extreme fatigue'],
      precautions: ['Use mosquito nets & repellent coils', 'Wear full-sleeve cotton clothing', 'Cover all indoor water tanks', 'Do not take Aspirin or Ibuprofen without doctor consult (take only Paracetamol for fever)'],
      actionHelpline: '022-28112233 (MBMC Dengue Helpline)',
    },
    {
      id: 'adv_senior_flu_aug26',
      title: 'Free Senior Citizen Flu & Pneumococcal Vaccination Drive',
      titleHi: 'वरिष्ठ नागरिकों के लिए मुफ्त फ्लू और न्यूमोकोकल टीकाकरण अभियान',
      titleMr: 'ज्येष्ठ नागरिकांसाठी मोफत न्यूमोनिया व फ्लू लसीकरण मोहीम',
      titleGu: 'વરિષ્ઠ નાગરિકો માટે મફત ફ્લૂ અને ન્યુમોનિયા રસીકરણ',
      locality: 'All Mira Bhayandar',
      category: 'elderly',
      severity: 'info',
      date: '2026-08-25',
      medicalText: 'MBMC Health Department announces subsidized and free Influenza and 13-valent Pneumococcal Conjugate Vaccine (PCV) for residents aged 60+ and those with chronic pulmonary conditions to prevent secondary bacterial pneumonia during seasonal climate shifts.',
      simpleText: 'All elders aged 60 and above can get free protection against seasonal chest infections and severe flu. Free vaccines are available at Indira Gandhi Civil Hospital and Temba Hospital this week.',
      simpleTextHi: '60 वर्ष से अधिक उम्र के सभी बुजुर्गों को मौसमी खांसी, सीने में जकड़न और फ्लू से बचाव के लिए मुफ्त टीका लगाया जा रहा है। इंदिरा गांधी अस्पताल और तेंभा अस्पताल में उपलब्ध है।',
      simpleTextMr: '६० वर्षांवरील सर्व ज्येष्ठ नागरिकांसाठी छातीतील संसर्ग व फ्लूपासून बचावासाठी मोफत लस उपलब्ध आहे. जवळच्या तेंभा किंवा इंदिरा गांधी रुग्णालयात संपर्क साधा.',
      simpleTextGu: '૬૦ વર્ષથી વધુ ઉંમરના વડીલો માટે ફ્લૂ અને ન્યુમોનિયાથી બચવા મફત રસી ઉપલબ્ધ છે.',
      symptoms: ['Persistent dry cough', 'Breathlessness in humid weather', 'Mild chest tightness', 'Wheezing'],
      precautions: ['Drink lukewarm boiled water', 'Get vaccinated before September', 'Avoid early morning cold mist walks without warm clothing'],
      actionHelpline: '1800-22-2026 (Toll-Free Senior Desk)',
    },
    {
      id: 'adv_maternal_anaemia',
      title: 'Special Maternal Nutrition & Anaemia Screening Camps for Women',
      titleHi: 'महिलाओं के लिए विशेष मातृत्व पोषण और एनीमिया जांच शिविर',
      titleMr: 'महिला व गरोदर मातांसाठी विशेष पोषण व हिमोग्लोबिन तपासणी शिबीर',
      titleGu: 'મહિલાઓ અને સગર્ભા માતાઓ માટે એનિમિયા તપાસ કેમ્પ',
      locality: 'Naya Nagar & Bhayandar West',
      category: 'maternal',
      severity: 'warning',
      date: '2026-08-22',
      medicalText: 'Routine surveillance identified elevated incidence of microcytic hypochromic anaemia (Hb < 10.5 g/dL) among pregnant and lactating women in informal settlements. MBMC is dispensing free daily elemental iron-folic acid tablets and conducting spot hemoglobinometer tests.',
      simpleText: 'Pregnant sisters and mothers: If you feel tired quickly, get dizzy, or look pale, your blood level (hemoglobin) might be low. Visit our free women checkup camp for free blood tests and iron syrup/tablets.',
      simpleTextHi: 'गर्भवती बहनों और माताओं के लिए: अगर जल्दी थकावट या चक्कर आए तो तुरंत मुफ्त खून की जांच कराएं। नगर पालिका सभी को मुफ्त आयरन की गोलियां दे रही है।',
      simpleTextMr: 'गरोदर माता व भगिनींनो: चक्कर येणे किंवा लवकर थकवा जाणवत असल्यास मोफत हिमोग्लोबिन चाचणी करून घ्या व मोफत आयर्नच्या गोळ्या मिळवा.',
      simpleTextGu: 'સગર્ભા બહેનો માટે: જો ચક્કર કે થાક લાગે તો મફત લોહીની તપાસ કરાવો અને મફત આયર્ન ગોળીઓ મેળવો.',
      symptoms: ['Extreme fatigue', 'Pale nails and inner eyelids', 'Dizziness while standing', 'Shortness of breath on mild walking'],
      precautions: ['Eat green leafy vegetables (Palak, Methi, Moringa)', 'Take Iron tablet with Lemon water, never with Tea or Milk', 'Attend monthly antenatal checkups'],
      actionHelpline: '104 (Health Helpline Maharashtra)',
    },
    {
      id: 'adv_waterborne_uttan',
      title: 'Drinking Water Safety Notice & ORS Distribution in Coastal Uttan & Gorai border',
      titleHi: 'उत्तन और तटीय क्षेत्रों में पीने के पानी की सुरक्षा और ओआरएस वितरण',
      titleMr: 'उत्तन सागरी पट्ट्यात पिण्याच्या पाण्याची खबरदारी व ओआरएस वाटप',
      titleGu: 'ઉત્તન વિસ્તારમાં પીવાના પાણીની સાવચેતી અને ઓઆરએસ વિતરણ',
      locality: 'Uttan & Bhayandar West',
      category: 'monsoon',
      severity: 'warning',
      date: '2026-08-18',
      medicalText: 'Post-high tide subterranean pipe seepage has caused sporadic acute gastroenteritis. Citizens are instructed to boil potable water to 100°C rolling boil and utilize supplied chlorine tablets (0.5 mg/L residual).',
      simpleText: 'Drink only boiled or filtered water. If anyone experiences loose motions or vomiting, give them ORS solution (1 packet in 1 liter clean water) immediately to prevent dehydration.',
      simpleTextHi: 'कृपया पानी उबालकर ही पिएं। उल्टी या दस्त होने पर तुरंत ओआरएस (ORS) का घोल पिलाएं ताकि शरीर में पानी की कमी न हो।',
      simpleTextMr: 'पाणी नेहमी उकळून व गाळून प्या. जुलाब किंवा उलट्या झाल्यास लगेच ओआरएस चे पाणी द्या.',
      simpleTextGu: 'પાણી ઉકાળીને જ પીવો. ઝાડા-ઉલટી થાય તો તરત ઓઆરએસનું પાણી પીવડાવો.',
      symptoms: ['Frequent watery stools', 'Abdominal cramps', 'Vomiting', 'Dry mouth and sunken eyes'],
      precautions: ['Boil drinking water for 10 minutes', 'Wash hands with soap before eating and cooking', 'Collect free chlorine drops from local Anganwadi'],
      actionHelpline: '022-28114455 (Uttan Health Post)',
    },
    {
      id: 'adv_diabetes_hypertension',
      title: 'Free Monthly BP & Sugar Screening at All Ward Offices',
      titleHi: 'सभी वार्ड कार्यालयों में बीपी और शुगर की मुफ्त मासिक जांच',
      titleMr: 'सर्व प्रभाग समिती कार्यालयांत मोफत बीपी व शुगर तपासणी',
      titleGu: 'તમામ વોર્ડ ઓફિસમાં બીપી અને સુગરની મફત તપાસ',
      locality: 'All Mira Bhayandar',
      category: 'general',
      severity: 'info',
      date: '2026-08-15',
      medicalText: 'Non-Communicable Disease (NCD) cell conducts free random blood glucose (RBG) and digital sphygmomanometer screening every Saturday from 8 AM to 12 PM for early detection of essential hypertension and Type 2 Diabetes.',
      simpleText: 'Check your Blood Pressure and Sugar for free every Saturday morning at your nearby ward office. Early checkup prevents heart attacks and kidney problems.',
      simpleTextHi: 'हर शनिवार सुबह अपने नजदीकी वार्ड ऑफिस में मुफ्त बीपी और शुगर की जांच कराएं। समय पर जांच से सेहत ठीक रहती है।',
      simpleTextMr: 'प्रत्येक शनिवारी सकाळी जवळच्या प्रभाग कार्यालयात मोफत रक्तदाब व मधुमेह तपासणी करून घ्या.',
      simpleTextGu: 'દર શનિવારે સવારે નજીકની વોર્ડ ઓફિસમાં મફત બીપી અને સુગર ચેક કરાવો.',
      symptoms: ['Excessive thirst', 'Frequent night urination', 'Blurred vision', 'Morning headaches'],
      precautions: ['Reduce dietary salt and fried farsan', 'Walk for 30 minutes daily', 'Never skip your prescribed daily tablets'],
      actionHelpline: '022-28197700 (MBMC NCD Desk)',
    },
    {
      id: 'adv_child_immunization',
      title: 'Mission Indradhanush Intensified: Zero Dose & Dropout Catch-up',
      titleHi: 'मिशन इंद्रधनुष: छूटे हुए बच्चों के लिए विशेष टीकाकरण',
      titleMr: 'मिशन इंद्रधनुष्य: बालकांसाठी विशेष लसीकरण मोहीम',
      titleGu: 'મિશન ઇન્દ્રધનુષ: બાળકો માટે વિશેષ રસીકરણ અભિયાન',
      locality: 'Shanti Nagar, Naya Nagar & Jesal Park',
      category: 'vaccination',
      severity: 'info',
      date: '2026-08-10',
      medicalText: 'Intensified Mission Indradhanush (IMI 6.0) targeting children 0-5 years who missed Pentavalent (DTP-HepB-Hib), Rotavirus, IPV, and Measles-Rubella (MR) vaccines.',
      simpleText: 'Did your young child miss any routine injection due to rain or travel? Bring your child immunization card to your nearest Anganwadi this Wednesday for free catch-up vaccination.',
      simpleTextHi: 'क्या आपके 0 से 5 साल के बच्चे का कोई टीका छूट गया है? इस बुधवार अपने बच्चे को लेकर नजदीकी आंगनवाड़ी आएं और मुफ्त टीका लगवाएं।',
      simpleTextMr: 'तुमच्या लहान बाळाची कोणती लस राहिली आहे का? या बुधवारी अंगणवाडी केंद्रात जाऊन मोफत लस टोचून घ्या.',
      simpleTextGu: 'શું તમારા બાળકનું રસીકરણ બાકી છે? આ બુધવારે નજીકની આંગણવાડીમાં જઈ રસી અપાવો.',
      symptoms: ['High fever with skin blotches', 'Barking cough', 'Severe cold & red eyes in infants'],
      precautions: ['Always keep the Mamta / Immunization Card safe', 'Do not delay vaccine due to mild cold'],
      actionHelpline: '1075 (National Vaccine Helpline)',
    },
  ];

  const camps: VaccinationCamp[] = [
    {
      id: 'camp_temba_aug31',
      name: 'MBMC Grand Senior Citizen Flu & Booster Camp',
      locality: 'Bhayandar West',
      address: 'Temba Municipal Hospital Ground Floor OPD, Subhash Chandra Bose Marg, Near Railway Station',
      landmark: 'Opposite Bhayandar West Railway Ticket Counter',
      date: '2026-08-31',
      timeRange: '09:00 AM - 01:30 PM',
      targetGroup: 'elderly',
      vaccinesOffered: ['Senior Flu / Influenza', 'Pneumococcal PCV', 'COVID Precautionary Booster', 'BP & Sugar Checkup'],
      totalSlots: 35,
      availableSlots: 14,
      contactNumber: '022-28191244',
      googleMapsUrl: 'https://maps.google.com/?q=Temba+Hospital+Bhayandar+West',
      status: 'upcoming',
    },
    {
      id: 'camp_nayanagar_sep02',
      name: 'Mothers & Infants Immunization & Nutrition Camp',
      locality: 'Naya Nagar',
      address: 'Community Hall, Near Millat Nagar Gate, Naya Nagar Road, Mira Road East',
      landmark: 'Next to Naya Nagar Police Chowki',
      date: '2026-09-02',
      timeRange: '10:00 AM - 03:00 PM',
      targetGroup: 'children',
      vaccinesOffered: ['MR (Measles-Rubella)', 'Polio Drops (bOPV)', 'Pentavalent Booster', 'Vitamin A Drops'],
      totalSlots: 40,
      availableSlots: 22,
      contactNumber: '022-28117890',
      googleMapsUrl: 'https://maps.google.com/?q=Naya+Nagar+Community+Hall+Mira+Road',
      status: 'upcoming',
    },
    {
      id: 'camp_kashimira_sep03',
      name: 'Kashimira Highway Free Tetanus & Health Check Camp',
      locality: 'Kashimira',
      address: 'MBMC Health Post, Near Kashimira Flyover Junction, Western Express Highway',
      landmark: 'Behind Kashimira Municipal School No. 4',
      date: '2026-09-03',
      timeRange: '09:30 AM - 02:00 PM',
      targetGroup: 'all',
      vaccinesOffered: ['Td (Tetanus-Diphtheria)', 'Hepatitis B', 'Free General Health & Blood Checkup'],
      totalSlots: 30,
      availableSlots: 18,
      contactNumber: '022-28456677',
      googleMapsUrl: 'https://maps.google.com/?q=Kashimira+Municipal+Health+Post',
      status: 'upcoming',
    },
    {
      id: 'camp_shantinagar_sep05',
      name: 'Women Wellness & Cervical/Maternal Health Drive',
      locality: 'Mira Road East',
      address: 'Shanti Nagar Sector 3 Community Center, Near Jain Temple',
      landmark: 'Close to Shanti Nagar Garden',
      date: '2026-09-05',
      timeRange: '10:00 AM - 04:00 PM',
      targetGroup: 'pregnant_women',
      vaccinesOffered: ['Td (Tetanus in Pregnancy)', 'Rubella for young women', 'Free Hemoglobin & Thyroid Screening'],
      totalSlots: 30,
      availableSlots: 11,
      contactNumber: '022-28123344',
      googleMapsUrl: 'https://maps.google.com/?q=Shanti+Nagar+Sector+3+Mira+Road',
      status: 'upcoming',
    },
    {
      id: 'camp_uttan_sep07',
      name: 'Coastal Fisherfolk & Elderly Mobile Health Outreach',
      locality: 'Uttan',
      address: 'St. Andrews Parish Hall, Uttan Coastal Road, Bhayandar West',
      landmark: 'Near Uttan Beach Jetty',
      date: '2026-09-07',
      timeRange: '08:30 AM - 01:00 PM',
      targetGroup: 'elderly',
      vaccinesOffered: ['Pneumonia Vaccine', 'Seasonal Flu', 'Joint Pain & Arthritis Consultation', 'Eye Checkup'],
      totalSlots: 25,
      availableSlots: 19,
      contactNumber: '022-28145522',
      googleMapsUrl: 'https://maps.google.com/?q=Uttan+Bhayandar+West',
      status: 'upcoming',
    },
    {
      id: 'camp_jesalpark_sep09',
      name: 'Jesal Park Family Wellness & Typhoid Protection Camp',
      locality: 'Bhayandar East',
      address: 'MBMC Primary Health Center, Near Jesal Park Chowpatty, Bhayandar East',
      landmark: 'Adjacent to Balasaheb Thackeray Garden',
      date: '2026-09-09',
      timeRange: '09:00 AM - 02:00 PM',
      targetGroup: 'all',
      vaccinesOffered: ['Typhoid Conjugate (TCV)', 'Hepatitis A', 'Dengue Rapid Platelet Count Test'],
      totalSlots: 30,
      availableSlots: 26,
      contactNumber: '022-28189911',
      googleMapsUrl: 'https://maps.google.com/?q=Jesal+Park+Bhayandar+East',
      status: 'upcoming',
    },
  ];

  const hospitals: Hospital[] = [
    {
      id: 'hosp_indira_gandhi',
      name: 'Bharat Ratna Indira Gandhi Municipal Civil Hospital (MBMC)',
      type: 'Municipal Hospital (MBMC)',
      locality: 'Mira Road East',
      address: 'Near Shanti Park, Off Kanakia Road, Mira Road East, Mira Bhayandar 401107',
      landmark: 'Opposite Shanti Park Police Station',
      latitude: 19.2825,
      longitude: 72.8682,
      contactNumber: '022-28114400',
      emergencyNumber: '022-28114411',
      specialties: ['General Medicine', 'Pediatrics', 'Gynecology & Obstetrics', 'Orthopedics', 'ENT', 'Ophthalmology', 'Cardiology (OPD)'],
      facilities: ['24x7 Emergency Casualty', 'Free OPD & Medicines', 'Digital X-Ray & Sonography', 'ICU & NICU', 'Blood Storage Unit', 'Ayushman Bharat Card Counter'],
      opdTimings: 'Monday - Saturday: 8:00 AM - 1:00 PM & 4:00 PM - 7:00 PM',
      isFreeGovt: true,
      appointmentSlots: [
        { slotId: 'ig_s1', time: '09:00 AM', date: '2026-08-31', doctorName: 'Dr. Vivek Mane (MD Gen Med)', specialty: 'General Medicine', isAvailable: true },
        { slotId: 'ig_s2', time: '10:30 AM', date: '2026-08-31', doctorName: 'Dr. Anjali Patil (DGO)', specialty: 'Gynecology & Obstetrics', isAvailable: true },
        { slotId: 'ig_s3', time: '11:45 AM', date: '2026-08-31', doctorName: 'Dr. Rajesh Kothari (DCH)', specialty: 'Pediatrics', isAvailable: false },
        { slotId: 'ig_s4', time: '04:30 PM', date: '2026-08-31', doctorName: 'Dr. Sameer Deshmukh (MS Ortho)', specialty: 'Orthopedics', isAvailable: true },
        { slotId: 'ig_s5', time: '09:30 AM', date: '2026-09-01', doctorName: 'Dr. Vivek Mane (MD Gen Med)', specialty: 'General Medicine', isAvailable: true },
        { slotId: 'ig_s6', time: '11:00 AM', date: '2026-09-01', doctorName: 'Dr. Anjali Patil (DGO)', specialty: 'Gynecology & Obstetrics', isAvailable: true },
      ],
    },
    {
      id: 'hosp_temba',
      name: 'Temba Municipal General Hospital (MBMC)',
      type: 'Municipal Hospital (MBMC)',
      locality: 'Bhayandar West',
      address: 'Subhash Chandra Bose Road, Near Railway Station, Bhayandar West, Mira Bhayandar 401101',
      landmark: '2 minutes walk from Bhayandar Railway Station (Platform 1)',
      latitude: 19.3082,
      longitude: 72.8491,
      contactNumber: '022-28191244',
      emergencyNumber: '022-28191200',
      specialties: ['General Medicine', 'Pediatrics', 'General Surgery', 'Obstetrics', 'Dental Clinic', 'Physiotherapy'],
      facilities: ['24x7 Trauma Care', 'Free Pathology Lab', 'Maternity Ward', 'Dialysis Center', 'Ambulance 108 Base'],
      opdTimings: 'Daily: 8:30 AM - 1:30 PM & 4:30 PM - 8:00 PM',
      isFreeGovt: true,
      appointmentSlots: [
        { slotId: 'tb_s1', time: '09:15 AM', date: '2026-08-31', doctorName: 'Dr. Pradeep Chougule (MBBS)', specialty: 'General Medicine', isAvailable: true },
        { slotId: 'tb_s2', time: '10:45 AM', date: '2026-08-31', doctorName: 'Dr. Meena Nair (MD Paed)', specialty: 'Pediatrics', isAvailable: true },
        { slotId: 'tb_s3', time: '05:00 PM', date: '2026-08-31', doctorName: 'Dr. Sandeep Joshi (BDS)', specialty: 'Dental Clinic', isAvailable: true },
        { slotId: 'tb_s4', time: '10:00 AM', date: '2026-09-01', doctorName: 'Dr. Pradeep Chougule (MBBS)', specialty: 'General Medicine', isAvailable: true },
      ],
    },
    {
      id: 'hosp_wockhardt',
      name: 'Wockhardt Super Specialty Hospital Mira Road',
      type: 'Private Hospital',
      locality: 'Mira Road East',
      address: 'The Umrao IMSR Building, Near Railway Station, Mira Road East, 401107',
      landmark: 'Near Rassaz Mall & Shanti Nagar Crossing',
      latitude: 19.2788,
      longitude: 72.8619,
      contactNumber: '022-68744444',
      emergencyNumber: '022-68744100',
      specialties: ['Cardiology', 'Neurology', 'Oncology', 'Joint Replacement', 'Gastroenterology', 'Critical Care'],
      facilities: ['24x7 Cardiac Emergency', 'Advanced Cath Lab', 'CT / MRI 3T', 'Cashless TPA & Ayushman desk', 'Organ Transplant Support'],
      opdTimings: 'Monday - Saturday: 9:00 AM - 8:00 PM',
      isFreeGovt: false,
      appointmentSlots: [
        { slotId: 'wk_s1', time: '11:00 AM', date: '2026-08-31', doctorName: 'Dr. Chetan Bhambure (DM Cardio)', specialty: 'Cardiology', isAvailable: true },
        { slotId: 'wk_s2', time: '03:30 PM', date: '2026-08-31', doctorName: 'Dr. Pavan Pai (DM Neuro)', specialty: 'Neurology', isAvailable: true },
        { slotId: 'wk_s3', time: '10:00 AM', date: '2026-09-01', doctorName: 'Dr. Imran Khan (MD Gen Med)', specialty: 'General Medicine', isAvailable: true },
      ],
    },
    {
      id: 'hosp_nayanagar_uphc',
      name: 'MBMC Urban Primary Health Post & Maternity Home Naya Nagar',
      type: 'Community Health Center',
      locality: 'Naya Nagar',
      address: 'Plot 14, Near Naya Nagar Jama Masjid, Mira Road East 401107',
      landmark: 'Near Al-Shams Mosque',
      latitude: 19.2871,
      longitude: 72.8595,
      contactNumber: '022-28117890',
      emergencyNumber: '022-28117891',
      specialties: ['Mother & Child Care', 'Vaccination', 'General OPD', 'Family Planning & Counselling', 'Tuberculosis & DOTS Center'],
      facilities: ['Free Antenatal Checkups', 'Free Baby Vaccines', 'Iron & Vitamin Distribution', 'Clean Delivery Suites'],
      opdTimings: 'Monday - Saturday: 8:00 AM - 2:00 PM',
      isFreeGovt: true,
      appointmentSlots: [
        { slotId: 'nn_s1', time: '08:30 AM', date: '2026-08-31', doctorName: 'Dr. Yasmin Qureshi (MBBS, DGO)', specialty: 'Mother & Child Care', isAvailable: true },
        { slotId: 'nn_s2', time: '11:30 AM', date: '2026-08-31', doctorName: 'Dr. Yasmin Qureshi (MBBS, DGO)', specialty: 'Mother & Child Care', isAvailable: true },
        { slotId: 'nn_s3', time: '09:00 AM', date: '2026-09-01', doctorName: 'Dr. Zoya Khan (MBBS)', specialty: 'General OPD', isAvailable: true },
      ],
    },
    {
      id: 'hosp_kashimira_chc',
      name: 'Kashimira Community Health Center & Trauma Care',
      type: 'Community Health Center',
      locality: 'Kashimira',
      address: 'Behind Kashimira Checkpost, WE Highway, Mira Bhayandar 401104',
      landmark: 'Near Kashimira Flyover & Silver Park Link',
      latitude: 19.2684,
      longitude: 72.8765,
      contactNumber: '022-28456677',
      emergencyNumber: '022-28456688',
      specialties: ['Emergency Trauma Care', 'General Medicine', 'Dog Bite & Anti-Rabies Center', 'Snake Bite Antivenom Center', 'Pediatrics'],
      facilities: ['24x7 Anti-Rabies Vaccine (ARV)', 'Emergency Wound Stitching', 'Free Tetanus Shots', 'Minor OT'],
      opdTimings: '24 Hours Emergency / General OPD: 9:00 AM - 1:00 PM',
      isFreeGovt: true,
      appointmentSlots: [
        { slotId: 'km_s1', time: '09:30 AM', date: '2026-08-31', doctorName: 'Dr. Harish Salve (MBBS)', specialty: 'General Medicine', isAvailable: true },
        { slotId: 'km_s2', time: '12:00 PM', date: '2026-08-31', doctorName: 'Dr. Harish Salve (MBBS)', specialty: 'Anti-Rabies / Wound Clinic', isAvailable: true },
        { slotId: 'km_s3', time: '10:00 AM', date: '2026-09-01', doctorName: 'Dr. Harish Salve (MBBS)', specialty: 'General Medicine', isAvailable: true },
      ],
    },
    {
      id: 'hosp_bhaktivedanta',
      name: 'BhaktiVedanta Hospital & Research Institute',
      type: 'Trust Hospital',
      locality: 'Mira Road East',
      address: 'Srishti Complex, Sector 1, Mira Road East, Mira Bhayandar 401107',
      landmark: 'Near Royal College of Arts & Science',
      latitude: 19.2942,
      longitude: 72.8711,
      contactNumber: '022-29452500',
      emergencyNumber: '022-29452525',
      specialties: ['Cardiology', 'Nephrology & Dialysis', 'Eye Care & Cataract', 'Ayurveda & Integrative Medicine', 'Geriatric Care (Elderly)'],
      facilities: ['Subsidized Charitable Wards', 'Free Senior Cataract Surgeries', 'Holistic Elderly Wellness Clinic', 'Home Care Service'],
      opdTimings: 'Monday - Saturday: 8:00 AM - 7:00 PM',
      isFreeGovt: false,
      appointmentSlots: [
        { slotId: 'bv_s1', time: '10:00 AM', date: '2026-08-31', doctorName: 'Dr. Girish Trivedi (MD Geriatrics)', specialty: 'Geriatric Care (Elderly)', isAvailable: true },
        { slotId: 'bv_s2', time: '02:00 PM', date: '2026-08-31', doctorName: 'Dr. Sneha Rane (MS Ophthal)', specialty: 'Eye Care & Cataract', isAvailable: true },
        { slotId: 'bv_s3', time: '11:00 AM', date: '2026-09-01', doctorName: 'Dr. Girish Trivedi (MD Geriatrics)', specialty: 'Geriatric Care (Elderly)', isAvailable: true },
      ],
    },
  ];

  const commonMedicines: Record<string, MedicineInfo> = {
    paracetamol: {
      name: 'Paracetamol 650mg / Dolo 650',
      genericName: 'Paracetamol (Acetaminophen)',
      category: 'Fever & Pain Relief',
      simplePurpose: 'Used to bring down high body fever and relieve mild-to-moderate body pain, headache, and joint aches during viral infections or dengue/flu.',
      dosageNotes: 'For adults: 1 tablet after meals when fever is above 100°F. Keep gap of at least 6 hours between tablets. Maximum 3-4 tablets in 24 hours.',
      commonSideEffects: ['Usually very safe when taken in correct dose', 'Nausea if taken on an empty stomach', 'Do NOT exceed dose as excess damages liver'],
      precautions: ['Do not drink alcohol with Paracetamol', 'Avoid taking multiple cold syrups at the same time containing hidden paracetamol', 'Safe for elderly and pregnant women in recommended dose'],
      requiresDoctorPrescription: false,
      disclaimer: 'Always consult your municipal doctor if fever stays for more than 48 hours without dropping.',
    },
    amoxicillin: {
      name: 'Amoxicillin 500mg (Mox 500)',
      genericName: 'Amoxicillin Trihydrate',
      category: 'Antibiotic (Bacterial Infection)',
      simplePurpose: 'Antibiotic medicine that kills bacteria causing throat infections, chest bronchitis, ear infections, and skin boils. Does NOT cure common viral cold or flu.',
      dosageNotes: 'Take exactly as prescribed by doctor (usually 1 capsule three times daily for 5 full days). Complete full course even if you start feeling better.',
      commonSideEffects: ['Mild loose motions / diarrhoea', 'Nausea', 'Mild skin rash in allergic individuals'],
      precautions: ['Tell your doctor if you are allergic to Penicillin', 'Drink plenty of water', 'Do not stop course midway as bacteria become resistant'],
      requiresDoctorPrescription: true,
      disclaimer: 'Antibiotics require a valid doctor prescription. Never take for simple viral cold or runny nose.',
    },
    metformin: {
      name: 'Metformin 500mg / Glycomet 500',
      genericName: 'Metformin Hydrochloride',
      category: 'Diabetes (Blood Sugar Control)',
      simplePurpose: 'Helps lower high blood sugar levels in people with Type 2 Diabetes by improving insulin response and reducing sugar made by the liver.',
      dosageNotes: 'Usually 1 tablet with or immediately after main meals (lunch/dinner) to prevent stomach upset.',
      commonSideEffects: ['Mild stomach gas or bloating in first week', 'Metallic taste in mouth', 'Mild nausea'],
      precautions: ['Do not skip meals after taking tablet', 'Get kidney function checked yearly', 'Inform doctor if feeling severe muscle weakness'],
      requiresDoctorPrescription: true,
      disclaimer: 'Do not alter your diabetes medicine dosage without checking your fasting and post-meal sugar levels with your doctor.',
    },
    amlodipine: {
      name: 'Amlodipine 5mg (Amlong / Stamlo)',
      genericName: 'Amlodipine Besylate',
      category: 'Blood Pressure & Heart',
      simplePurpose: 'Relaxes and widens blood vessels so blood flows easily, lowering high blood pressure and reducing heart strain.',
      dosageNotes: 'Take 1 tablet daily at the same time every morning with water, with or without food.',
      commonSideEffects: ['Mild swelling in ankles or feet if standing long', 'Dizziness when standing up suddenly', 'Warm flushing sensation in face'],
      precautions: ['Do not stop taking abruptly even if you feel completely fine (BP has no symptoms)', 'Avoid high salt snacks', 'Check BP weekly'],
      requiresDoctorPrescription: true,
      disclaimer: 'Blood pressure medication must be taken lifelong unless changed by a certified physician.',
    },
    cetirizine: {
      name: 'Cetirizine 10mg (Cetzine / Okacet)',
      genericName: 'Cetirizine Hydrochloride',
      category: 'Allergy & Cold Relief',
      simplePurpose: 'Relieves allergy symptoms like sneezing, runny nose, itchy watery eyes, insect bites, and allergic skin hives.',
      dosageNotes: 'Take 1 tablet at night before sleeping as it may cause slight sleepiness.',
      commonSideEffects: ['Mild drowsiness', 'Dry mouth', 'Tiredness'],
      precautions: ['Avoid driving or operating machinery after taking', 'Elderly should start with 5mg dose', 'Avoid alcohol'],
      requiresDoctorPrescription: false,
      disclaimer: 'Consult a doctor if allergic hives spread rapidly or cause breathing difficulty.',
    },
    pantoprazole: {
      name: 'Pantoprazole 40mg (Pan 40 / Pantocid)',
      genericName: 'Pantoprazole Sodium',
      category: 'Antacid & Acid Reflux',
      simplePurpose: 'Reduces excess acid produced in your stomach. Helps heal stomach ulcers, burning sensation in chest (heartburn), and acidity.',
      dosageNotes: 'Swallow 1 tablet whole with water in the morning 30 minutes before breakfast on an empty stomach. Do not crush or chew.',
      commonSideEffects: ['Headache', 'Mild stomach discomfort', 'Diarrhoea in rare cases'],
      precautions: ['Do not use continuously for months without medical supervision', 'Avoid spicy, oily dinner', 'Elevate pillows if acidity flares at night'],
      requiresDoctorPrescription: false,
      disclaimer: 'If chest burning is accompanied by left arm pain or sweating, treat as a cardiac emergency and call 108.',
    },
    ors: {
      name: 'ORS Electrolyte Powder (WHO Formula)',
      genericName: 'Oral Rehydration Salts',
      category: 'Dehydration & Diarrhoea',
      simplePurpose: 'Restores essential water and minerals (salts) lost during watery loose motions, vomiting, or heavy sweating in hot weather.',
      dosageNotes: 'Dissolve 1 entire packet in exactly 1 litre of clean boiled and cooled drinking water. Drink small sips continuously. Discard leftover solution after 24 hours.',
      commonSideEffects: ['None when mixed in the correct volume of water'],
      precautions: ['Do not mix with milk, soup, or fruit juice — use only clean water', 'Do not add extra sugar or salt', 'Safe for all infants, pregnant women, and elderly'],
      requiresDoctorPrescription: false,
      disclaimer: 'Life-saving first aid during loose motions. If patient cannot drink or becomes drowsy, rush to the hospital immediately.',
    },
    azithromycin: {
      name: 'Azithromycin 500mg (Azee 500 / Zithrox)',
      genericName: 'Azithromycin Dihydrate',
      category: 'Antibiotic (Chest & Throat)',
      simplePurpose: 'Used to treat severe bacterial chest infections, tonsillitis, sinusitis, and skin infections.',
      dosageNotes: 'Usually 1 tablet once daily 1 hour before or 2 hours after food for 3 or 5 consecutive days.',
      commonSideEffects: ['Stomach ache', 'Nausea', 'Soft stools'],
      precautions: ['Complete the entire 3-5 day strip', 'Tell doctor if you have heart rhythm issues', 'Do not take antacids at the same time'],
      requiresDoctorPrescription: true,
      disclaimer: 'Must be taken under doctor prescription only.',
    },
    telmisartan: {
      name: 'Telmisartan 40mg (Telma 40)',
      genericName: 'Telmisartan',
      category: 'Blood Pressure & Kidney Protection',
      simplePurpose: 'Lowers high blood pressure and protects kidneys in diabetic and hypertensive patients.',
      dosageNotes: '1 tablet once daily morning or evening with a glass of water.',
      commonSideEffects: ['Mild dizziness', 'Back pain', 'Sinus congestion'],
      precautions: ['Not for pregnant women', 'Monitor serum potassium levels periodically', 'Avoid potassium-rich salt substitutes without consult'],
      requiresDoctorPrescription: true,
      disclaimer: 'Consult your cardiologist or MBMC physician.',
    },
    folic_iron: {
      name: 'Iron & Folic Acid Tablet (IFA - Red/Blue)',
      genericName: 'Ferrous Ascorbate + Folic Acid',
      category: 'Maternal Nutrition & Blood Building',
      simplePurpose: 'Increases blood hemoglobin levels, prevents anaemia in women, and supports healthy baby development in pregnant mothers.',
      dosageNotes: '1 tablet daily after food with water or lemonade. Never take with tea or milk as calcium stops iron absorption.',
      commonSideEffects: ['Stools may turn dark/black (this is normal and harmless)', 'Mild constipation or nausea'],
      precautions: ['Drink 8-10 glasses of water daily', 'Eat fiber like leafy greens, guava, and bananas', 'Free supplies available at all Anganwadis'],
      requiresDoctorPrescription: false,
      disclaimer: 'Essential for all expecting mothers throughout pregnancy and 6 months after delivery.',
    },
  };

  const pharmacies: Pharmacy[] = [
    {
      id: 'pharm_janaushadhi_mira',
      name: 'Pradhan Mantri Jan Aushadhi Kendra (Subsidized)',
      locality: 'Mira Road East',
      address: 'Shop No. 4, Shanti Shopping Center, Opposite Mira Road Railway Station (East), 401107',
      contactNumber: '022-28119020',
      timings: '08:30 AM - 10:30 PM (All 7 Days)',
      is24Hours: false,
      hasJanAushadhiScheme: true,
      distanceKm: 0.4,
      inventory: [
        { medicineId: 'paracetamol', name: 'Paracetamol 650mg (Jan Aushadhi)', genericName: 'Paracetamol', category: 'Fever & Pain Relief', status: 'In Stock', price: '₹14 (Strip of 10)', discountGovt: '70% off vs branded' },
        { medicineId: 'amoxicillin', name: 'Amoxicillin 500mg Cap', genericName: 'Amoxicillin', category: 'Antibiotic', status: 'In Stock', price: '₹38 (Strip of 10)', discountGovt: '65% off' },
        { medicineId: 'metformin', name: 'Metformin 500mg SR', genericName: 'Metformin', category: 'Diabetes', status: 'In Stock', price: '₹12 (Strip of 10)', discountGovt: '80% off' },
        { medicineId: 'amlodipine', name: 'Amlodipine 5mg Tab', genericName: 'Amlodipine', category: 'Blood Pressure', status: 'In Stock', price: '₹8 (Strip of 10)', discountGovt: '85% off' },
        { medicineId: 'cetirizine', name: 'Cetirizine 10mg Tab', genericName: 'Cetirizine', category: 'Allergy', status: 'In Stock', price: '₹9 (Strip of 10)', discountGovt: '75% off' },
        { medicineId: 'pantoprazole', name: 'Pantoprazole 40mg Tab', genericName: 'Pantoprazole', category: 'Antacid', status: 'In Stock', price: '₹22 (Strip of 10)', discountGovt: '70% off' },
        { medicineId: 'ors', name: 'ORS Powder WHO Sachet', genericName: 'Oral Rehydration Salts', category: 'Dehydration', status: 'In Stock', price: '₹5 per sachet', discountGovt: '60% off' },
        { medicineId: 'folic_iron', name: 'Iron + Folic Acid (Govt Supply)', genericName: 'Ferrous Ascorbate', category: 'Nutrition', status: 'In Stock', price: '₹15 (Strip of 30)', discountGovt: 'Free with ration card' },
      ],
    },
    {
      id: 'pharm_noble_chemists',
      name: 'Noble 24x7 Chemist & Day-Night Pharmacy',
      locality: 'Bhayandar West',
      address: 'Station Road, Near Temba Hospital Gate, Bhayandar West 401101',
      contactNumber: '022-28193355',
      timings: '24 Hours Open (Day & Night)',
      is24Hours: true,
      hasJanAushadhiScheme: false,
      distanceKm: 0.2,
      inventory: [
        { medicineId: 'paracetamol', name: 'Dolo 650mg / Calpol', genericName: 'Paracetamol', category: 'Fever & Pain Relief', status: 'In Stock', price: '₹34 (Strip of 15)' },
        { medicineId: 'amoxicillin', name: 'Mox 500mg Cap', genericName: 'Amoxicillin', category: 'Antibiotic', status: 'In Stock', price: '₹92 (Strip of 10)' },
        { medicineId: 'metformin', name: 'Glycomet 500mg', genericName: 'Metformin', category: 'Diabetes', status: 'In Stock', price: '₹45 (Strip of 20)' },
        { medicineId: 'amlodipine', name: 'Amlong 5mg Tab', genericName: 'Amlodipine', category: 'Blood Pressure', status: 'In Stock', price: '₹38 (Strip of 15)' },
        { medicineId: 'azithromycin', name: 'Azee 500mg Tab', genericName: 'Azithromycin', category: 'Antibiotic', status: 'In Stock', price: '₹118 (Strip of 5)' },
        { medicineId: 'pantoprazole', name: 'Pan 40mg Tab', genericName: 'Pantoprazole', category: 'Antacid', status: 'In Stock', price: '₹140 (Strip of 15)' },
        { medicineId: 'ors', name: 'Electral ORS Sachet 21.8g', genericName: 'ORS', category: 'Dehydration', status: 'In Stock', price: '₹22 per sachet' },
      ],
    },
    {
      id: 'pharm_apna_nayanagar',
      name: 'Apna Medical & Surgical Store Naya Nagar',
      locality: 'Naya Nagar',
      address: 'Shop No. 7, Near Millat Nagar Gate, Naya Nagar Main Road, 401107',
      contactNumber: '022-28115599',
      timings: '08:00 AM - 11:30 PM',
      is24Hours: false,
      hasJanAushadhiScheme: false,
      distanceKm: 0.8,
      inventory: [
        { medicineId: 'paracetamol', name: 'Dolo 650mg', genericName: 'Paracetamol', category: 'Fever & Pain Relief', status: 'In Stock', price: '₹34 (Strip of 15)' },
        { medicineId: 'cetirizine', name: 'Cetzine 10mg', genericName: 'Cetirizine', category: 'Allergy', status: 'In Stock', price: '₹22 (Strip of 10)' },
        { medicineId: 'amoxicillin', name: 'Novamox 500mg', genericName: 'Amoxicillin', category: 'Antibiotic', status: 'Low Stock', price: '₹88 (Strip of 10)' },
        { medicineId: 'folic_iron', name: 'Autrin Iron Cap', genericName: 'Iron & Folic', category: 'Nutrition', status: 'In Stock', price: '₹110 (Strip of 30)' },
        { medicineId: 'ors', name: 'Enerzal / Electral Sachet', genericName: 'ORS', category: 'Dehydration', status: 'In Stock', price: '₹20' },
      ],
    },
    {
      id: 'pharm_wellness_forever_beverly',
      name: 'Wellness Forever 24x7 Beverly Park',
      locality: 'Mira Road East',
      address: 'Shop 1-3, Beverly Park Junction, Kanakia Road, Mira Road East 401107',
      contactNumber: '022-28128844',
      timings: '24 Hours Open',
      is24Hours: true,
      hasJanAushadhiScheme: false,
      distanceKm: 1.1,
      inventory: [
        { medicineId: 'paracetamol', name: 'Calpol 650mg', genericName: 'Paracetamol', category: 'Fever & Pain Relief', status: 'In Stock', price: '₹32 (Strip of 15)' },
        { medicineId: 'telmisartan', name: 'Telma 40mg Tab', genericName: 'Telmisartan', category: 'Blood Pressure', status: 'In Stock', price: '₹195 (Strip of 30)' },
        { medicineId: 'metformin', name: 'Glycomet GP 1 / 500', genericName: 'Metformin', category: 'Diabetes', status: 'In Stock', price: '₹95 (Strip of 15)' },
        { medicineId: 'azithromycin', name: 'Zithrox 500mg', genericName: 'Azithromycin', category: 'Antibiotic', status: 'In Stock', price: '₹125 (Strip of 5)' },
        { medicineId: 'pantoprazole', name: 'Pantocid 40', genericName: 'Pantoprazole', category: 'Antacid', status: 'In Stock', price: '₹135 (Strip of 15)' },
      ],
    },
    {
      id: 'pharm_shreeji_kashimira',
      name: 'Shreeji Medical & General Stores Kashimira',
      locality: 'Kashimira',
      address: 'Near Kashimira Flyover, Western Express Highway, Kashimira 401104',
      contactNumber: '022-28453311',
      timings: '09:00 AM - 11:00 PM',
      is24Hours: false,
      hasJanAushadhiScheme: true,
      distanceKm: 1.5,
      inventory: [
        { medicineId: 'paracetamol', name: 'Paracetamol 650mg Generic', genericName: 'Paracetamol', category: 'Fever & Pain Relief', status: 'In Stock', price: '₹15 (Strip of 10)' },
        { medicineId: 'amoxicillin', name: 'Amoxycillin Cap', genericName: 'Amoxicillin', category: 'Antibiotic', status: 'Out of Stock', price: '₹40' },
        { medicineId: 'amlodipine', name: 'Amlodipine 5mg', genericName: 'Amlodipine', category: 'Blood Pressure', status: 'In Stock', price: '₹10 (Strip of 10)' },
        { medicineId: 'ors', name: 'ORS Powder Sachet', genericName: 'ORS', category: 'Dehydration', status: 'In Stock', price: '₹8 per sachet' },
      ],
    },
    {
      id: 'pharm_shanti_nagar_chemists',
      name: 'Shanti Nagar Chemists & Druggists',
      locality: 'Mira Road East',
      address: 'Sector 4, Shanti Nagar, Near Post Office, Mira Road East 401107',
      contactNumber: '022-28114422',
      timings: '08:00 AM - 10:30 PM',
      is24Hours: false,
      hasJanAushadhiScheme: false,
      distanceKm: 0.7,
      inventory: [
        { medicineId: 'paracetamol', name: 'Dolo 650', genericName: 'Paracetamol', category: 'Fever & Pain Relief', status: 'In Stock', price: '₹34' },
        { medicineId: 'cetirizine', name: 'Okacet 10mg', genericName: 'Cetirizine', category: 'Allergy', status: 'In Stock', price: '₹20' },
        { medicineId: 'metformin', name: 'Metformin 500mg', genericName: 'Metformin', category: 'Diabetes', status: 'In Stock', price: '₹40' },
        { medicineId: 'pantoprazole', name: 'Pan 40', genericName: 'Pantoprazole', category: 'Antacid', status: 'Low Stock', price: '₹140' },
      ],
    },
    {
      id: 'pharm_uttan_seacoast',
      name: 'Uttan Seacoast Community Pharmacy',
      locality: 'Uttan',
      address: 'Near Uttan Bus Depot, Uttan Church Road, Bhayandar West 401106',
      contactNumber: '022-28147788',
      timings: '08:30 AM - 09:30 PM',
      is24Hours: false,
      hasJanAushadhiScheme: true,
      distanceKm: 3.2,
      inventory: [
        { medicineId: 'paracetamol', name: 'Paracetamol 650 Tab', genericName: 'Paracetamol', category: 'Fever & Pain Relief', status: 'In Stock', price: '₹14' },
        { medicineId: 'ors', name: 'ORS Powder WHO', genericName: 'ORS', category: 'Dehydration', status: 'In Stock', price: '₹6' },
        { medicineId: 'folic_iron', name: 'Iron Folic Acid IFA', genericName: 'Iron & Folic', category: 'Nutrition', status: 'In Stock', price: '₹15' },
        { medicineId: 'amoxicillin', name: 'Amox 500', genericName: 'Amoxicillin', category: 'Antibiotic', status: 'In Stock', price: '₹42' },
      ],
    },
    {
      id: 'pharm_jesal_chemist',
      name: 'Jesal Park Chemist & Medical Store',
      locality: 'Bhayandar East',
      address: 'Shop 2, Jesal Park Chowpatty Road, Bhayandar East 401105',
      contactNumber: '022-28182244',
      timings: '09:00 AM - 11:00 PM',
      is24Hours: false,
      hasJanAushadhiScheme: false,
      distanceKm: 1.8,
      inventory: [
        { medicineId: 'paracetamol', name: 'Dolo 650', genericName: 'Paracetamol', category: 'Fever & Pain Relief', status: 'In Stock', price: '₹34' },
        { medicineId: 'telmisartan', name: 'Telma 40', genericName: 'Telmisartan', category: 'Blood Pressure', status: 'In Stock', price: '₹190' },
        { medicineId: 'metformin', name: 'Glycomet 500', genericName: 'Metformin', category: 'Diabetes', status: 'In Stock', price: '₹44' },
        { medicineId: 'azithromycin', name: 'Azee 500', genericName: 'Azithromycin', category: 'Antibiotic', status: 'In Stock', price: '₹118' },
      ],
    },
  ];

  const bookings: Booking[] = [
    {
      id: 'bk_1001',
      tokenNumber: 'MBMC-CAMP-1042',
      type: 'camp',
      targetId: 'camp_temba_aug31',
      targetName: 'MBMC Grand Senior Citizen Flu & Booster Camp (Bhayandar West)',
      slotDate: '2026-08-31',
      slotTime: '09:30 AM - 10:30 AM',
      specialtyOrVaccine: 'Senior Flu / Influenza & Pneumococcal',
      userName: 'Sarita Sharma',
      userPhone: '9820123456',
      userEmail: 'sarita.sharma@example.com',
      userAge: 63,
      userGender: 'Female',
      userLocality: 'Mira Road East',
      userId: 'usr_sarita',
      status: 'confirmed',
      createdAt: '2026-08-29T08:15:00Z',
    },
    {
      id: 'bk_1002',
      tokenNumber: 'MBMC-HOSP-2098',
      type: 'hospital',
      targetId: 'hosp_indira_gandhi',
      targetName: 'Bharat Ratna Indira Gandhi Municipal Civil Hospital (Mira Road)',
      slotDate: '2026-08-31',
      slotTime: '10:30 AM',
      specialtyOrVaccine: 'Gynecology & Obstetrics',
      doctorName: 'Dr. Anjali Patil (DGO)',
      userName: 'Fatima Sheikh',
      userPhone: '9892345678',
      userAge: 38,
      userGender: 'Female',
      userLocality: 'Naya Nagar',
      userId: 'usr_fatima',
      status: 'confirmed',
      createdAt: '2026-08-29T11:40:00Z',
    },
    {
      id: 'bk_1003',
      tokenNumber: 'MBMC-CAMP-1089',
      type: 'camp',
      targetId: 'camp_nayanagar_sep02',
      targetName: 'Mothers & Infants Immunization & Nutrition Camp (Naya Nagar)',
      slotDate: '2026-09-02',
      slotTime: '10:00 AM - 11:00 AM',
      specialtyOrVaccine: 'MR (Measles-Rubella) & Polio',
      userName: 'Ramesh Patel',
      userPhone: '9819554433',
      userAge: 34,
      userGender: 'Male',
      userLocality: 'Naya Nagar',
      status: 'confirmed',
      createdAt: '2026-08-29T14:20:00Z',
    },
  ];

  const feedback: Feedback[] = [
    {
      id: 'fb_1',
      name: 'Gulshan Kumar',
      phoneOrEmail: '9833441122',
      locality: 'Bhayandar West',
      category: 'camps',
      rating: 5,
      message: 'The Temba Hospital senior camp booking token made it so easy for my 70-year old mother. No long queues in the rain!',
      createdAt: '2026-08-28T16:00:00Z',
    },
    {
      id: 'fb_2',
      name: 'Amina Khatun',
      phoneOrEmail: '9892110044',
      locality: 'Naya Nagar',
      category: 'translation',
      rating: 5,
      message: 'The simple language toggle in Urdu and Hindi helped me understand the dengue advisory very clearly.',
      createdAt: '2026-08-27T10:30:00Z',
    },
  ];

  return {
    users,
    advisories,
    camps,
    hospitals,
    pharmacies,
    medicinesDirectory: commonMedicines,
    bookings,
    feedback,
  };
}

class Database {
  private data: DatabaseSchema;

  constructor() {
    this.ensureDirectory();
    this.data = this.loadData();
  }

  private ensureDirectory() {
    if (!fs.existsSync(DATA_DIR)) {
      fs.mkdirSync(DATA_DIR, { recursive: true });
    }
  }

  private loadData(): DatabaseSchema {
    try {
      if (fs.existsSync(DB_FILE)) {
        const raw = fs.readFileSync(DB_FILE, 'utf-8');
        const parsed = JSON.parse(raw);
        return parsed;
      }
    } catch (err) {
      console.error('Error reading database file, using seed data:', err);
    }

    const seed = getInitialSeedData();
    this.saveData(seed);
    return seed;
  }

  private saveData(dataToSave: DatabaseSchema = this.data) {
    try {
      fs.writeFileSync(DB_FILE, JSON.stringify(dataToSave, null, 2), 'utf-8');
    } catch (err) {
      console.error('Error writing to database file:', err);
    }
  }

  // Users
  getUsers(): User[] {
    return this.data.users;
  }

  findUserByEmailOrPhone(query: string): User | undefined {
    const q = query.trim().toLowerCase();
    return this.data.users.find(
      (u) => u.emailOrPhone.toLowerCase() === q || u.name.toLowerCase() === q
    );
  }

  findUserById(id: string): User | undefined {
    return this.data.users.find((u) => u.id === id);
  }

  addUser(user: User): User {
    this.data.users.push(user);
    this.saveData();
    return user;
  }

  updateUser(id: string, updates: Partial<User>): User | undefined {
    const idx = this.data.users.findIndex((u) => u.id === id);
    if (idx === -1) return undefined;
    this.data.users[idx] = { ...this.data.users[idx], ...updates };
    this.saveData();
    return this.data.users[idx];
  }

  // Advisories
  getAdvisories(): HealthAdvisory[] {
    return this.data.advisories;
  }

  getAdvisoryById(id: string): HealthAdvisory | undefined {
    return this.data.advisories.find((a) => a.id === id);
  }

  addAdvisory(adv: HealthAdvisory): HealthAdvisory {
    this.data.advisories.unshift(adv);
    this.saveData();
    return adv;
  }

  updateAdvisory(id: string, updates: Partial<HealthAdvisory>): HealthAdvisory | undefined {
    const idx = this.data.advisories.findIndex((a) => a.id === id);
    if (idx === -1) return undefined;
    this.data.advisories[idx] = { ...this.data.advisories[idx], ...updates };
    this.saveData();
    return this.data.advisories[idx];
  }

  deleteAdvisory(id: string): boolean {
    const initialLen = this.data.advisories.length;
    this.data.advisories = this.data.advisories.filter((a) => a.id !== id);
    this.saveData();
    return this.data.advisories.length < initialLen;
  }

  // Camps
  getCamps(): VaccinationCamp[] {
    return this.data.camps;
  }

  getCampById(id: string): VaccinationCamp | undefined {
    return this.data.camps.find((c) => c.id === id);
  }

  addCamp(camp: VaccinationCamp): VaccinationCamp {
    this.data.camps.push(camp);
    this.saveData();
    return camp;
  }

  updateCamp(id: string, updates: Partial<VaccinationCamp>): VaccinationCamp | undefined {
    const idx = this.data.camps.findIndex((c) => c.id === id);
    if (idx === -1) return undefined;
    this.data.camps[idx] = { ...this.data.camps[idx], ...updates };
    this.saveData();
    return this.data.camps[idx];
  }

  deleteCamp(id: string): boolean {
    const initialLen = this.data.camps.length;
    this.data.camps = this.data.camps.filter((c) => c.id !== id);
    this.saveData();
    return this.data.camps.length < initialLen;
  }

  // Hospitals
  getHospitals(): Hospital[] {
    return this.data.hospitals;
  }

  getHospitalById(id: string): Hospital | undefined {
    return this.data.hospitals.find((h) => h.id === id);
  }

  addHospital(hospital: Hospital): Hospital {
    this.data.hospitals.push(hospital);
    this.saveData();
    return hospital;
  }

  updateHospital(id: string, updates: Partial<Hospital>): Hospital | undefined {
    const idx = this.data.hospitals.findIndex((h) => h.id === id);
    if (idx === -1) return undefined;
    this.data.hospitals[idx] = { ...this.data.hospitals[idx], ...updates };
    this.saveData();
    return this.data.hospitals[idx];
  }

  deleteHospital(id: string): boolean {
    const initialLen = this.data.hospitals.length;
    this.data.hospitals = this.data.hospitals.filter((h) => h.id !== id);
    this.saveData();
    return this.data.hospitals.length < initialLen;
  }

  // Pharmacies & Medicines
  getPharmacies(): Pharmacy[] {
    return this.data.pharmacies;
  }

  getPharmacyById(id: string): Pharmacy | undefined {
    return this.data.pharmacies.find((p) => p.id === id);
  }

  updatePharmacy(id: string, updates: Partial<Pharmacy>): Pharmacy | undefined {
    const idx = this.data.pharmacies.findIndex((p) => p.id === id);
    if (idx === -1) return undefined;
    this.data.pharmacies[idx] = { ...this.data.pharmacies[idx], ...updates };
    this.saveData();
    return this.data.pharmacies[idx];
  }

  getMedicinesDirectory(): Record<string, MedicineInfo> {
    return this.data.medicinesDirectory;
  }

  // Bookings with Atomic Slot Operations
  getBookings(): Booking[] {
    return this.data.bookings;
  }

  getBookingById(id: string): Booking | undefined {
    return this.data.bookings.find((b) => b.id === id);
  }

  getUserBookings(userIdOrPhone: string): Booking[] {
    return this.data.bookings.filter(
      (b) => b.userId === userIdOrPhone || b.userPhone === userIdOrPhone
    );
  }

  createBooking(booking: Booking): { success: boolean; booking?: Booking; error?: string } {
    if (booking.type === 'camp') {
      const camp = this.getCampById(booking.targetId);
      if (!camp) return { success: false, error: 'Vaccination camp not found' };
      if (camp.availableSlots <= 0) return { success: false, error: 'No slots available for this camp' };
      
      // decrement slot
      camp.availableSlots -= 1;
      this.updateCamp(camp.id, { availableSlots: camp.availableSlots });
    } else if (booking.type === 'hospital') {
      const hosp = this.getHospitalById(booking.targetId);
      if (!hosp) return { success: false, error: 'Hospital not found' };
      // find slot
      const slot = hosp.appointmentSlots.find(
        (s) => s.time === booking.slotTime && s.date === booking.slotDate
      );
      if (slot && !slot.isAvailable) {
        return { success: false, error: 'This time slot was just booked by another resident' };
      }
      if (slot) {
        slot.isAvailable = false;
        this.updateHospital(hosp.id, { appointmentSlots: hosp.appointmentSlots });
      }
    }

    this.data.bookings.unshift(booking);
    this.saveData();
    return { success: true, booking };
  }

  updateBookingStatus(id: string, status: 'confirmed' | 'attended' | 'cancelled' | 'no_show'): Booking | undefined {
    const booking = this.getBookingById(id);
    if (!booking) return undefined;

    const oldStatus = booking.status;
    booking.status = status;

    // if cancelling a previously confirmed booking, restore slot
    if (oldStatus === 'confirmed' && status === 'cancelled') {
      if (booking.type === 'camp') {
        const camp = this.getCampById(booking.targetId);
        if (camp) {
          camp.availableSlots = Math.min(camp.totalSlots, camp.availableSlots + 1);
          this.updateCamp(camp.id, { availableSlots: camp.availableSlots });
        }
      } else if (booking.type === 'hospital') {
        const hosp = this.getHospitalById(booking.targetId);
        if (hosp) {
          const slot = hosp.appointmentSlots.find(
            (s) => s.time === booking.slotTime && s.date === booking.slotDate
          );
          if (slot) {
            slot.isAvailable = true;
            this.updateHospital(hosp.id, { appointmentSlots: hosp.appointmentSlots });
          }
        }
      }
    }

    this.saveData();
    return booking;
  }

  // Feedback
  addFeedback(fb: Feedback): Feedback {
    this.data.feedback.unshift(fb);
    this.saveData();
    return fb;
  }

  getFeedback(): Feedback[] {
    return this.data.feedback;
  }
}

export const db = new Database();
