import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  MessageSquare,
  Send,
  Bot,
  User,
  Sparkles,
  Volume2,
  VolumeX,
  Trash2,
  ExternalLink,
  ShieldCheck,
  Phone,
  Calendar,
  Building2,
  Pill,
  Loader2,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useAccessibility } from '../context/AccessibilityContext';

interface ChatMessage {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  suggestedActions?: { label: string; action: string }[];
  time: string;
}

export const ChatbotPage: React.FC = () => {
  const { currentLang, t } = useLanguage();
  const { speakText, stopSpeaking, isSpeaking } = useAccessibility();
  const navigate = useNavigate();

  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'm_init',
      sender: 'bot',
      text: 'Namaste! I am Arogya Mitra, your 24/7 community health guide for Mira Bhayandar Municipal Corporation. You can ask me about fever symptoms, free baby vaccines, hospital OPD hours, or government health schemes.',
      suggestedActions: [
        { label: 'Dengue & Fever Precautions', action: '/advisories' },
        { label: 'Upcoming Vaccination Camps', action: '/camps' },
        { label: 'Municipal Hospitals', action: '/hospitals' },
      ],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const chatEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, loading]);

  const handleSend = async (messageText?: string) => {
    const text = (messageText || input).trim();
    if (!text || loading) return;

    const userMsg: ChatMessage = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/chatbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          lang: currentLang,
        }),
      });

      const data = await res.json();
      const botMsg: ChatMessage = {
        id: `bot_${Date.now()}`,
        sender: 'bot',
        text: data.reply || 'Thank you for your question. Please consult a registered MBMC medical officer for medical diagnosis.',
        suggestedActions: data.suggestedActions || [],
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: `bot_err_${Date.now()}`,
          sender: 'bot',
          text: 'Unable to reach the assistant server right now. In medical emergency, call 108 immediately or visit Indira Gandhi Civil Hospital.',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleClearChat = () => {
    setMessages([
      {
        id: 'm_init',
        sender: 'bot',
        text: 'Conversation reset. How can I assist your family today with health services in Mira Bhayandar?',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      },
    ]);
  };

  const sampleCategories = [
    {
      title: '🦟 Dengue & Monsoon Fever',
      prompt: 'What are the early symptoms of dengue fever and how do I prevent mosquito breeding at home in Mira Road?',
    },
    {
      title: '💉 Infant & Child Vaccines',
      prompt: 'What routine vaccines are free for children under 5 years at Mira Bhayandar health centers?',
    },
    {
      title: '👵 Senior Citizen Checkups',
      prompt: 'Are there special senior citizen OPD counters and free pneumonia vaccines at Temba Hospital?',
    },
    {
      title: '💊 Subsidized Medicine Stores',
      prompt: 'Where is the Pradhan Mantri Jan Aushadhi Kendra in Mira Bhayandar for cheap diabetes medicines?',
    },
    {
      title: '🚑 Ambulance & Emergency',
      prompt: 'What is the fastest way to get a government ambulance in Bhayandar West in emergency?',
    },
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-emerald-900 via-teal-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl space-y-3">
        <div className="flex items-center justify-between">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-800/80 rounded-full text-emerald-200 text-xs font-bold uppercase tracking-wider">
            <Sparkles className="w-4 h-4 text-emerald-300" />
            24/7 AI Health Assistant
          </div>
          <button
            onClick={handleClearChat}
            className="p-2 text-xs text-teal-200 hover:text-white hover:bg-white/10 rounded-xl transition-colors flex items-center gap-1"
          >
            <Trash2 className="w-3.5 h-3.5" />
            <span>Clear Chat</span>
          </button>
        </div>

        <h1 className="text-2xl sm:text-4xl font-extrabold text-white">
          Arogya Mitra 24/7 Health Assistant
        </h1>
        <p className="text-sm sm:text-base text-emerald-100/90 leading-relaxed font-normal">
          Instant answers to your medical questions in simple words, grounded in Mira Bhayandar municipal hospitals, vaccination camps, and outbreak alerts.
        </p>
      </div>

      {/* Suggested Topic Starter Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5">
        {sampleCategories.map((cat, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(cat.prompt)}
            className="p-3 bg-white hover:bg-teal-50/70 text-slate-800 border border-slate-200 hover:border-teal-300 rounded-2xl text-left text-xs font-bold shadow-2xs transition-all flex flex-col justify-between space-y-1"
          >
            <span className="text-teal-900 font-extrabold">{cat.title}</span>
            <span className="text-slate-500 font-normal text-[11px] line-clamp-1">{cat.prompt}</span>
          </button>
        ))}
      </div>

      {/* Main Chat Box Container */}
      <div className="bg-white rounded-3xl border border-slate-200 shadow-md flex flex-col h-[560px] overflow-hidden">
        {/* Messages Stream */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-4 bg-slate-50/60">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
            >
              <div
                className={`max-w-[85%] rounded-3xl p-4 leading-relaxed text-sm shadow-2xs space-y-2 ${
                  msg.sender === 'user'
                    ? 'bg-teal-700 text-white rounded-br-xs font-medium'
                    : 'bg-white text-slate-900 border border-slate-200/90 rounded-bl-xs'
                }`}
              >
                <div className="flex items-center justify-between gap-4 text-xs opacity-70 pb-1 border-b border-white/10">
                  <span className="font-bold flex items-center gap-1">
                    {msg.sender === 'user' ? <User className="w-3.5 h-3.5" /> : <Bot className="w-3.5 h-3.5 text-teal-700" />}
                    {msg.sender === 'user' ? 'You (Resident)' : 'Arogya Mitra'}
                  </span>
                  <span>{msg.time}</span>
                </div>

                <p className="whitespace-pre-line text-sm leading-relaxed">{msg.text}</p>

                {msg.sender === 'bot' && (
                  <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                    <button
                      onClick={() => speakText(msg.text, currentLang)}
                      className="p-1 hover:text-teal-700 flex items-center gap-1 text-teal-800 font-bold"
                    >
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>Read aloud</span>
                    </button>
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              {msg.suggestedActions && msg.suggestedActions.length > 0 && (
                <div className="flex flex-wrap gap-2 mt-2">
                  {msg.suggestedActions.map((act, i) => (
                    <button
                      key={i}
                      onClick={() => {
                        if (act.action.startsWith('tel:')) {
                          window.location.href = act.action;
                        } else {
                          navigate(act.action);
                        }
                      }}
                      className="px-3 py-1.5 bg-teal-50 hover:bg-teal-100 text-teal-900 border border-teal-200 rounded-xl text-xs font-bold flex items-center gap-1.5 transition-colors shadow-2xs"
                    >
                      <span>{act.label}</span>
                      <ExternalLink className="w-3 h-3 text-teal-600" />
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}

          {loading && (
            <div className="flex items-center gap-2.5 p-3 bg-white rounded-2xl border border-slate-200 w-fit text-xs text-slate-600">
              <Loader2 className="w-4 h-4 animate-spin text-teal-600" />
              <span>Arogya Mitra is finding verified health advice...</span>
            </div>
          )}
          <div ref={chatEndRef} />
        </div>

        {/* Input Bar */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="p-3 sm:p-4 bg-white border-t border-slate-200 flex gap-2"
        >
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Type your health question (e.g. fever remedies, free camps in Mira Road)..."
            className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600 focus:bg-white"
          />
          <button
            type="submit"
            disabled={!input.trim() || loading}
            className="px-6 py-3 bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white font-extrabold text-sm rounded-2xl transition-colors flex items-center gap-2 shadow-xs"
          >
            <Send className="w-4 h-4" />
            <span className="hidden sm:inline">Send</span>
          </button>
        </form>
      </div>
    </div>
  );
};
