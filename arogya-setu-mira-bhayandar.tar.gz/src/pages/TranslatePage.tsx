import React, { useState } from 'react';
import {
  Languages,
  ArrowRightLeft,
  Volume2,
  VolumeX,
  Copy,
  Check,
  Sparkles,
  Share2,
  RotateCcw,
  BookOpen,
  Send,
  Loader2,
} from 'lucide-react';
import { useLanguage, ALL_LANGUAGES } from '../context/LanguageContext';
import { useAccessibility } from '../context/AccessibilityContext';

export const TranslatePage: React.FC = () => {
  const { currentLang } = useLanguage();
  const { speakText, stopSpeaking, isSpeaking } = useAccessibility();

  const [sourceLang, setSourceLang] = useState('en');
  const [targetLang, setTargetLang] = useState(currentLang || 'hi');
  const [inputText, setInputText] = useState('');
  const [translatedText, setTranslatedText] = useState('');
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);

  const samplePhrases = [
    { label: 'Elderly Fever', text: 'My elderly mother has high fever, body pain, and headache for 2 days. Which hospital in Mira Bhayandar should we visit?' },
    { label: 'Dengue Platelets', text: 'How do I check platelet count for dengue fever, and is the blood test free at Indira Gandhi Civil Hospital?' },
    { label: 'Baby Vaccines', text: 'Where can my 6-month-old baby get free routine vaccination drops in Bhayandar West?' },
    { label: 'Medicine Dosage', text: 'Should I take this blood pressure tablet in the morning on an empty stomach or after breakfast?' },
    { label: 'Pregnant Mother Care', text: 'When should a pregnant woman get the Tetanus (Td) injection at the municipal maternity health post?' },
  ];

  const handleTranslate = async (textToUse?: string) => {
    const text = (textToUse || inputText).trim();
    if (!text) return;

    setLoading(true);
    try {
      const res = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          from: sourceLang,
          to: targetLang,
        }),
      });

      const data = await res.json();
      if (res.ok) {
        setTranslatedText(data.translatedText || '');
      } else {
        setTranslatedText('Translation unavailable at the moment. Please try again.');
      }
    } catch (err) {
      console.error('Translation failed:', err);
      setTranslatedText('Network error during translation.');
    } finally {
      setLoading(false);
    }
  };

  const handleSwap = () => {
    const prevSource = sourceLang;
    const prevTarget = targetLang;
    setSourceLang(prevTarget);
    setTargetLang(prevSource);
    setInputText(translatedText);
    setTranslatedText(inputText);
  };

  const handleCopy = () => {
    if (!translatedText) return;
    navigator.clipboard.writeText(translatedText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = () => {
    if (navigator.share && translatedText) {
      navigator.share({
        title: 'Arogya Setu Health Translation',
        text: `${translatedText}\n\n(Arogya Setu Mira Bhayandar)`,
      }).catch(() => {});
    } else {
      handleCopy();
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-teal-800 via-cyan-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-cyan-700/80 rounded-full text-cyan-100 text-xs font-bold uppercase tracking-wider">
          <Sparkles className="w-4 h-4 text-cyan-300" />
          100+ Languages • 5th-Grade Plain Language Health Translation
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-white">
          Multilingual Health Text & Prescription Translator
        </h1>
        <p className="text-sm sm:text-base text-cyan-100/90 leading-relaxed font-normal max-w-3xl">
          Translate doctor prescriptions, medical notices, lab test advice, and symptom questions into Marathi, Hindi, Gujarati, Urdu, Bengali, Tamil, or any of 100+ languages.
        </p>
      </div>

      {/* Pre-populated Quick Medical Health Statement Chips */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs space-y-2">
        <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
          <BookOpen className="w-3.5 h-3.5 text-teal-700" />
          Quick Common Health Queries (Click to load & translate):
        </span>
        <div className="flex flex-wrap gap-2">
          {samplePhrases.map((phrase, i) => (
            <button
              key={i}
              onClick={() => {
                setInputText(phrase.text);
                handleTranslate(phrase.text);
              }}
              className="px-3 py-1.5 bg-teal-50/70 hover:bg-teal-100 text-teal-950 border border-teal-200 rounded-xl text-xs font-medium transition-colors text-left"
            >
              <strong>{phrase.label}:</strong> {phrase.text.slice(0, 45)}...
            </button>
          ))}
        </div>
      </div>

      {/* Main Translation Cards Area */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        {/* Language Selection Row */}
        <div className="grid grid-cols-1 sm:grid-cols-11 gap-3 items-center">
          {/* Source Language */}
          <div className="sm:col-span-5">
            <label className="block text-xs font-bold text-slate-600 mb-1">From Language</label>
            <select
              value={sourceLang}
              onChange={(e) => setSourceLang(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-600"
            >
              {ALL_LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.native} ({l.name})
                </option>
              ))}
            </select>
          </div>

          {/* Swap Button */}
          <div className="sm:col-span-1 flex justify-center pt-4 sm:pt-4">
            <button
              onClick={handleSwap}
              className="p-3 bg-slate-100 hover:bg-teal-50 hover:text-teal-800 text-slate-600 rounded-xl border border-slate-200 transition-colors shadow-2xs"
              title="Swap Languages"
            >
              <ArrowRightLeft className="w-4 h-4" />
            </button>
          </div>

          {/* Target Language */}
          <div className="sm:col-span-5">
            <label className="block text-xs font-bold text-slate-600 mb-1">To Language (Your Language)</label>
            <select
              value={targetLang}
              onChange={(e) => setTargetLang(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-teal-50/70 border border-teal-300 rounded-xl text-sm font-bold text-teal-950 focus:outline-none focus:ring-2 focus:ring-teal-600"
            >
              {ALL_LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.native} ({l.name})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Text Areas Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Source Input Box */}
          <div className="flex flex-col space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-700">Enter Medical Text or Doctor Advice:</span>
              {inputText && (
                <button
                  onClick={() => setInputText('')}
                  className="text-xs text-slate-400 hover:text-slate-600 font-medium"
                >
                  Clear
                </button>
              )}
            </div>

            <textarea
              rows={6}
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Paste doctor's advice, medication dosage, lab instructions, or symptom descriptions here..."
              className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm leading-relaxed focus:outline-none focus:ring-2 focus:ring-teal-600 focus:bg-white resize-y"
            />

            <div className="flex items-center justify-between pt-1">
              <span className="text-xs text-slate-400">{inputText.length} characters</span>
              <button
                onClick={() => handleTranslate()}
                disabled={!inputText.trim() || loading}
                className="px-5 py-2.5 bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-all flex items-center gap-2"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Send className="w-4 h-4" />}
                <span>Translate Now</span>
              </button>
            </div>
          </div>

          {/* Translated Result Box */}
          <div className="flex flex-col space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-teal-900 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-teal-600" />
                Translated Plain-Language Result:
              </span>
              {translatedText && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => speakText(translatedText, targetLang)}
                    className="p-1.5 text-teal-700 hover:bg-teal-50 rounded-lg transition-colors"
                    title="Listen to translation"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                  <button
                    onClick={handleCopy}
                    className="p-1.5 text-teal-700 hover:bg-teal-50 rounded-lg transition-colors"
                    title="Copy to clipboard"
                  >
                    {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={handleShare}
                    className="p-1.5 text-teal-700 hover:bg-teal-50 rounded-lg transition-colors"
                    title="Share translation"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>

            <div
              className={`w-full p-4 rounded-2xl border text-sm leading-relaxed min-h-[160px] flex flex-col justify-between ${
                translatedText
                  ? 'bg-teal-50/60 border-teal-200 text-slate-900 font-medium'
                  : 'bg-slate-50/70 border-slate-200 text-slate-400 italic'
              }`}
            >
              {loading ? (
                <div className="flex items-center gap-2 text-teal-700 py-8 justify-center">
                  <Loader2 className="w-5 h-5 animate-spin" />
                  <span>Translating in simple words...</span>
                </div>
              ) : (
                <p className="whitespace-pre-line">
                  {translatedText || 'Translated output will appear here in simple words.'}
                </p>
              )}

              {translatedText && (
                <div className="mt-4 pt-3 border-t border-teal-100 flex items-center justify-between text-xs text-teal-800">
                  <span>Target: <strong>{ALL_LANGUAGES.find(l => l.code === targetLang)?.name}</strong></span>
                  <span className="font-bold flex items-center gap-1">
                    <Check className="w-3.5 h-3.5 text-emerald-600" /> Ready to read or listen
                  </span>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
