import React, { useState, useEffect } from 'react';
import {
  Pill,
  Search,
  MapPin,
  Phone,
  Clock,
  CheckCircle2,
  AlertCircle,
  ShieldCheck,
  Tag,
  Store,
  Filter,
  Sparkles,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { Pharmacy, MedicineStockItem } from '../types';

export const MedicineAvailabilityPage: React.FC = () => {
  const { t } = useLanguage();
  const [pharmacies, setPharmacies] = useState<Pharmacy[]>([]);
  const [loading, setLoading] = useState(true);
  const [medicineQuery, setMedicineQuery] = useState('');
  const [selectedLocality, setSelectedLocality] = useState('all');
  const [onlyJanAushadhi, setOnlyJanAushadhi] = useState(false);
  const [only24Hours, setOnly24Hours] = useState(false);

  useEffect(() => {
    const fetchPharmacies = async () => {
      try {
        const params = new URLSearchParams();
        if (medicineQuery) params.append('medicine', medicineQuery);
        if (selectedLocality !== 'all') params.append('locality', selectedLocality);
        if (onlyJanAushadhi) params.append('janAushadhi', 'true');
        if (only24Hours) params.append('is24Hours', 'true');

        const res = await fetch(`/api/pharmacies?${params.toString()}`);
        if (res.ok) {
          const data = await res.json();
          setPharmacies(data.pharmacies || []);
        }
      } catch (err) {
        console.error('Error loading pharmacies:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchPharmacies();
  }, [medicineQuery, selectedLocality, onlyJanAushadhi, only24Hours]);

  const quickMedicines = [
    'Paracetamol 650',
    'Metformin 500',
    'Amlodipine 5',
    'Pantoprazole 40',
    'Amoxicillin 500',
    'ORS Sachet',
    'Cetirizine 10',
    'Iron & Folic Acid',
  ];

  const localities = [
    'all',
    'Bhayandar West',
    'Bhayandar East',
    'Mira Road East',
    'Naya Nagar',
    'Kashimira',
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-cyan-900 via-teal-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-cyan-800/80 rounded-full text-cyan-200 text-xs font-bold uppercase tracking-wider">
          <Store className="w-4 h-4 text-cyan-300" />
          Real-Time Local Chemist & Jan Aushadhi Kendra Inventory
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-white">
          {t('navPharmacies', 'Medicine Availability & Subsidized Chemist Finder')}
        </h1>
        <p className="text-sm sm:text-base text-cyan-100/90 leading-relaxed font-normal max-w-3xl">
          Search local pharmacies across Mira Bhayandar for essential fever, diabetes, blood pressure, and antibiotic medicine stocks. Locate 24x7 stores and Jan Aushadhi Kendras offering up to 80% generic discounts.
        </p>
      </div>

      {/* Quick Medicine Search Tags */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs space-y-2">
        <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
          <Tag className="w-3.5 h-3.5 text-teal-600" />
          Popular Essential Medicines in Mira Bhayandar:
        </span>
        <div className="flex flex-wrap gap-2">
          {quickMedicines.map((med, i) => (
            <button
              key={i}
              onClick={() => setMedicineQuery(med)}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-colors border ${
                medicineQuery === med
                  ? 'bg-teal-700 text-white border-teal-600 shadow-xs'
                  : 'bg-slate-50 hover:bg-teal-50 text-slate-800 border-slate-200'
              }`}
            >
              {med}
            </button>
          ))}
          {medicineQuery && (
            <button
              onClick={() => setMedicineQuery('')}
              className="px-3 py-1 bg-rose-50 text-rose-700 hover:bg-rose-100 rounded-xl text-xs font-bold border border-rose-200"
            >
              Clear Filter ✕
            </button>
          )}
        </div>
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
          {/* Medicine Search Box */}
          <div className="sm:col-span-6 relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={medicineQuery}
              onChange={(e) => setMedicineQuery(e.target.value)}
              placeholder="Search medicine brand or generic salt name..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-600"
            />
          </div>

          {/* Locality Selector */}
          <div className="sm:col-span-3">
            <select
              value={selectedLocality}
              onChange={(e) => setSelectedLocality(e.target.value)}
              className="w-full px-3 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-600"
            >
              <option value="all">All Localities</option>
              {localities.filter(l => l !== 'all').map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>
          </div>

          {/* Quick Checkboxes */}
          <div className="sm:col-span-3 flex items-center gap-4 text-xs font-bold text-slate-700">
            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={onlyJanAushadhi}
                onChange={(e) => setOnlyJanAushadhi(e.target.checked)}
                className="w-4 h-4 rounded text-teal-600 focus:ring-teal-500"
              />
              <span>Jan Aushadhi Only</span>
            </label>

            <label className="flex items-center gap-1.5 cursor-pointer">
              <input
                type="checkbox"
                checked={only24Hours}
                onChange={(e) => setOnly24Hours(e.target.checked)}
                className="w-4 h-4 rounded text-teal-600 focus:ring-teal-500"
              />
              <span>24x7 Open</span>
            </label>
          </div>
        </div>
      </div>

      {/* Pharmacies Grid */}
      {loading ? (
        <div className="p-12 text-center text-slate-500 font-medium bg-white rounded-2xl border border-slate-200">
          Checking pharmacy stocks across Mira Bhayandar...
        </div>
      ) : pharmacies.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 space-y-3">
          <AlertCircle className="w-10 h-10 text-slate-400 mx-auto" />
          <h3 className="text-lg font-bold text-slate-800">No pharmacies found matching criteria</h3>
          <p className="text-sm text-slate-500">Try searching for generic salt names like "Paracetamol" or clearing filters.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pharmacies.map((pharm) => (
            <div
              key={pharm.id}
              className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all flex flex-col justify-between space-y-4"
            >
              <div className="space-y-3">
                {/* Badges */}
                <div className="flex flex-wrap items-center justify-between gap-1.5">
                  <div className="flex items-center gap-1.5">
                    {pharm.hasJanAushadhiScheme && (
                      <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-full text-[11px] font-black uppercase">
                        ⭐ Jan Aushadhi (50-80% OFF)
                      </span>
                    )}
                    {pharm.is24Hours && (
                      <span className="px-2 py-0.5 bg-blue-100 text-blue-900 rounded-full text-[11px] font-bold">
                        24x7 Open
                      </span>
                    )}
                  </div>
                  <span className="text-[11px] font-semibold text-slate-500">
                    {pharm.distanceKm} km away
                  </span>
                </div>

                {/* Name & Address */}
                <div>
                  <h3 className="text-lg font-bold text-slate-900 leading-tight">
                    {pharm.name}
                  </h3>
                  <p className="text-xs text-slate-600 mt-1 flex items-start gap-1">
                    <MapPin className="w-3.5 h-3.5 text-teal-700 shrink-0 mt-0.5" />
                    <span>{pharm.address} ({pharm.locality})</span>
                  </p>
                </div>

                <div className="text-xs text-slate-500 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-slate-400" />
                  <span>Timings: {pharm.timings}</span>
                </div>

                {/* Live Stock Items in this Store */}
                <div className="pt-2 border-t border-slate-100 space-y-1.5">
                  <span className="text-xs font-bold text-slate-700 block">Available Medicines in Stock:</span>
                  <div className="space-y-1.5">
                    {(pharm.matchingItems || pharm.inventory).map((item) => (
                      <div
                        key={item.medicineId}
                        className="p-2 rounded-xl bg-slate-50 border border-slate-200/80 flex items-center justify-between text-xs"
                      >
                        <div>
                          <span className="font-bold text-slate-900 block">{item.name}</span>
                          <span className="text-[10px] text-slate-500">{item.genericName}</span>
                        </div>
                        <div className="text-right">
                          <span
                            className={`px-1.5 py-0.5 rounded text-[10px] font-bold block ${
                              item.status === 'In Stock'
                                ? 'bg-emerald-100 text-emerald-800'
                                : item.status === 'Low Stock'
                                ? 'bg-amber-100 text-amber-800'
                                : 'bg-red-100 text-red-800'
                            }`}
                          >
                            {item.status}
                          </span>
                          <span className="text-[11px] font-black text-slate-900 mt-0.5 block">{item.price}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Call Pharmacy CTA */}
              <div className="pt-3 border-t border-slate-100">
                <a
                  href={`tel:${pharm.contactNumber}`}
                  className="w-full py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Call Chemist ({pharm.contactNumber})</span>
                </a>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
