import React, { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import L from 'leaflet';
import {
  Building2,
  MapPin,
  Phone,
  Clock,
  ShieldCheck,
  Search,
  Filter,
  CheckCircle,
  ExternalLink,
  Calendar,
  Layers,
  Map as MapIcon,
  List,
  AlertCircle,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { Hospital } from '../types';

export const HospitalsPage: React.FC = () => {
  const { t } = useLanguage();
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedLocality, setSelectedLocality] = useState('all');
  const [selectedSpecialty, setSelectedSpecialty] = useState('all');
  const [search, setSearch] = useState('');
  const [viewMode, setViewMode] = useState<'map' | 'list'>('map');
  const [selectedHospital, setSelectedHospital] = useState<Hospital | null>(null);

  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<L.Map | null>(null);
  const markersRef = useRef<L.Marker[]>([]);

  // Fetch hospitals
  useEffect(() => {
    const fetchHospitals = async () => {
      try {
        const params = new URLSearchParams();
        if (selectedLocality !== 'all') params.append('locality', selectedLocality);
        if (selectedSpecialty !== 'all') params.append('specialty', selectedSpecialty);
        if (search) params.append('search', search);

        const res = await fetch(`/api/hospitals?${params.toString()}`);
        if (res.ok) {
          const data = await res.json();
          setHospitals(data.hospitals || []);
          if (data.hospitals?.length > 0 && !selectedHospital) {
            setSelectedHospital(data.hospitals[0]);
          }
        }
      } catch (err) {
        console.error('Failed to load hospitals:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchHospitals();
  }, [selectedLocality, selectedSpecialty, search]);

  // Initialize Leaflet Map
  useEffect(() => {
    if (viewMode !== 'map' || !mapContainerRef.current) return;

    if (!mapInstanceRef.current) {
      // Mira Bhayandar Center: 19.2825° N, 72.8561° E
      const map = L.map(mapContainerRef.current).setView([19.2825, 72.8561], 13);

      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors | MBMC GIS',
        maxZoom: 18,
      }).addTo(map);

      mapInstanceRef.current = map;
    }

    const map = mapInstanceRef.current;

    // Clear old markers
    markersRef.current.forEach((m) => m.remove());
    markersRef.current = [];

    // Custom Icons
    const createHospitalIcon = (isFree: boolean) =>
      L.divIcon({
        className: 'custom-leaflet-marker',
        html: `
          <div style="
            background-color: ${isFree ? '#0f766e' : '#0369a1'};
            color: white;
            padding: 6px;
            border-radius: 50%;
            border: 2px solid white;
            box-shadow: 0 4px 6px -1px rgba(0,0,0,0.3);
            display: flex;
            align-items: center;
            justify-content: center;
            width: 32px;
            height: 32px;
          ">
            🏥
          </div>
        `,
        iconSize: [32, 32],
        iconAnchor: [16, 16],
      });

    // Add markers
    hospitals.forEach((hosp) => {
      const marker = L.marker([hosp.latitude, hosp.longitude], {
        icon: createHospitalIcon(hosp.isFreeGovt),
      }).addTo(map);

      marker.bindPopup(`
        <div style="font-family: sans-serif; padding: 4px;">
          <h4 style="margin: 0 0 4px 0; font-size: 14px; font-weight: bold; color: #0f172a;">${hosp.name}</h4>
          <p style="margin: 0 0 4px 0; font-size: 12px; color: #475569;">${hosp.locality} • ${hosp.type}</p>
          <p style="margin: 0; font-size: 11px; font-weight: bold; color: #0f766e;">📞 ${hosp.contactNumber}</p>
        </div>
      `);

      marker.on('click', () => {
        setSelectedHospital(hosp);
      });

      markersRef.current.push(marker);
    });

    // Clean up
    return () => {
      // no need to destroy map completely, markers are cleared on update
    };
  }, [viewMode, hospitals]);

  // Center map on selected hospital
  const handleSelectHospital = (hosp: Hospital) => {
    setSelectedHospital(hosp);
    if (mapInstanceRef.current) {
      mapInstanceRef.current.flyTo([hosp.latitude, hosp.longitude], 15, {
        duration: 1.2,
      });
    }
  };

  const localities = [
    { value: 'all', label: 'All Localities' },
    { value: 'Bhayandar West', label: 'Bhayandar West' },
    { value: 'Mira Road East', label: 'Mira Road East' },
    { value: 'Naya Nagar', label: 'Naya Nagar' },
    { value: 'Kashimira', label: 'Kashimira' },
    { value: 'Uttan Coastal', label: 'Uttan Coastal' },
  ];

  const specialties = [
    { value: 'all', label: 'All Specialties' },
    { value: 'General Medicine', label: 'General Medicine (Fever/Flu)' },
    { value: 'Pediatrics', label: 'Pediatrics (Children)' },
    { value: 'Gynecology', label: 'Gynecology & Maternity' },
    { value: 'Cardiology', label: 'Cardiology (Heart/BP)' },
    { value: 'Trauma Care', label: 'Trauma & Emergency' },
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-6">
      {/* Header */}
      <div className="bg-linear-to-r from-teal-900 via-cyan-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-teal-800/80 rounded-full text-teal-200 text-xs font-bold uppercase tracking-wider">
          <ShieldCheck className="w-4 h-4 text-emerald-300" />
          Mira Bhayandar Municipal & Trust Healthcare Facilities
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-white">
          {t('navHospitals', 'Nearby Municipal Hospitals & OPD Centers')}
        </h1>
        <p className="text-sm sm:text-base text-teal-100/90 leading-relaxed font-normal max-w-3xl">
          Browse verified hospitals in Mira Bhayandar with live OPD timings, emergency phone numbers, specialties, and real-time available consultation slots.
        </p>
      </div>

      {/* Filter and View Mode Switcher */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
          {/* Search Box */}
          <div className="sm:col-span-4 relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search hospital name, doctor, OPD..."
              className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm focus:outline-none focus:ring-2 focus:ring-teal-600"
            />
          </div>

          {/* Locality */}
          <div className="sm:col-span-3">
            <select
              value={selectedLocality}
              onChange={(e) => setSelectedLocality(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
            >
              {localities.map((loc) => (
                <option key={loc.value} value={loc.value}>
                  {loc.label}
                </option>
              ))}
            </select>
          </div>

          {/* Specialty */}
          <div className="sm:col-span-3">
            <select
              value={selectedSpecialty}
              onChange={(e) => setSelectedSpecialty(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs sm:text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
            >
              {specialties.map((spec) => (
                <option key={spec.value} value={spec.value}>
                  {spec.label}
                </option>
              ))}
            </select>
          </div>

          {/* Map vs List Switcher (Senior Citizen friendly) */}
          <div className="sm:col-span-2 flex justify-end">
            <div className="inline-flex bg-slate-100 p-1 rounded-xl border border-slate-200">
              <button
                onClick={() => setViewMode('map')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  viewMode === 'map' ? 'bg-teal-700 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <MapIcon className="w-3.5 h-3.5" />
                <span>Map</span>
              </button>
              <button
                onClick={() => setViewMode('list')}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  viewMode === 'list' ? 'bg-teal-700 text-white shadow-xs' : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <List className="w-3.5 h-3.5" />
                <span>List</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content Area */}
      {loading ? (
        <div className="p-12 text-center text-slate-500 font-medium bg-white rounded-2xl border border-slate-200">
          Locating Mira Bhayandar municipal hospitals on map...
        </div>
      ) : viewMode === 'map' ? (
        /* MAP VIEW */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Leaflet Map Stage */}
          <div className="lg:col-span-7 bg-white rounded-3xl overflow-hidden border border-slate-200 shadow-md h-[460px] sm:h-[550px] relative z-10">
            <div ref={mapContainerRef} className="w-full h-full" />
          </div>

          {/* Selected Hospital Detailed Drawer */}
          <div className="lg:col-span-5 space-y-4">
            {selectedHospital ? (
              <div className="bg-white rounded-3xl p-6 border border-teal-200 shadow-md space-y-5">
                <div className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="px-3 py-1 bg-teal-100 text-teal-900 rounded-full text-xs font-bold uppercase">
                      {selectedHospital.type}
                    </span>
                    {selectedHospital.isFreeGovt && (
                      <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 text-xs font-black rounded-md">
                        100% Free MBMC Care
                      </span>
                    )}
                  </div>

                  <h2 className="text-xl font-bold text-slate-900 leading-snug">
                    {selectedHospital.name}
                  </h2>
                  <p className="text-xs text-slate-600 flex items-start gap-1">
                    <MapPin className="w-4 h-4 text-teal-700 shrink-0 mt-0.5" />
                    <span>{selectedHospital.address} (Near {selectedHospital.landmark})</span>
                  </p>
                </div>

                {/* Emergency Contact & OPD Times */}
                <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-3 rounded-2xl border border-slate-100">
                  <div>
                    <span className="text-slate-500 block">General OPD Timings</span>
                    <strong className="text-slate-800">{selectedHospital.opdTimings}</strong>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Hospital Phone</span>
                    <strong className="text-slate-900 font-mono">{selectedHospital.contactNumber}</strong>
                  </div>
                </div>

                {/* Specialties */}
                <div>
                  <span className="text-xs font-bold text-slate-700 block mb-1.5">Specialties & OPD Departments:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedHospital.specialties.map((s, i) => (
                      <span key={i} className="px-2 py-0.5 bg-teal-50 text-teal-900 border border-teal-200 rounded-md text-xs font-semibold">
                        {s}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Facilities */}
                <div>
                  <span className="text-xs font-bold text-slate-700 block mb-1.5">Key Facilities Available:</span>
                  <div className="flex flex-wrap gap-1.5">
                    {selectedHospital.facilities.map((f, i) => (
                      <span key={i} className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded-md text-xs">
                        ✓ {f}
                      </span>
                    ))}
                  </div>
                </div>

                {/* Available OPD Slots Section */}
                <div className="pt-3 border-t border-slate-100 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-bold text-slate-900">Available Consultation Slots:</span>
                    <span className="text-[11px] text-emerald-700 font-bold">Fast-Track Pass</span>
                  </div>

                  <div className="space-y-1.5 max-h-32 overflow-y-auto">
                    {selectedHospital.appointmentSlots?.map((slot) => (
                      <div
                        key={slot.slotId}
                        className="p-2 rounded-xl bg-teal-50/60 border border-teal-100 flex items-center justify-between text-xs"
                      >
                        <div>
                          <span className="font-bold text-slate-800 block">{slot.doctorName}</span>
                          <span className="text-[11px] text-slate-500">{slot.specialty} • {slot.time}</span>
                        </div>
                        <Link
                          to={`/book-slot?type=hospital&targetId=${selectedHospital.id}`}
                          className="px-2.5 py-1 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-lg transition-colors"
                        >
                          Book Slot
                        </Link>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Phone & Directions */}
                <div className="pt-2 flex items-center gap-2">
                  <a
                    href={`tel:${selectedHospital.contactNumber}`}
                    className="flex-1 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors shadow-xs"
                  >
                    <Phone className="w-4 h-4" />
                    <span>Call Center ({selectedHospital.contactNumber})</span>
                  </a>
                  <a
                    href={`https://maps.google.com/?q=${selectedHospital.latitude},${selectedHospital.longitude}`}
                    target="_blank"
                    rel="noreferrer"
                    className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl flex items-center gap-1 transition-colors"
                  >
                    <ExternalLink className="w-4 h-4" />
                    <span>Directions</span>
                  </a>
                </div>
              </div>
            ) : (
              <div className="p-8 text-center bg-white rounded-3xl border border-slate-200 text-slate-500">
                Click any hospital marker on the map to see OPD timings and doctor consultation slots.
              </div>
            )}

            {/* Quick List under map on mobile */}
            <div className="bg-white rounded-2xl p-4 border border-slate-200 shadow-2xs space-y-2">
              <span className="text-xs font-bold text-slate-700 block">Click to locate hospital:</span>
              <div className="space-y-1.5 max-h-48 overflow-y-auto">
                {hospitals.map((hosp) => (
                  <button
                    key={hosp.id}
                    onClick={() => handleSelectHospital(hosp)}
                    className={`w-full p-2.5 rounded-xl text-left text-xs flex items-center justify-between transition-colors ${
                      selectedHospital?.id === hosp.id
                        ? 'bg-teal-700 text-white font-bold'
                        : 'bg-slate-50 hover:bg-teal-50 text-slate-800'
                    }`}
                  >
                    <span className="truncate pr-2">{hosp.name}</span>
                    <span className="shrink-0 text-[10px] opacity-80">{hosp.locality}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      ) : (
        /* LIST VIEW */
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {hospitals.map((hosp) => (
            <div
              key={hosp.id}
              className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm hover:shadow-md transition-all space-y-4"
            >
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 bg-teal-100 text-teal-900 rounded-full text-xs font-bold uppercase">
                  {hosp.type}
                </span>
                {hosp.isFreeGovt && (
                  <span className="px-2.5 py-0.5 bg-emerald-100 text-emerald-800 text-xs font-black rounded-md">
                    Free MBMC Care
                  </span>
                )}
              </div>

              <div>
                <h2 className="text-xl font-bold text-slate-900">{hosp.name}</h2>
                <p className="text-xs text-slate-600 mt-1 flex items-start gap-1">
                  <MapPin className="w-4 h-4 text-teal-700 shrink-0 mt-0.5" />
                  <span>{hosp.address} • Landmark: {hosp.landmark}</span>
                </p>
              </div>

              <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-3 rounded-2xl border border-slate-100">
                <div>
                  <span className="text-slate-500 block">OPD Timings</span>
                  <strong className="text-slate-800">{hosp.opdTimings}</strong>
                </div>
                <div>
                  <span className="text-slate-500 block">Contact</span>
                  <strong className="text-slate-900 font-mono">{hosp.contactNumber}</strong>
                </div>
              </div>

              <div>
                <span className="text-xs font-bold text-slate-700 block mb-1">Specialties:</span>
                <div className="flex flex-wrap gap-1">
                  {hosp.specialties.map((s, i) => (
                    <span key={i} className="px-2 py-0.5 bg-teal-50 text-teal-900 rounded text-xs">
                      {s}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-2">
                <a
                  href={`tel:${hosp.contactNumber}`}
                  className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-xs rounded-xl flex items-center gap-1.5 transition-colors"
                >
                  <Phone className="w-3.5 h-3.5 text-teal-700" />
                  <span>Call {hosp.contactNumber}</span>
                </a>

                <Link
                  to={`/book-slot?type=hospital&targetId=${hosp.id}`}
                  className="px-5 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl transition-colors shadow-xs"
                >
                  Book OPD Slot
                </Link>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
