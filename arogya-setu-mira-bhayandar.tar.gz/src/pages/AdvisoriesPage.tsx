import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  AlertTriangle,
  Search,
  Filter,
  Volume2,
  VolumeX,
  Sparkles,
  MapPin,
  Calendar,
  Phone,
  ShieldAlert,
  ChevronDown,
  Info,
  CheckCircle,
  HelpCircle,
  PlusCircle,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useAccessibility } from '../context/AccessibilityContext';
import { HealthAdvisory } from '../types';

export const AdvisoriesPage: React.FC = () => {
  const { t, currentLang } = useLanguage();
  const { speakText, stopSpeaking, isSpeaking } = useAccessibility();

  const [advisories, setAdvisories] = useState<HealthAdvisory[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [selectedLocality, setSelectedLocality] = useState('all');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [simpleModeOverrides, setSimpleModeOverrides] = useState<Record<string, boolean>>({});

  useEffect(() => {
    const fetchAdvisories = async () => {
      try {
        const queryParams = new URLSearchParams();
        if (selectedLocality !== 'all') queryParams.append('locality', selectedLocality);
        if (selectedCategory !== 'all') queryParams.append('category', selectedCategory);
        if (search) queryParams.append('search', search);

        const res = await fetch(`/api/advisories?${queryParams.toString()}`);
        if (res.ok) {
          const data = await res.json();
          setAdvisories(data.advisories || []);
        }
      } catch (err) {
        console.error('Error loading advisories:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchAdvisories();
  }, [selectedLocality, selectedCategory, search]);

  const localities = [
    { value: 'all', label: 'All Localities in Mira Bhayandar' },
    { value: 'Bhayandar West', label: 'Bhayandar West' },
    { value: 'Bhayandar East', label: 'Bhayandar East' },
    { value: 'Mira Road East', label: 'Mira Road East' },
    { value: 'Naya Nagar', label: 'Naya Nagar' },
    { value: 'Kashimira', label: 'Kashimira' },
    { value: 'Uttan Coastal', label: 'Uttan Coastal' },
  ];

  const categories = [
    { value: 'all', label: 'All Categories' },
    { value: 'outbreak', label: '🦟 Outbreak Alerts (Dengue/Malaria)' },
    { value: 'monsoon', label: '🌧️ Monsoon Water-Borne' },
    { value: 'vaccination', label: '💉 Immunization & Camps' },
    { value: 'maternal', label: '👶 Maternal & Child Care' },
    { value: 'elderly', label: '👵 Senior Citizen Health' },
  ];

  const toggleSimpleMode = (id: string) => {
    setSimpleModeOverrides((prev) => ({
      ...prev,
      [id]: prev[id] === undefined ? false : !prev[id],
    }));
  };

  const handleReadAloud = (adv: HealthAdvisory, isSimple: boolean) => {
    if (isSpeaking) {
      stopSpeaking();
    } else {
      const textToRead = `${adv.title}. ${isSimple ? adv.simpleText : adv.medicalText}. Symptoms: ${adv.symptoms.join(', ')}. Precautions: ${adv.precautions.join('. ')}`;
      speakText(textToRead, currentLang);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-red-900 via-rose-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="relative z-10 space-y-3 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-red-800/80 rounded-full text-red-200 text-xs font-bold uppercase tracking-wider border border-red-700/50">
            <ShieldAlert className="w-4 h-4 text-red-300" />
            MBMC Public Health Surveillance & Emergency Notices
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
            {t('navAdvisories', 'Mira Bhayandar Health Advisories & Alerts')}
          </h1>
          <p className="text-sm sm:text-base text-rose-100/90 leading-relaxed font-normal">
            Official guidelines, disease outbreak alerts, and seasonal prevention notices issued by the Health Officer, Mira Bhayandar Municipal Corporation. Toggle between <strong className="text-white">Plain 5th-Grade Language</strong> and medical text anytime.
          </p>
        </div>
      </div>

      {/* Filter and Search Toolbar */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search symptoms, illness, fever..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-600 focus:bg-white"
            />
          </div>

          {/* Locality Dropdown */}
          <div className="relative">
            <select
              value={selectedLocality}
              onChange={(e) => setSelectedLocality(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-600"
            >
              {localities.map((loc) => (
                <option key={loc.value} value={loc.value}>
                  {loc.label}
                </option>
              ))}
            </select>
          </div>

          {/* Category Dropdown */}
          <div className="relative">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-600"
            >
              {categories.map((cat) => (
                <option key={cat.value} value={cat.value}>
                  {cat.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Quick Result Counter */}
        <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
          <span>Showing <strong>{advisories.length}</strong> active health advisories</span>
          <span className="text-teal-700 font-semibold flex items-center gap-1">
            <Sparkles className="w-3.5 h-3.5" />
            All advisories verified for Mira Bhayandar wards
          </span>
        </div>
      </div>

      {/* Advisories Grid */}
      {loading ? (
        <div className="p-12 text-center text-slate-500 font-medium bg-white rounded-2xl border border-slate-200">
          Loading health advisories from MBMC database...
        </div>
      ) : advisories.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 space-y-3">
          <Info className="w-10 h-10 text-slate-400 mx-auto" />
          <h3 className="text-lg font-bold text-slate-800">No active advisories found</h3>
          <p className="text-sm text-slate-500">Try clearing filters or searching for different keywords.</p>
        </div>
      ) : (
        <div className="space-y-6">
          {advisories.map((adv) => {
            const isSimple = simpleModeOverrides[adv.id] !== false; // default true for plain language
            const isUrgent = adv.severity === 'urgent';
            const isWarning = adv.severity === 'warning';

            return (
              <article
                key={adv.id}
                className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm hover:shadow-md transition-shadow space-y-6"
              >
                {/* Header Row */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 border-b border-slate-100">
                  <div className="flex flex-wrap items-center gap-2">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-black uppercase tracking-wider ${
                        isUrgent
                          ? 'bg-red-100 text-red-900 border border-red-300'
                          : isWarning
                          ? 'bg-amber-100 text-amber-900 border border-amber-300'
                          : 'bg-blue-100 text-blue-900 border border-blue-300'
                      }`}
                    >
                      {adv.severity === 'urgent' && '🚨 URGENT OUTBREAK ALERT'}
                      {adv.severity === 'warning' && '⚠️ SEASONAL WARNING'}
                      {adv.severity === 'info' && 'ℹ️ HEALTH NOTICE'}
                    </span>

                    <span className="px-3 py-1 bg-slate-100 text-slate-700 rounded-full text-xs font-semibold">
                      Category: {adv.category}
                    </span>

                    <span className="text-xs text-slate-500 flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {adv.date}
                    </span>
                  </div>

                  {/* Read Aloud & Language Mode Switch */}
                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => handleReadAloud(adv, isSimple)}
                      className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                        isSpeaking
                          ? 'bg-amber-500 text-slate-950 font-bold'
                          : 'bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200'
                      }`}
                      title="Listen to this advisory read aloud"
                    >
                      {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5" />}
                      <span>{isSpeaking ? 'Stop Voice' : 'Read Aloud'}</span>
                    </button>

                    <button
                      onClick={() => toggleSimpleMode(adv.id)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all border ${
                        isSimple
                          ? 'bg-emerald-700 text-white border-emerald-600 shadow-2xs'
                          : 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-300'
                      }`}
                    >
                      {isSimple ? '✨ Simple Words (Active)' : '📄 Standard Medical View'}
                    </button>
                  </div>
                </div>

                {/* Title & Locality */}
                <div>
                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 leading-snug">
                    {adv.title}
                  </h2>
                  <p className="text-xs sm:text-sm text-teal-800 font-bold flex items-center gap-1.5 mt-1">
                    <MapPin className="w-4 h-4 text-teal-700" />
                    Target Locality: <span className="underline decoration-teal-400">{adv.locality}</span>
                  </p>
                </div>

                {/* Plain-Language vs Medical Text Box */}
                <div
                  className={`p-5 rounded-2xl border transition-colors ${
                    isSimple
                      ? 'bg-teal-50/80 border-teal-200 text-slate-800'
                      : 'bg-slate-50 border-slate-200 text-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs font-extrabold uppercase tracking-wider text-teal-900 flex items-center gap-1.5">
                      {isSimple ? <Sparkles className="w-4 h-4 text-teal-600" /> : <Info className="w-4 h-4 text-slate-500" />}
                      {isSimple ? 'Plain-Language Explanation (5th-Grade Simple):' : 'Official Clinical / Medical Text:'}
                    </span>
                    <button
                      onClick={() => toggleSimpleMode(adv.id)}
                      className="text-xs text-teal-700 hover:underline font-semibold"
                    >
                      Switch to {isSimple ? 'Clinical View' : 'Simple Words'}
                    </button>
                  </div>
                  <p className="text-sm sm:text-base leading-relaxed font-medium">
                    {isSimple ? adv.simpleText : adv.medicalText}
                  </p>
                </div>

                {/* Symptoms & Precautions 2-Column Section */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-5 pt-2">
                  {/* Common Symptoms */}
                  <div className="p-4 bg-amber-50/70 rounded-2xl border border-amber-200/80 space-y-2">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-amber-900 flex items-center gap-1.5">
                      <AlertTriangle className="w-4 h-4 text-amber-700" />
                      Key Symptoms to Watch For:
                    </h3>
                    <ul className="space-y-1 text-xs sm:text-sm text-slate-800">
                      {adv.symptoms.map((sym, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-600 mt-2 shrink-0"></span>
                          <span>{sym}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Immediate Precautions */}
                  <div className="p-4 bg-emerald-50/70 rounded-2xl border border-emerald-200/80 space-y-2">
                    <h3 className="text-xs font-bold uppercase tracking-wider text-emerald-900 flex items-center gap-1.5">
                      <CheckCircle className="w-4 h-4 text-emerald-700" />
                      Precautions & What You Must Do:
                    </h3>
                    <ul className="space-y-1 text-xs sm:text-sm text-slate-800">
                      {adv.precautions.map((prec, idx) => (
                        <li key={idx} className="flex items-start gap-2">
                          <span className="w-1.5 h-1.5 rounded-full bg-emerald-600 mt-2 shrink-0"></span>
                          <span>{prec}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Action Footer */}
                <div className="pt-4 border-t border-slate-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-slate-50 -mx-6 sm:-mx-8 -mb-6 sm:-mb-8 p-4 sm:px-8 rounded-b-3xl">
                  <div className="flex items-center gap-2 text-xs text-slate-700">
                    <Phone className="w-4 h-4 text-red-600" />
                    <span>MBMC Helpline / Action Desk: <strong className="text-slate-950">{adv.actionHelpline}</strong></span>
                  </div>

                  <div className="flex items-center gap-2">
                    <Link
                      to="/hospitals"
                      className="px-4 py-2 bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 rounded-xl text-xs font-bold transition-colors"
                    >
                      Find Nearest Hospital
                    </Link>
                    <Link
                      to="/book-slot"
                      className="px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
                    >
                      Book Doctor Consultation
                    </Link>
                  </div>
                </div>
              </article>
            );
          })}
        </div>
      )}
    </div>
  );
};
