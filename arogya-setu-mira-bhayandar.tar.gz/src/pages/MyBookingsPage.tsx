import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Calendar,
  Clock,
  MapPin,
  QrCode,
  Printer,
  Trash2,
  AlertCircle,
  CheckCircle2,
  ShieldCheck,
  PlusCircle,
  Loader2,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Booking } from '../types';
import { TokenSlipModal } from '../components/TokenSlipModal';

export const MyBookingsPage: React.FC = () => {
  const { user, token } = useAuth();
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeModalBooking, setActiveModalBooking] = useState<Booking | null>(null);
  const [cancelLoadingId, setCancelLoadingId] = useState<string | null>(null);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    const fetchMyBookings = async () => {
      try {
        const headers: Record<string, string> = {};
        if (token) headers['Authorization'] = `Bearer ${token}`;

        const res = await fetch('/api/bookings/my', { headers });
        if (res.ok) {
          const data = await res.json();
          setBookings(data.bookings || []);
        }
      } catch (err) {
        console.error('Failed to load bookings:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchMyBookings();
  }, [token]);

  const handleCancelBooking = async (id: string) => {
    if (!window.confirm('Are you sure you want to cancel this booking slot?')) return;
    setCancelLoadingId(id);

    try {
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) headers['Authorization'] = `Bearer ${token}`;

      const res = await fetch(`/api/bookings/${id}/cancel`, {
        method: 'POST',
        headers,
      });

      const data = await res.json();
      if (res.ok) {
        setBookings((prev) =>
          prev.map((b) => (b.id === id ? { ...b, status: 'cancelled' } : b))
        );
        setMessage('Booking cancelled. The slot has been returned to the public pool.');
      } else {
        alert(data.error || 'Failed to cancel');
      }
    } catch (err) {
      alert('Error cancelling booking');
    } finally {
      setCancelLoadingId(null);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-teal-800 via-emerald-800 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-700/80 rounded-full text-emerald-100 text-xs font-bold uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4 text-emerald-300" />
            Confirmed Digital Health Tokens
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            My Vaccination & Hospital Bookings
          </h1>
          <p className="text-sm text-teal-100/90 leading-relaxed font-normal">
            Show these digital passes with QR code at the registration desk for fast-track entry.
          </p>
        </div>

        <Link
          to="/book-slot"
          className="px-5 py-3 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold text-sm rounded-2xl shadow-md transition-all flex items-center justify-center gap-2 shrink-0"
        >
          <PlusCircle className="w-4 h-4 text-slate-950" />
          <span>Book New Slot</span>
        </Link>
      </div>

      {message && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-900 text-sm font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>{message}</span>
        </div>
      )}

      {/* Bookings List */}
      {loading ? (
        <div className="p-12 text-center text-slate-500 font-medium bg-white rounded-3xl border border-slate-200">
          Loading your health bookings...
        </div>
      ) : bookings.length === 0 ? (
        <div className="bg-white rounded-3xl p-12 text-center border border-slate-200 space-y-4">
          <div className="w-16 h-16 rounded-full bg-teal-50 text-teal-700 flex items-center justify-center mx-auto">
            <Calendar className="w-8 h-8" />
          </div>
          <div className="space-y-1">
            <h3 className="text-lg font-bold text-slate-900">No active bookings yet</h3>
            <p className="text-xs text-slate-500 max-w-sm mx-auto">
              You haven't booked any vaccination camps or hospital OPD appointments. Book a free digital slot in seconds.
            </p>
          </div>
          <Link
            to="/book-slot"
            className="inline-flex items-center gap-2 px-6 py-3 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs sm:text-sm rounded-xl shadow-xs transition-colors"
          >
            <PlusCircle className="w-4 h-4" />
            Book a Free Health Slot Now
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {bookings.map((booking) => {
            const isConfirmed = booking.status === 'confirmed';
            const isCancelled = booking.status === 'cancelled';
            const isAttended = booking.status === 'attended';

            return (
              <div
                key={booking.id}
                className={`bg-white rounded-3xl p-6 border shadow-sm transition-all flex flex-col md:flex-row md:items-center justify-between gap-5 ${
                  isCancelled
                    ? 'border-slate-200 bg-slate-50/70 opacity-75'
                    : 'border-teal-200/90 hover:shadow-md'
                }`}
              >
                {/* Left details */}
                <div className="space-y-3">
                  <div className="flex flex-wrap items-center gap-2">
                    <span className="px-3 py-1 bg-teal-900 text-white font-mono font-bold text-xs rounded-lg tracking-widest">
                      {booking.tokenNumber}
                    </span>

                    <span
                      className={`px-3 py-0.5 rounded-full text-xs font-bold uppercase ${
                        isConfirmed
                          ? 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                          : isAttended
                          ? 'bg-blue-100 text-blue-900 border border-blue-300'
                          : 'bg-red-100 text-red-900 border border-red-300'
                      }`}
                    >
                      {booking.status}
                    </span>

                    <span className="text-xs text-slate-500 font-semibold">
                      {booking.type === 'camp' ? 'Vaccination Camp' : 'Hospital OPD Pass'}
                    </span>
                  </div>

                  <div>
                    <h2 className="text-lg font-bold text-slate-900 leading-snug">
                      {booking.targetName}
                    </h2>
                    <p className="text-xs text-slate-600 mt-0.5">
                      Patient: <strong className="text-slate-800">{booking.userName}</strong> ({booking.userAge}y, {booking.userGender}) • 📞 {booking.userPhone}
                    </p>
                  </div>

                  <div className="flex flex-wrap items-center gap-4 text-xs text-slate-600 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5 text-teal-700" />
                      Date: <strong className="text-slate-900">{booking.slotDate}</strong>
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5 text-teal-700" />
                      Time: <strong className="text-slate-900">{booking.slotTime}</strong>
                    </span>
                    {booking.specialtyOrVaccine && (
                      <span className="text-teal-800 font-semibold">
                        Service: {booking.specialtyOrVaccine}
                      </span>
                    )}
                  </div>
                </div>

                {/* Right Action buttons */}
                <div className="flex flex-wrap items-center gap-2 pt-3 md:pt-0 border-t md:border-t-0 border-slate-100">
                  <button
                    onClick={() => setActiveModalBooking(booking)}
                    className="flex items-center gap-1.5 px-4 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl shadow-xs transition-colors"
                  >
                    <QrCode className="w-4 h-4" />
                    <span>View Pass & QR</span>
                  </button>

                  {isConfirmed && (
                    <button
                      onClick={() => handleCancelBooking(booking.id)}
                      disabled={cancelLoadingId === booking.id}
                      className="p-2.5 bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs rounded-xl border border-rose-200 transition-colors"
                      title="Cancel Booking"
                    >
                      {cancelLoadingId === booking.id ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Trash2 className="w-4 h-4" />
                      )}
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Slip Modal */}
      {activeModalBooking && (
        <TokenSlipModal
          booking={activeModalBooking}
          onClose={() => setActiveModalBooking(null)}
        />
      )}
    </div>
  );
};
