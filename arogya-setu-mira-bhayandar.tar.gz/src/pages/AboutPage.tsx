import React, { useState } from 'react';
import {
  Heart,
  Shield,
  Phone,
  MapPin,
  LifeBuoy,
  FileCheck,
  Send,
  CheckCircle2,
  AlertCircle,
  Building,
  Sparkles,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const AboutPage: React.FC = () => {
  const { t } = useLanguage();
  const [feedbackName, setFeedbackName] = useState('');
  const [feedbackContact, setFeedbackContact] = useState('');
  const [feedbackLocality, setFeedbackLocality] = useState('Bhayandar West');
  const [feedbackCategory, setFeedbackCategory] = useState('camps');
  const [feedbackRating, setFeedbackRating] = useState('5');
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [loading, setLoading] = useState(false);
  const [feedbackSuccess, setFeedbackSuccess] = useState(false);

  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!feedbackName || !feedbackMessage) return;

    setLoading(true);
    try {
      const res = await fetch('/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: feedbackName,
          phoneOrEmail: feedbackContact,
          locality: feedbackLocality,
          category: feedbackCategory,
          rating: Number(feedbackRating),
          message: feedbackMessage,
        }),
      });

      if (res.ok) {
        setFeedbackSuccess(true);
        setFeedbackName('');
        setFeedbackContact('');
        setFeedbackMessage('');
        setTimeout(() => setFeedbackSuccess(false), 5000);
      }
    } catch (err) {
      console.error('Feedback submit error:', err);
    } finally {
      setLoading(false);
    }
  };

  const wardOffices = [
    { ward: 'Ward 1 - Bhayandar West', post: 'Temba Municipal Hospital Health Post', head: 'Dr. S. Patil', phone: '022-28191244', location: 'Near Station, Bhayandar West' },
    { ward: 'Ward 2 - Bhayandar East', post: 'Jesal Park Community Health Post', head: 'Dr. M. Joshi', phone: '022-28189911', location: 'Jesal Park Road, Bhayandar East' },
    { ward: 'Ward 3 - Naya Nagar', post: 'Naya Nagar Urban Primary Health Center (UPHC)', head: 'Dr. F. Khan', phone: '022-28117890', location: 'Opp Millat Nagar, Naya Nagar' },
    { ward: 'Ward 4 - Mira Road East', post: 'Indira Gandhi Civil Hospital Cell', head: 'Dr. V. Shinde', phone: '022-28114400', location: 'Shanti Nagar, Sector 4' },
    { ward: 'Ward 5 - Kashimira', post: 'Kashimira Trauma & Anti-Rabies Center', head: 'Dr. R. Mishra', phone: '022-28456677', location: 'Western Express Highway Junction' },
    { ward: 'Ward 6 - Uttan & Gorai', post: 'Uttan Seacoast Primary Health Post', head: 'Dr. A. Dmello', phone: '022-28451122', location: 'Uttan Village Market' },
  ];

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 space-y-10">
      {/* Hero Mission */}
      <div className="bg-linear-to-r from-teal-900 via-emerald-950 to-slate-900 text-white rounded-3xl p-6 sm:p-10 shadow-xl space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-teal-800/80 rounded-full text-teal-200 text-xs font-bold uppercase tracking-wider">
          <Heart className="w-4 h-4 text-emerald-300 fill-emerald-300/30" />
          MBMC Public Health Cell Initiative
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-white">
          About Arogya Setu Mira Bhayandar
        </h1>
        <p className="text-sm sm:text-base text-teal-100/90 leading-relaxed font-normal max-w-3xl">
          Arogya Setu Mira Bhayandar is a dedicated municipal health platform created for senior citizens, mothers, and lower-income families residing in Mira Bhayandar. Our mission is to make verified health alerts, free vaccination slots, and hospital OPD appointments simple, fast, and accessible in your own mother tongue.
        </p>
      </div>

      {/* Ward Health Posts Directory */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-5">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <Building className="w-5 h-5 text-teal-700" />
            MBMC Ward Health Posts & Medical Officers
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Contact your local ward medical officer for sanitation, fogging, child immunization, or water testing.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {wardOffices.map((office, i) => (
            <div key={i} className="p-4 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2 flex flex-col justify-between">
              <div>
                <span className="text-xs font-bold text-teal-800 uppercase block">{office.ward}</span>
                <h3 className="font-bold text-sm text-slate-900 mt-0.5">{office.post}</h3>
                <p className="text-xs text-slate-600 mt-1 flex items-start gap-1">
                  <MapPin className="w-3.5 h-3.5 text-teal-700 shrink-0 mt-0.5" />
                  <span>{office.location}</span>
                </p>
              </div>

              <div className="pt-2 border-t border-slate-200/70 flex items-center justify-between text-xs">
                <span className="text-slate-500">In-Charge: <strong>{office.head}</strong></span>
                <a href={`tel:${office.phone}`} className="font-bold text-teal-700 hover:underline">
                  📞 {office.phone}
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Government Health Schemes Summary */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-5">
        <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
          <FileCheck className="w-5 h-5 text-emerald-700" />
          Subsidized Health Schemes for Mira Bhayandar Citizens
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          <div className="p-5 rounded-2xl bg-teal-50/70 border border-teal-100 space-y-2">
            <h3 className="font-bold text-base text-teal-950">Mahatma Jyotiba Phule Jan Arogya Yojana</h3>
            <p className="text-xs text-slate-700 leading-relaxed">
              Provides cashless medical insurance up to ₹5 Lakhs per family per year for 996 secondary and tertiary care hospital procedures in empanelled hospitals like Indira Gandhi Civil Hospital.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-cyan-50/70 border border-cyan-100 space-y-2">
            <h3 className="font-bold text-base text-cyan-950">Pradhan Mantri Jan Aushadhi Kendra</h3>
            <p className="text-xs text-slate-700 leading-relaxed">
              Quality generic medicines available at 50% to 80% lower cost than branded alternatives at Mira Road East Station and Bhayandar West Jan Aushadhi outlets.
            </p>
          </div>

          <div className="p-5 rounded-2xl bg-emerald-50/70 border border-emerald-100 space-y-2">
            <h3 className="font-bold text-base text-emerald-950">Free Universal Immunization</h3>
            <p className="text-xs text-slate-700 leading-relaxed">
              100% free vaccines for pregnant mothers (Tetanus/Td) and infants (BCG, Polio, Pentavalent, Rotavirus, MR) across all 6 MBMC ward centers.
            </p>
          </div>
        </div>
      </div>

      {/* Citizen Feedback Form */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        <div>
          <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
            <LifeBuoy className="w-5 h-5 text-amber-600" />
            Citizen Feedback & Health Suggestions
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Help MBMC improve health facilities, camp timings, or report medicine shortage in your ward.
          </p>
        </div>

        {feedbackSuccess && (
          <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-900 text-sm font-semibold flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span>Thank you for your feedback! It has been recorded for the MBMC Health Officer.</span>
          </div>
        )}

        <form onSubmit={handleFeedbackSubmit} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Your Name *</label>
              <input
                type="text"
                value={feedbackName}
                onChange={(e) => setFeedbackName(e.target.value)}
                placeholder="e.g. Fatima Sheikh"
                required
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Phone or Email (Optional)</label>
              <input
                type="text"
                value={feedbackContact}
                onChange={(e) => setFeedbackContact(e.target.value)}
                placeholder="e.g. 9820123456"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Your Locality</label>
              <select
                value={feedbackLocality}
                onChange={(e) => setFeedbackLocality(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
              >
                <option value="Bhayandar West">Bhayandar West</option>
                <option value="Bhayandar East">Bhayandar East</option>
                <option value="Mira Road East">Mira Road East</option>
                <option value="Naya Nagar">Naya Nagar</option>
                <option value="Kashimira">Kashimira</option>
                <option value="Uttan Coastal">Uttan Coastal</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">Category</label>
              <select
                value={feedbackCategory}
                onChange={(e) => setFeedbackCategory(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
              >
                <option value="camps">Vaccination Camps</option>
                <option value="hospitals">Hospital Facilities & OPD</option>
                <option value="medicine_availability">Medicine Availability</option>
                <option value="translation">Language & Accessibility</option>
                <option value="general">General Suggestion</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-700 mb-1">Message / Suggestion *</label>
            <textarea
              rows={3}
              value={feedbackMessage}
              onChange={(e) => setFeedbackMessage(e.target.value)}
              placeholder="Tell us your experience or suggestion for Mira Bhayandar public health..."
              required
              className="w-full p-3.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="px-6 py-3 bg-teal-700 hover:bg-teal-800 text-white font-bold text-sm rounded-xl shadow-xs transition-colors flex items-center gap-2"
          >
            <Send className="w-4 h-4" />
            <span>Submit Feedback to MBMC</span>
          </button>
        </form>
      </div>
    </div>
  );
};
