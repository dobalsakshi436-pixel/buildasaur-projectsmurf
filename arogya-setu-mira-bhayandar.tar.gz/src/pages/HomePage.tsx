import React, { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import {
  Heart,
  Languages,
  Camera,
  MessageSquare,
  Calendar,
  MapPin,
  ShieldCheck,
  AlertTriangle,
  ArrowRight,
  Phone,
  Clock,
  Sparkles,
  Users,
  CheckCircle2,
  ChevronRight,
  Volume2,
  Eye,
  Pill,
  Building2,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useAccessibility } from '../context/AccessibilityContext';
import { HealthAdvisory, VaccinationCamp, Hospital } from '../types';

export const HomePage: React.FC = () => {
  const { t, currentLang, setIsModalOpen } = useLanguage();
  const { speakText } = useAccessibility();
  const navigate = useNavigate();

  const [advisories, setAdvisories] = useState<HealthAdvisory[]>([]);
  const [camps, setCamps] = useState<VaccinationCamp[]>([]);
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [advRes, campRes, hospRes] = await Promise.all([
          fetch('/api/advisories'),
          fetch('/api/camps'),
          fetch('/api/hospitals'),
        ]);

        if (advRes.ok) {
          const advData = await advRes.json();
          setAdvisories(advData.advisories?.slice(0, 3) || []);
        }
        if (campRes.ok) {
          const campData = await campRes.json();
          setCamps(campData.camps?.slice(0, 3) || []);
        }
        if (hospRes.ok) {
          const hospData = await hospRes.json();
          setHospitals(hospData.hospitals?.slice(0, 4) || []);
        }
      } catch (err) {
        console.error('Error fetching homepage data:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  return (
    <div className="space-y-10 pb-16">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-linear-to-b from-teal-800 via-teal-900 to-slate-900 text-white pt-10 pb-16 px-4 sm:px-6">
        <div className="absolute inset-0 bg-[radial-gradient(#2dd4bf_1px,transparent_1px)] [background-size:24px_24px] opacity-10"></div>
        <div className="max-w-7xl mx-auto relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Main Hero Copy */}
            <div className="lg:col-span-8 space-y-5">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-700/80 border border-teal-500/30 text-teal-200 text-xs sm:text-sm font-semibold backdrop-blur-xs">
                <ShieldCheck className="w-4 h-4 text-emerald-300" />
                <span>Mira Bhayandar Municipal Corporation • Public Health Cell</span>
              </div>

              <h1 className="text-2xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight">
                {t('appName', 'Arogya Setu Mira Bhayandar')}
              </h1>

              <p className="text-base sm:text-xl text-teal-100/90 max-w-2xl font-normal leading-relaxed">
                Health information in your mother tongue, in simple 5th-grade words. Free vaccination camp bookings, medicine strip scanner, and local hospital guides for elderly citizens and families.
              </p>

              {/* Local Area Highlight Tags */}
              <div className="flex flex-wrap items-center gap-2 pt-1 text-xs text-teal-200">
                <span className="font-bold text-white">Serving:</span>
                <span className="px-2.5 py-1 rounded-lg bg-white/10 border border-white/10">Bhayandar West</span>
                <span className="px-2.5 py-1 rounded-lg bg-white/10 border border-white/10">Mira Road East</span>
                <span className="px-2.5 py-1 rounded-lg bg-white/10 border border-white/10">Naya Nagar</span>
                <span className="px-2.5 py-1 rounded-lg bg-white/10 border border-white/10">Kashimira</span>
                <span className="px-2.5 py-1 rounded-lg bg-white/10 border border-white/10">Uttan Coastal</span>
              </div>

              {/* Quick Action CTA Bar */}
              <div className="pt-4 flex flex-wrap items-center gap-3">
                <Link
                  to="/book-slot"
                  className="px-6 py-3.5 bg-emerald-500 hover:bg-emerald-600 text-slate-950 font-extrabold text-sm sm:text-base rounded-xl shadow-lg shadow-emerald-500/20 transition-all transform hover:-translate-y-0.5 active:translate-y-0 flex items-center gap-2"
                >
                  <Calendar className="w-5 h-5 text-slate-950" />
                  {t('bookNowBtn', 'Book Free Camp / OPD Slot')}
                </Link>

                <Link
                  to="/hospitals"
                  className="px-5 py-3.5 bg-white/10 hover:bg-white/20 text-white font-bold text-sm sm:text-base rounded-xl border border-white/20 backdrop-blur-xs transition-all flex items-center gap-2"
                >
                  <MapPin className="w-5 h-5 text-teal-300" />
                  {t('navHospitals', 'Find Nearby Hospitals')}
                </Link>

                <button
                  onClick={() => setIsModalOpen(true)}
                  className="px-4 py-3.5 bg-teal-800/80 hover:bg-teal-700 text-teal-100 font-semibold text-sm rounded-xl border border-teal-600/40 transition-colors flex items-center gap-1.5"
                >
                  <Languages className="w-4 h-4 text-emerald-300" />
                  Change Language (100+)
                </button>
              </div>
            </div>

            {/* Quick Emergency Highlights Box */}
            <div className="lg:col-span-4">
              <div className="bg-white/10 backdrop-blur-md rounded-2xl p-5 border border-white/15 shadow-xl space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-white/10">
                  <div className="flex items-center gap-2">
                    <span className="w-3 h-3 rounded-full bg-red-500 animate-ping"></span>
                    <span className="text-sm font-bold text-white uppercase tracking-wider">Quick Helpline Desk</span>
                  </div>
                  <span className="text-xs text-teal-200">24x7 Active</span>
                </div>

                <div className="space-y-2.5">
                  <div className="p-3 bg-red-950/50 rounded-xl border border-red-500/30 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-red-200 block font-medium">Free Govt Ambulance</span>
                      <span className="text-lg font-black text-white">Call 108</span>
                    </div>
                    <a href="tel:108" className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-lg transition-colors shadow-xs">
                      Dial 108
                    </a>
                  </div>

                  <div className="p-3 bg-teal-950/50 rounded-xl border border-teal-500/30 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-teal-200 block font-medium">MBMC Health Control</span>
                      <span className="text-sm font-bold text-white">022-28112233</span>
                    </div>
                    <a href="tel:02228112233" className="px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-lg transition-colors">
                      Call MBMC
                    </a>
                  </div>

                  <div className="p-3 bg-slate-950/50 rounded-xl border border-slate-700 flex items-center justify-between">
                    <div>
                      <span className="text-xs text-slate-300 block font-medium">Temba Civil Hospital OPD</span>
                      <span className="text-sm font-bold text-white">022-28191244</span>
                    </div>
                    <Link to="/hospitals" className="text-xs text-teal-300 hover:underline font-semibold">
                      View OPD &rarr;
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3 Core Tools Highlight Cards */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 -mt-8 sm:-mt-12 relative z-20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Tool 1: Medicine Scanner */}
          <Link
            to="/scan-medicine"
            className="group bg-white p-6 rounded-2xl border border-slate-200 shadow-md hover:shadow-xl hover:border-teal-400 transition-all transform hover:-translate-y-1"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-teal-50 text-teal-700 flex items-center justify-center group-hover:bg-teal-700 group-hover:text-white transition-colors">
                <Camera className="w-6 h-6" />
              </div>
              <span className="px-2.5 py-1 rounded-full bg-teal-100 text-teal-800 text-xs font-bold">
                Camera / Upload OCR
              </span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 group-hover:text-teal-700 transition-colors">
              {t('navScanner', 'Scan Medicine Strip')}
            </h3>
            <p className="text-sm text-slate-600 mt-2 leading-relaxed">
              Take a photo or upload your medicine box. Get a plain-language explanation of dosage, purpose, and side effects in your language.
            </p>
            <div className="mt-4 flex items-center gap-1 text-sm font-bold text-teal-700 group-hover:gap-2 transition-all">
              <span>Scan your medicine now</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </Link>

          {/* Tool 2: Translate Medical Text */}
          <Link
            to="/translate"
            className="group bg-white p-6 rounded-2xl border border-slate-200 shadow-md hover:shadow-xl hover:border-cyan-400 transition-all transform hover:-translate-y-1"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-cyan-50 text-cyan-700 flex items-center justify-center group-hover:bg-cyan-700 group-hover:text-white transition-colors">
                <Languages className="w-6 h-6" />
              </div>
              <span className="px-2.5 py-1 rounded-full bg-cyan-100 text-cyan-800 text-xs font-bold">
                100+ Languages
              </span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 group-hover:text-cyan-700 transition-colors">
              {t('navTranslate', 'Translate Health Advice')}
            </h3>
            <p className="text-sm text-slate-600 mt-2 leading-relaxed">
              Paste or type doctor prescriptions, tests, or medical notices to translate instantly into Marathi, Hindi, Gujarati, or Urdu.
            </p>
            <div className="mt-4 flex items-center gap-1 text-sm font-bold text-cyan-700 group-hover:gap-2 transition-all">
              <span>Open Health Translator</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </Link>

          {/* Tool 3: Ask Health Bot */}
          <Link
            to="/chatbot"
            className="group bg-white p-6 rounded-2xl border border-slate-200 shadow-md hover:shadow-xl hover:border-emerald-400 transition-all transform hover:-translate-y-1"
          >
            <div className="flex items-center justify-between mb-4">
              <div className="w-12 h-12 rounded-xl bg-emerald-50 text-emerald-700 flex items-center justify-center group-hover:bg-emerald-700 group-hover:text-white transition-colors">
                <MessageSquare className="w-6 h-6" />
              </div>
              <span className="px-2.5 py-1 rounded-full bg-emerald-100 text-emerald-800 text-xs font-bold">
                24x7 Assistant
              </span>
            </div>
            <h3 className="text-lg font-bold text-slate-900 group-hover:text-emerald-700 transition-colors">
              {t('navChatbot', 'Ask Health Bot')}
            </h3>
            <p className="text-sm text-slate-600 mt-2 leading-relaxed">
              Ask about fever remedies, dengue symptoms, child vaccination schedules, and nearest MBMC checkup centers.
            </p>
            <div className="mt-4 flex items-center gap-1 text-sm font-bold text-emerald-700 group-hover:gap-2 transition-all">
              <span>Chat with Arogya Mitra</span>
              <ArrowRight className="w-4 h-4" />
            </div>
          </Link>
        </div>
      </section>

      {/* Latest Health Advisories Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
          <div>
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-red-500"></span>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900">
                {t('navAdvisories', 'Latest Health Alerts & Outbreak Warnings')}
              </h2>
            </div>
            <p className="text-sm text-slate-600 mt-1">
              Verified notices issued by Mira Bhayandar Municipal Corporation Public Health Dept.
            </p>
          </div>
          <Link
            to="/advisories"
            className="inline-flex items-center gap-1.5 text-sm font-bold text-teal-700 hover:text-teal-900 transition-colors"
          >
            <span>View All Advisories</span>
            <ChevronRight className="w-4 h-4" />
          </Link>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {advisories.map((adv) => {
            const isUrgent = adv.severity === 'urgent';
            return (
              <div
                key={adv.id}
                className="bg-white rounded-2xl p-5 border border-slate-200 shadow-2xs hover:shadow-md transition-shadow flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between gap-2 mb-3">
                    <span
                      className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider ${
                        isUrgent
                          ? 'bg-red-100 text-red-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {adv.category} • {adv.severity}
                    </span>
                    <span className="text-xs text-slate-500">{adv.date}</span>
                  </div>

                  <h3 className="font-bold text-base text-slate-900 line-clamp-2 leading-snug">
                    {adv.title}
                  </h3>

                  <div className="mt-3 p-3 bg-teal-50/60 rounded-xl border border-teal-100 text-xs text-slate-700 space-y-1">
                    <p className="font-semibold text-teal-900 flex items-center gap-1">
                      <Sparkles className="w-3 h-3 text-teal-600" />
                      Simple Language Summary:
                    </p>
                    <p className="line-clamp-3 leading-relaxed">
                      {adv.simpleText}
                    </p>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
                  <span className="text-slate-500 font-medium flex items-center gap-1">
                    <MapPin className="w-3.5 h-3.5 text-teal-700" />
                    {adv.locality}
                  </span>
                  <Link
                    to={`/advisories`}
                    className="font-bold text-teal-700 hover:underline"
                  >
                    Read Precautions &rarr;
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* Upcoming Vaccination Camps Highlight */}
      <section className="bg-teal-50/70 border-y border-teal-100 py-10 px-4 sm:px-6">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-6">
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-slate-900 flex items-center gap-2">
                <Calendar className="w-6 h-6 text-teal-700" />
                {t('navCamps', 'Upcoming Free Vaccination Camps in Mira Bhayandar')}
              </h2>
              <p className="text-sm text-slate-600 mt-1">
                Senior citizen flu drives, infant immunization catch-ups, and maternal tetanus camps.
              </p>
            </div>
            <Link
              to="/camps"
              className="inline-flex items-center gap-1.5 px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white font-bold text-sm rounded-xl shadow-xs transition-colors"
            >
              <span>Explore All Camps</span>
              <ChevronRight className="w-4 h-4" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {camps.map((camp) => (
              <div
                key={camp.id}
                className="bg-white rounded-2xl p-5 border border-teal-200 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between"
              >
                <div className="space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="px-2.5 py-1 rounded-md bg-teal-100 text-teal-900 font-bold text-xs uppercase">
                      {camp.targetGroup === 'elderly' ? 'Senior Citizens (60+)' : camp.targetGroup === 'children' ? 'Infants & Kids' : 'General Public'}
                    </span>
                    <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200">
                      {camp.availableSlots} of {camp.totalSlots} slots left
                    </span>
                  </div>

                  <h3 className="font-bold text-base text-slate-900 leading-snug">
                    {camp.name}
                  </h3>

                  <p className="text-xs text-slate-600 flex items-start gap-1.5">
                    <MapPin className="w-4 h-4 text-teal-700 shrink-0 mt-0.5" />
                    <span>{camp.address}</span>
                  </p>

                  <div className="grid grid-cols-2 gap-2 text-xs bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <div>
                      <span className="text-slate-500 block">Date</span>
                      <strong className="text-slate-800">{camp.date}</strong>
                    </div>
                    <div>
                      <span className="text-slate-500 block">Time</span>
                      <strong className="text-slate-800">{camp.timeRange}</strong>
                    </div>
                  </div>

                  <div>
                    <span className="text-[11px] text-slate-500 font-semibold block mb-1">Vaccines Available:</span>
                    <div className="flex flex-wrap gap-1">
                      {camp.vaccinesOffered.map((v, idx) => (
                        <span key={idx} className="px-2 py-0.5 bg-slate-100 text-slate-700 rounded text-[11px] font-medium">
                          {v}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center gap-2">
                  <Link
                    to={`/book-slot?type=camp&targetId=${camp.id}`}
                    className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl text-center shadow-xs transition-colors"
                  >
                    Book Slot Now
                  </Link>
                  <a
                    href={camp.googleMapsUrl}
                    target="_blank"
                    rel="noreferrer"
                    className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold text-xs rounded-xl transition-colors"
                    title="Get Directions on Google Maps"
                  >
                    <MapPin className="w-3.5 h-3.5" />
                  </a>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Nearby Hospitals & Pharmacies Teaser */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Municipal Hospitals List */}
          <div className="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-teal-700" />
                <h3 className="font-bold text-lg text-slate-900">MBMC Civil Hospitals & Health Centers</h3>
              </div>
              <Link to="/hospitals" className="text-xs font-bold text-teal-700 hover:underline">
                View Interactive Map &rarr;
              </Link>
            </div>

            <div className="space-y-3">
              {hospitals.map((hosp) => (
                <div key={hosp.id} className="p-3.5 rounded-xl bg-slate-50 border border-slate-200/80 hover:bg-teal-50/40 transition-colors flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-sm text-slate-900">{hosp.name}</h4>
                      {hosp.isFreeGovt && (
                        <span className="px-1.5 py-0.5 bg-emerald-100 text-emerald-800 text-[10px] font-bold rounded">
                          Free OPD
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-slate-600 mt-0.5">{hosp.locality} • {hosp.specialties.slice(0, 3).join(', ')}</p>
                    <p className="text-xs text-slate-500 font-mono mt-0.5">📞 {hosp.contactNumber}</p>
                  </div>
                  <Link
                    to={`/book-slot?type=hospital&targetId=${hosp.id}`}
                    className="px-3 py-1.5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-lg text-center shrink-0"
                  >
                    Book OPD Slot
                  </Link>
                </div>
              ))}
            </div>
          </div>

          {/* Subsidized Medicine & Jan Aushadhi Feature */}
          <div className="bg-linear-to-br from-cyan-900 to-teal-950 text-white rounded-2xl p-6 shadow-md flex flex-col justify-between space-y-4">
            <div className="space-y-3">
              <div className="inline-flex items-center gap-2 px-3 py-1 bg-cyan-800/80 rounded-full text-xs font-bold text-cyan-200">
                <Pill className="w-3.5 h-3.5" />
                Pradhan Mantri Jan Aushadhi & 24x7 Pharmacies
              </div>
              <h3 className="text-xl sm:text-2xl font-black text-white leading-tight">
                Find Medicines at 50% - 80% Lower Price in Mira Bhayandar
              </h3>
              <p className="text-sm text-cyan-100/90 leading-relaxed">
                Check real-time availability of Paracetamol, Diabetes (Metformin), Blood Pressure (Amlodipine), and Antibiotics in certified local stores across Bhayandar West, Mira Road, and Naya Nagar.
              </p>
            </div>

            <div className="p-4 bg-white/10 rounded-xl border border-white/15 space-y-2">
              <p className="text-xs font-bold text-cyan-200">Quick Local Chemist Directory:</p>
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div>• Jan Aushadhi Kendra (Station East)</div>
                <div>• Noble 24x7 Chemist (Temba Gate)</div>
                <div>• Wellness Forever (Beverly Park)</div>
                <div>• Apna Medical (Naya Nagar)</div>
              </div>
            </div>

            <Link
              to="/pharmacies"
              className="w-full py-3 bg-cyan-400 hover:bg-cyan-300 text-slate-950 font-extrabold text-sm rounded-xl text-center shadow-md transition-colors"
            >
              Search Medicine Stock Nearby &rarr;
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};
