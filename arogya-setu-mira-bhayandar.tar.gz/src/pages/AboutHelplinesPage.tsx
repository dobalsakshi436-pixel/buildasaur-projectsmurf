import React, { useState } from 'react';
import {
  Phone,
  Shield,
  MapPin,
  Clock,
  Send,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Building2,
  Heart,
  MessageSquare,
  Sparkles,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const AboutHelplinesPage: React.FC = () => {
  const { t } = useLanguage();

  const [feedbackName, setFeedbackName] = useState('');
  const [feedbackPhone, setFeedbackPhone] = useState('');
  const [feedbackLocality, setFeedbackLocality] = useState('Bhayandar West');
  const [feedbackCategory, setFeedbackCategory] = useState('mosquito');
  const [feedbackMessage, setFeedbackMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const emergencyNumbers = [
    {
      title: 'Free National Ambulance',
      number: '108',
      desc: '24x7 Government emergency ambulance service for accidents, cardiac events, and labor delivery.',
      badge: 'Immediate Response',
      color: 'red',
    },
    {
      title: 'MBMC Health Control Room',
      number: '022-28112233',
      desc: 'Mira Bhayandar Municipal Corporation central health desk for outbreak reports and medical inquiries.',
      badge: '24x7 Municipal Desk',
      color: 'teal',
    },
    {
      title: 'Senior Citizen Elderline',
      number: '14567',
      desc: 'National helpline for elderly support, medical aid assistance, and elder abuse prevention.',
      badge: 'Elderly Citizens',
      color: 'amber',
    },
    {
      title: 'Women in Distress & Maternity Support',
      number: '1091 / 181',
      desc: '24x7 helpline for women safety, maternal medical emergencies, and psychological support.',
      badge: 'Women Helpline',
      color: 'rose',
    },
    {
      title: 'Kashimira Trauma & Anti-Rabies Desk',
      number: '022-29452200',
      desc: '24-hour rabies vaccine, snakebite anti-venom, and highway accident emergency center.',
      badge: 'Trauma & Rabies',
      color: 'blue',
    },
    {
      title: 'Kiran National Mental Health Helpline',
      number: '1800-599-0019',
      desc: 'Free tele-counseling support for depression, anxiety, senior loneliness, and caregiver stress.',
      badge: 'Mental Wellness',
      color: 'purple',
    },
  ];

  const wardHealthPosts = [
    {
      ward: 'Ward 1 (Bhayandar West)',
      center: 'Temba Municipal Hospital UPHC',
      address: 'Near Old Bus Depot, Balaram Patil Marg, Bhayandar West',
      incharge: 'Dr. Ramesh Kulkarni (Medical Officer)',
      phone: '022-28191244',
      timings: '08:00 AM - 08:00 PM (OPD & Free Pharmacy)',
      specialties: 'Senior OPD, Dialysis, Pathology Lab, Pediatrics',
    },
    {
      ward: 'Ward 2 (Bhayandar East)',
      center: 'Jesal Park Community Health Post',
      address: 'Beside MBMC Community Hall, Jesal Park, Bhayandar East',
      incharge: 'Dr. Sunita Patil',
      phone: '022-28145590',
      timings: '09:00 AM - 04:00 PM',
      specialties: 'Child Vaccination, Diabetes Checkup, Blood Pressure Monitoring',
    },
    {
      ward: 'Ward 3 (Naya Nagar)',
      center: 'Naya Nagar Municipal Maternity & Child Hospital',
      address: 'Opp. Millat Nagar Ground, Mira Road East',
      incharge: 'Dr. Farhana Shaikh',
      phone: '022-28109922',
      timings: '24 Hours Emergency & Maternity',
      specialties: 'Normal Deliveries, Newborn Care, Immunization, Gynecologist OPD',
    },
    {
      ward: 'Ward 4 (Mira Road East)',
      center: 'Shanti Nagar Primary Health Center',
      address: 'Sector 4, Near Shanti Nagar High School, Mira Road',
      incharge: 'Dr. Anand Joshi',
      phone: '022-28124411',
      timings: '09:00 AM - 05:00 PM',
      specialties: 'General Physician OPD, Tuberculosis DOTS Center, Dengue Testing',
    },
    {
      ward: 'Ward 5 (Kashimira)',
      center: 'Kashimira Highway Health & Trauma Post',
      address: 'Near Kashimira Police Station, Western Express Highway',
      incharge: 'Dr. Vikram Rathod',
      phone: '022-29452200',
      timings: '24 Hours Open',
      specialties: 'Accident Trauma, Anti-Rabies Vaccination, Snakebite Treatment',
    },
    {
      ward: 'Ward 6 (Uttan Coastal)',
      center: 'Uttan Seacoast Rural Health Clinic',
      address: 'Near Uttan Church & Lighthouse Road, Uttan',
      incharge: 'Dr. Mary Fernandes',
      phone: '022-28451100',
      timings: '08:30 AM - 03:30 PM',
      specialties: 'Fishermen Community Health, Monsoon Illnesses, Child Health',
    },
  ];

  const handleFeedbackSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    // Simulate grievance ticket submission to backend
    setTimeout(() => {
      setLoading(false);
      setSubmitted(true);
      setFeedbackMessage('');
    }, 800);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-10">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-teal-900 via-slate-900 to-cyan-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/15 rounded-full text-xs font-bold uppercase tracking-wider">
          <Shield className="w-4 h-4 text-emerald-300" />
          MBMC Citizen Health Directory & Grievance Cell
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-white">
          Emergency Helplines & Ward Health Posts
        </h1>
        <p className="text-sm sm:text-base text-teal-100/90 leading-relaxed font-normal max-w-3xl">
          Complete directory of government ambulances, 24x7 control rooms, ward health posts in Bhayandar West, Mira Road, Naya Nagar, and Kashimira, with direct citizen feedback channels.
        </p>
      </div>

      {/* Emergency Helplines Grid */}
      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <Phone className="w-5 h-5 text-red-600" />
          <h2 className="text-xl font-bold text-slate-900">24x7 Emergency Helplines</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {emergencyNumbers.map((item, idx) => (
            <div
              key={idx}
              className="bg-white rounded-3xl p-5 border border-slate-200 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between space-y-4"
            >
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="px-2.5 py-0.5 rounded-full text-[11px] font-bold bg-slate-100 text-slate-700">
                    {item.badge}
                  </span>
                  <span className="text-xs font-bold text-emerald-700">24x7 Toll Free</span>
                </div>
                <h3 className="font-bold text-base text-slate-900 leading-snug">{item.title}</h3>
                <p className="text-xs text-slate-600 leading-relaxed">{item.desc}</p>
              </div>

              <div className="pt-3 border-t border-slate-100 flex items-center justify-between">
                <span className="text-lg font-black text-slate-950 font-mono">{item.number}</span>
                <a
                  href={`tel:${item.number.replace(/\s+/g, '')}`}
                  className="px-4 py-2 bg-teal-700 hover:bg-teal-800 text-white font-bold text-xs rounded-xl transition-colors shadow-2xs flex items-center gap-1.5"
                >
                  <Phone className="w-3.5 h-3.5" />
                  <span>Call Now</span>
                </a>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Ward Health Posts Directory */}
      <section className="space-y-4">
        <div className="flex items-center gap-2">
          <Building2 className="w-5 h-5 text-teal-700" />
          <h2 className="text-xl font-bold text-slate-900">
            Mira Bhayandar Municipal Corporation Ward Health Posts (UPHC)
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {wardHealthPosts.map((post, idx) => (
            <div
              key={idx}
              className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-3"
            >
              <div className="flex items-center justify-between">
                <span className="px-3 py-1 bg-teal-100 text-teal-900 rounded-full font-bold text-xs">
                  {post.ward}
                </span>
                <span className="text-xs text-slate-500 font-mono">{post.phone}</span>
              </div>

              <h3 className="text-base font-bold text-slate-900 leading-snug">{post.center}</h3>

              <div className="space-y-1.5 text-xs text-slate-600">
                <p className="flex items-start gap-1.5">
                  <MapPin className="w-3.5 h-3.5 text-teal-700 shrink-0 mt-0.5" />
                  <span>{post.address}</span>
                </p>
                <p className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-teal-700 shrink-0" />
                  <span>Timings: <strong className="text-slate-800">{post.timings}</strong></span>
                </p>
              </div>

              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100 text-xs">
                <span className="text-slate-500 font-semibold block">Key Health Services:</span>
                <span className="text-teal-900 font-medium">{post.specialties}</span>
              </div>

              <div className="pt-2 flex items-center justify-between text-xs">
                <span className="text-slate-500 font-medium">In-Charge: {post.incharge}</span>
                <a
                  href={`tel:${post.phone}`}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-teal-50 hover:text-teal-900 text-slate-800 font-bold rounded-lg transition-colors"
                >
                  📞 Call Center
                </a>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Citizen Feedback & Grievance Desk */}
      <section className="bg-linear-to-br from-slate-900 to-teal-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          <div className="lg:col-span-5 space-y-4">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/10 rounded-full text-xs font-bold text-teal-200">
              <MessageSquare className="w-4 h-4 text-emerald-300" />
              Public Grievance Redressal
            </div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white leading-tight">
              Report Health Issues or Send Feedback to MBMC
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed font-normal">
              Notice stagnant water causing mosquitoes? Medicine shortage at your local health center? Report directly to the Public Health Officer for fast-track resolution.
            </p>

            <div className="p-4 bg-white/10 rounded-2xl border border-white/10 text-xs space-y-1.5 text-teal-100">
              <p className="font-bold text-white">Direct Health Department Desk:</p>
              <p>📍 MBMC Main Headquarters, Bhayandar West 401101</p>
              <p>📧 healthofficer@mbmc.gov.in</p>
              <p>⏱️ Average resolution time: 24 - 48 hours</p>
            </div>
          </div>

          <div className="lg:col-span-7 bg-white text-slate-800 rounded-2xl p-6 shadow-2xl">
            {submitted ? (
              <div className="py-8 text-center space-y-3">
                <div className="w-14 h-14 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-8 h-8" />
                </div>
                <h3 className="text-xl font-bold text-slate-900">Grievance Ticket Generated!</h3>
                <p className="text-xs text-slate-600 max-w-md mx-auto">
                  Your ticket has been forwarded to the MBMC Ward Health Inspector. A confirmation SMS with tracking number has been sent to your number.
                </p>
                <button
                  onClick={() => setSubmitted(false)}
                  className="px-5 py-2 bg-teal-700 text-white font-bold text-xs rounded-xl shadow-xs"
                >
                  Submit Another Report
                </button>
              </div>
            ) : (
              <form onSubmit={handleFeedbackSubmit} className="space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                      Your Name
                    </label>
                    <input
                      type="text"
                      required
                      value={feedbackName}
                      onChange={(e) => setFeedbackName(e.target.value)}
                      placeholder="e.g. Ramesh Patil"
                      className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                      Mobile Number
                    </label>
                    <input
                      type="tel"
                      required
                      value={feedbackPhone}
                      onChange={(e) => setFeedbackPhone(e.target.value)}
                      placeholder="9820012345"
                      className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                      Ward / Locality
                    </label>
                    <select
                      value={feedbackLocality}
                      onChange={(e) => setFeedbackLocality(e.target.value)}
                      className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800"
                    >
                      <option value="Bhayandar West">Bhayandar West</option>
                      <option value="Bhayandar East">Bhayandar East</option>
                      <option value="Mira Road East">Mira Road East</option>
                      <option value="Naya Nagar">Naya Nagar</option>
                      <option value="Kashimira">Kashimira</option>
                      <option value="Uttan Coastal">Uttan Coastal</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                      Issue Category
                    </label>
                    <select
                      value={feedbackCategory}
                      onChange={(e) => setFeedbackCategory(e.target.value)}
                      className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium text-slate-800"
                    >
                      <option value="mosquito">🦟 Mosquito Breeding / Fogging Needed</option>
                      <option value="water">💧 Dirty Drinking Water Supply</option>
                      <option value="medicine">💊 Medicine Shortage at UPHC</option>
                      <option value="vaccine">💉 Vaccination Camp Query</option>
                      <option value="other">ℹ️ Other Public Health Matter</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                    Describe the Issue & Exact Location
                  </label>
                  <textarea
                    required
                    rows={3}
                    value={feedbackMessage}
                    onChange={(e) => setFeedbackMessage(e.target.value)}
                    placeholder="Provide specific details like building name, lane number, or hospital counter..."
                    className="w-full px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 bg-teal-700 hover:bg-teal-800 text-white font-extrabold text-xs sm:text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
                >
                  <Send className="w-4 h-4" />
                  <span>Submit Grievance to Health Cell</span>
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </div>
  );
};
