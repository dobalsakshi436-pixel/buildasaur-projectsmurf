import React, { useState, useEffect } from 'react';
import {
  Shield,
  Calendar,
  AlertTriangle,
  Users,
  CheckCircle,
  PlusCircle,
  Clock,
  MapPin,
  Search,
  Activity,
  FileText,
  Trash2,
  Building2,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { Booking, HealthAdvisory, VaccinationCamp } from '../types';

export const AdminPage: React.FC = () => {
  const { user } = useAuth();
  const [activeTab, setActiveTab] = useState<'bookings' | 'addCamp' | 'addAdvisory'>('bookings');

  const [bookings, setBookings] = useState<Booking[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');

  // New Camp Form State
  const [campName, setCampName] = useState('');
  const [campLocality, setCampLocality] = useState('Bhayandar West');
  const [campAddress, setCampAddress] = useState('');
  const [campDate, setCampDate] = useState('2025-06-15');
  const [campTime, setCampTime] = useState('09:00 AM - 02:00 PM');
  const [campGroup, setCampGroup] = useState<'elderly' | 'children' | 'pregnant_women' | 'all'>('elderly');
  const [campSlots, setCampSlots] = useState('80');
  const [campVaccines, setCampVaccines] = useState('Pneumococcal, Influenza (Flu), Senior Booster');
  const [campSuccess, setCampSuccess] = useState('');

  // New Advisory Form State
  const [advTitle, setAdvTitle] = useState('');
  const [advLocality, setAdvLocality] = useState('All Mira Bhayandar');
  const [advSeverity, setAdvSeverity] = useState<'info' | 'warning' | 'urgent'>('warning');
  const [advCategory, setAdvCategory] = useState('outbreak');
  const [advSimpleText, setAdvSimpleText] = useState('');
  const [advMedicalText, setAdvMedicalText] = useState('');
  const [advSymptoms, setAdvSymptoms] = useState('High fever, Joint pain, Rash behind eyes');
  const [advPrecautions, setAdvPrecautions] = useState('Empty stagnant water, Sleep under mosquito net, Drink boiled water');
  const [advSuccess, setAdvSuccess] = useState('');

  useEffect(() => {
    fetchBookings();
  }, []);

  const fetchBookings = async () => {
    try {
      const res = await fetch('/api/admin/bookings');
      if (res.ok) {
        const data = await res.json();
        setBookings(data.bookings || []);
      }
    } catch (err) {
      console.error('Failed to load admin bookings:', err);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (id: string, newStatus: 'confirmed' | 'attended' | 'cancelled') => {
    try {
      const res = await fetch(`/api/admin/bookings/${id}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus }),
      });
      if (res.ok) {
        setBookings((prev) =>
          prev.map((b) => (b.id === id ? { ...b, status: newStatus } : b))
        );
      }
    } catch (err) {
      alert('Failed to update status');
    }
  };

  const handleCreateCamp = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/camps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name: campName,
          locality: campLocality,
          address: campAddress,
          landmark: `${campLocality} Health Post`,
          date: campDate,
          timeRange: campTime,
          targetGroup: campGroup,
          totalSlots: parseInt(campSlots) || 50,
          availableSlots: parseInt(campSlots) || 50,
          vaccinesOffered: campVaccines.split(',').map((v) => v.trim()),
          contactNumber: '022-28112233',
        }),
      });

      if (res.ok) {
        setCampSuccess('New vaccination camp published to public portal successfully!');
        setCampName('');
        setCampAddress('');
        setTimeout(() => setCampSuccess(''), 4000);
      }
    } catch (err) {
      alert('Error creating camp');
    }
  };

  const handleCreateAdvisory = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const res = await fetch('/api/advisories', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: advTitle,
          locality: advLocality,
          severity: advSeverity,
          category: advCategory,
          simpleText: advSimpleText,
          medicalText: advMedicalText || advSimpleText,
          symptoms: advSymptoms.split(',').map((s) => s.trim()),
          precautions: advPrecautions.split(',').map((p) => p.trim()),
          actionHelpline: '022-28112233 / 108',
        }),
      });

      if (res.ok) {
        setAdvSuccess('Health alert notice published with plain-language summary!');
        setAdvTitle('');
        setAdvSimpleText('');
        setAdvMedicalText('');
        setTimeout(() => setAdvSuccess(''), 4000);
      }
    } catch (err) {
      alert('Error creating advisory');
    }
  };

  const filteredBookings = bookings.filter((b) => {
    const matchesSearch =
      b.userName.toLowerCase().includes(search.toLowerCase()) ||
      b.tokenNumber.toLowerCase().includes(search.toLowerCase()) ||
      b.userPhone.includes(search);
    const matchesStatus = statusFilter === 'all' || b.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-slate-900 via-teal-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-500/20 text-amber-300 border border-amber-500/30 rounded-full text-xs font-bold uppercase tracking-wider">
              <Shield className="w-4 h-4 text-amber-400" />
              Mira Bhayandar Municipal Corporation • Health Administration
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
              Public Health Officer Control Console
            </h1>
            <p className="text-sm text-slate-300 leading-relaxed font-normal">
              Manage live OPD & vaccination queues, post outbreak warning bulletins, and organize health drives across wards.
            </p>
          </div>
        </div>
      </div>

      {/* Tabs Toolbar */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2 overflow-x-auto">
        <button
          onClick={() => setActiveTab('bookings')}
          className={`px-5 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'bookings'
              ? 'bg-teal-700 text-white shadow-xs'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <Users className="w-4 h-4" />
          <span>Live Token Queue ({bookings.length})</span>
        </button>

        <button
          onClick={() => setActiveTab('addCamp')}
          className={`px-5 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'addCamp'
              ? 'bg-teal-700 text-white shadow-xs'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <PlusCircle className="w-4 h-4" />
          <span>Schedule New Vaccination Camp</span>
        </button>

        <button
          onClick={() => setActiveTab('addAdvisory')}
          className={`px-5 py-2.5 rounded-xl font-bold text-sm transition-all flex items-center gap-2 whitespace-nowrap ${
            activeTab === 'addAdvisory'
              ? 'bg-teal-700 text-white shadow-xs'
              : 'bg-white text-slate-700 hover:bg-slate-100 border border-slate-200'
          }`}
        >
          <AlertTriangle className="w-4 h-4" />
          <span>Issue Health Alert / Advisory</span>
        </button>
      </div>

      {/* TAB 1: Live Bookings & Queue Desk */}
      {activeTab === 'bookings' && (
        <div className="space-y-6">
          {/* Stats Bar */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-2xs">
              <span className="text-xs text-slate-500 font-bold uppercase block">Total Bookings</span>
              <span className="text-2xl font-black text-slate-900 mt-1 block">{bookings.length}</span>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-emerald-200 shadow-2xs">
              <span className="text-xs text-emerald-700 font-bold uppercase block">Confirmed Active</span>
              <span className="text-2xl font-black text-emerald-800 mt-1 block">
                {bookings.filter((b) => b.status === 'confirmed').length}
              </span>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-blue-200 shadow-2xs">
              <span className="text-xs text-blue-700 font-bold uppercase block">Attended & Vaccinated</span>
              <span className="text-2xl font-black text-blue-800 mt-1 block">
                {bookings.filter((b) => b.status === 'attended').length}
              </span>
            </div>
            <div className="bg-white p-5 rounded-2xl border border-rose-200 shadow-2xs">
              <span className="text-xs text-rose-700 font-bold uppercase block">Cancelled / Returned</span>
              <span className="text-2xl font-black text-rose-800 mt-1 block">
                {bookings.filter((b) => b.status === 'cancelled').length}
              </span>
            </div>
          </div>

          {/* Search and Filters */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200 flex flex-col sm:flex-row gap-3">
            <div className="flex-1 relative">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                placeholder="Search patient name, token number (e.g. MBMC-CMP-...), phone..."
                className="w-full pl-10 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-700"
            >
              <option value="all">All Statuses</option>
              <option value="confirmed">Confirmed Only</option>
              <option value="attended">Attended Only</option>
              <option value="cancelled">Cancelled Only</option>
            </select>
          </div>

          {/* Table */}
          <div className="bg-white rounded-3xl border border-slate-200 shadow-xs overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-700 font-bold uppercase tracking-wider">
                  <tr>
                    <th className="p-4">Token & Type</th>
                    <th className="p-4">Patient Name</th>
                    <th className="p-4">Center / Hospital</th>
                    <th className="p-4">Date & Slot</th>
                    <th className="p-4">Status</th>
                    <th className="p-4 text-right">Desk Action</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredBookings.map((b) => (
                    <tr key={b.id} className="hover:bg-slate-50/80 transition-colors">
                      <td className="p-4">
                        <span className="font-mono font-bold text-slate-900 block">{b.tokenNumber}</span>
                        <span className="text-[10px] text-slate-500 uppercase">{b.type}</span>
                      </td>
                      <td className="p-4">
                        <strong className="text-slate-900 block font-semibold">{b.userName}</strong>
                        <span className="text-slate-500">{b.userAge}y, {b.userGender} • 📞 {b.userPhone}</span>
                      </td>
                      <td className="p-4">
                        <span className="font-medium text-slate-800 block">{b.targetName}</span>
                        <span className="text-teal-700 text-[11px]">{b.specialtyOrVaccine}</span>
                      </td>
                      <td className="p-4">
                        <span className="font-semibold text-slate-900 block">{b.slotDate}</span>
                        <span className="text-slate-500">{b.slotTime}</span>
                      </td>
                      <td className="p-4">
                        <span
                          className={`px-2.5 py-0.5 rounded-full font-bold uppercase text-[10px] ${
                            b.status === 'confirmed'
                              ? 'bg-emerald-100 text-emerald-800'
                              : b.status === 'attended'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-red-100 text-red-800'
                          }`}
                        >
                          {b.status}
                        </span>
                      </td>
                      <td className="p-4 text-right">
                        <div className="flex items-center justify-end gap-1.5">
                          {b.status === 'confirmed' && (
                            <button
                              onClick={() => handleStatusChange(b.id, 'attended')}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-lg text-[11px]"
                            >
                              Mark Attended
                            </button>
                          )}
                          {b.status !== 'cancelled' && (
                            <button
                              onClick={() => handleStatusChange(b.id, 'cancelled')}
                              className="px-2 py-1 bg-slate-100 hover:bg-rose-50 text-rose-700 font-semibold rounded-lg text-[11px]"
                            >
                              Cancel
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                  {filteredBookings.length === 0 && (
                    <tr>
                      <td colSpan={6} className="p-8 text-center text-slate-500">
                        No bookings found matching query.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: Schedule New Camp */}
      {activeTab === 'addCamp' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm max-w-3xl space-y-6">
          <div className="border-b border-slate-100 pb-3">
            <h2 className="text-xl font-extrabold text-slate-900">
              Publish New Vaccination or Health Camp
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              The camp will be immediately visible for booking on the citizen portal with automated token generation.
            </p>
          </div>

          {campSuccess && (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-900 text-sm font-semibold flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600" />
              <span>{campSuccess}</span>
            </div>
          )}

          <form onSubmit={handleCreateCamp} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Camp Name / Title *
              </label>
              <input
                type="text"
                required
                value={campName}
                onChange={(e) => setCampName(e.target.value)}
                placeholder="e.g. Senior Citizen Pneumonia & Flu Vaccine Drive - Jesal Park"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Locality *
                </label>
                <select
                  value={campLocality}
                  onChange={(e) => setCampLocality(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800"
                >
                  <option value="Bhayandar West">Bhayandar West</option>
                  <option value="Bhayandar East">Bhayandar East</option>
                  <option value="Mira Road East">Mira Road East</option>
                  <option value="Naya Nagar">Naya Nagar</option>
                  <option value="Kashimira">Kashimira</option>
                  <option value="Uttan Coastal">Uttan Coastal</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Target Beneficiary Group *
                </label>
                <select
                  value={campGroup}
                  onChange={(e) => setCampGroup(e.target.value as any)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800"
                >
                  <option value="elderly">Senior Citizens (60+)</option>
                  <option value="children">Infants & Children (0-5 Yrs)</option>
                  <option value="pregnant_women">Pregnant Mothers & Women</option>
                  <option value="all">General Public</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Camp Date *
                </label>
                <input
                  type="date"
                  required
                  value={campDate}
                  onChange={(e) => setCampDate(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Time Slot Range *
                </label>
                <input
                  type="text"
                  required
                  value={campTime}
                  onChange={(e) => setCampTime(e.target.value)}
                  placeholder="09:00 AM - 02:00 PM"
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Total Available Slots *
                </label>
                <input
                  type="number"
                  required
                  value={campSlots}
                  onChange={(e) => setCampSlots(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium"
                />
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Vaccines Offered (Comma Separated)
                </label>
                <input
                  type="text"
                  required
                  value={campVaccines}
                  onChange={(e) => setCampVaccines(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium"
                />
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Full Address & Landmark *
              </label>
              <textarea
                required
                rows={2}
                value={campAddress}
                onChange={(e) => setCampAddress(e.target.value)}
                placeholder="e.g. MBMC Community Health Hall, Near Jesal Park Chaupati, Bhayandar East"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium"
              />
            </div>

            <button
              type="submit"
              className="px-6 py-3 bg-teal-700 hover:bg-teal-800 text-white font-extrabold text-sm rounded-xl shadow-md transition-colors"
            >
              Publish Camp to Portal
            </button>
          </form>
        </div>
      )}

      {/* TAB 3: Issue Health Advisory */}
      {activeTab === 'addAdvisory' && (
        <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm max-w-3xl space-y-6">
          <div className="border-b border-slate-100 pb-3">
            <h2 className="text-xl font-extrabold text-slate-900">
              Issue Official Health Advisory or Outbreak Alert
            </h2>
            <p className="text-xs text-slate-500 mt-1">
              Includes dual views: Plain 5th-grade simple language for citizens and official clinical text.
            </p>
          </div>

          {advSuccess && (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-900 text-sm font-semibold flex items-center gap-2">
              <CheckCircle className="w-4 h-4 text-emerald-600" />
              <span>{advSuccess}</span>
            </div>
          )}

          <form onSubmit={handleCreateAdvisory} className="space-y-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Advisory Headline / Title *
              </label>
              <input
                type="text"
                required
                value={advTitle}
                onChange={(e) => setAdvTitle(e.target.value)}
                placeholder="e.g. Monsoon Alert: Sudden Spike in Water-Borne Typhoid & Jaundice"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Severity Level *
                </label>
                <select
                  value={advSeverity}
                  onChange={(e) => setAdvSeverity(e.target.value as any)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800"
                >
                  <option value="warning">⚠️ Warning</option>
                  <option value="urgent">🚨 Urgent Outbreak</option>
                  <option value="info">ℹ️ General Info</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Locality *
                </label>
                <select
                  value={advLocality}
                  onChange={(e) => setAdvLocality(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800"
                >
                  <option value="All Mira Bhayandar">All Mira Bhayandar</option>
                  <option value="Bhayandar West">Bhayandar West</option>
                  <option value="Bhayandar East">Bhayandar East</option>
                  <option value="Mira Road East">Mira Road East</option>
                  <option value="Naya Nagar">Naya Nagar</option>
                  <option value="Kashimira">Kashimira</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                  Category *
                </label>
                <select
                  value={advCategory}
                  onChange={(e) => setAdvCategory(e.target.value)}
                  className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800"
                >
                  <option value="outbreak">🦟 Outbreak</option>
                  <option value="monsoon">🌧️ Monsoon</option>
                  <option value="elderly">👵 Senior Health</option>
                  <option value="maternal">👶 Maternal</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Plain-Language Citizen Summary (5th-Grade Simple) *
              </label>
              <textarea
                required
                rows={3}
                value={advSimpleText}
                onChange={(e) => setAdvSimpleText(e.target.value)}
                placeholder="Explain in very easy words what is happening and what residents must do."
                className="w-full px-4 py-2.5 bg-teal-50/60 border border-teal-200 rounded-xl text-sm font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Key Symptoms (Comma Separated)
              </label>
              <input
                type="text"
                value={advSymptoms}
                onChange={(e) => setAdvSymptoms(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1">
                Precautions (Comma Separated)
              </label>
              <input
                type="text"
                value={advPrecautions}
                onChange={(e) => setAdvPrecautions(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium"
              />
            </div>

            <button
              type="submit"
              className="px-6 py-3 bg-red-700 hover:bg-red-800 text-white font-extrabold text-sm rounded-xl shadow-md transition-colors"
            >
              Broadcast Alert to Residents
            </button>
          </form>
        </div>
      )}
    </div>
  );
};
