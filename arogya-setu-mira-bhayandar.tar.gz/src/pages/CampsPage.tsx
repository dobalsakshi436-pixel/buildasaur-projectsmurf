import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  Calendar,
  MapPin,
  Clock,
  Users,
  Search,
  Filter,
  CheckCircle2,
  ExternalLink,
  ShieldCheck,
  Phone,
  Sparkles,
  Baby,
  HeartHandshake,
  AlertCircle,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { VaccinationCamp } from '../types';

export const CampsPage: React.FC = () => {
  const { t } = useLanguage();
  const [camps, setCamps] = useState<VaccinationCamp[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedLocality, setSelectedLocality] = useState('all');
  const [selectedGroup, setSelectedGroup] = useState('all');
  const [search, setSearch] = useState('');

  useEffect(() => {
    const fetchCamps = async () => {
      try {
        const params = new URLSearchParams();
        if (selectedLocality !== 'all') params.append('locality', selectedLocality);
        if (selectedGroup !== 'all') params.append('targetGroup', selectedGroup);
        if (search) params.append('search', search);

        const res = await fetch(`/api/camps?${params.toString()}`);
        if (res.ok) {
          const data = await res.json();
          setCamps(data.camps || []);
        }
      } catch (err) {
        console.error('Error fetching camps:', err);
      } finally {
        setLoading(false);
      }
    };

    fetchCamps();
  }, [selectedLocality, selectedGroup, search]);

  const targetGroups = [
    { value: 'all', label: 'All Target Groups', icon: Users },
    { value: 'elderly', label: 'Elderly Citizens (60+ Years)', icon: HeartHandshake },
    { value: 'children', label: 'Infants & Children (0-5 Yrs)', icon: Baby },
    { value: 'pregnant_women', label: 'Pregnant Mothers & Women', icon: Sparkles },
  ];

  const localities = [
    'all',
    'Bhayandar West',
    'Bhayandar East',
    'Mira Road East',
    'Naya Nagar',
    'Kashimira',
    'Uttan Coastal',
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-teal-800 via-emerald-800 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl relative overflow-hidden">
        <div className="relative z-10 space-y-3 max-w-3xl">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-700/80 rounded-full text-emerald-100 text-xs font-bold uppercase tracking-wider border border-emerald-500/40">
            <ShieldCheck className="w-4 h-4 text-emerald-300" />
            100% Free Government & Municipal Vaccination Camps
          </div>
          <h1 className="text-2xl sm:text-4xl font-extrabold tracking-tight text-white leading-tight">
            {t('navCamps', 'Free Vaccination & Health Camps in Mira Bhayandar')}
          </h1>
          <p className="text-sm sm:text-base text-teal-100/90 leading-relaxed font-normal">
            Pre-book your confirmed entry token to avoid waiting in long queues. Free childhood vaccines, senior citizen pneumonia/flu jabs, and pregnant mother health checkup camps across all MBMC wards.
          </p>
        </div>
      </div>

      {/* Target Group Selector Pills */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {targetGroups.map((grp) => {
          const isSelected = selectedGroup === grp.value;
          const Icon = grp.icon;
          return (
            <button
              key={grp.value}
              onClick={() => setSelectedGroup(grp.value)}
              className={`p-3.5 rounded-2xl text-left flex items-center gap-3 transition-all border ${
                isSelected
                  ? 'bg-teal-800 text-white border-teal-700 shadow-md ring-2 ring-teal-600'
                  : 'bg-white text-slate-700 border-slate-200 hover:border-teal-300 hover:bg-teal-50/50'
              }`}
            >
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${isSelected ? 'bg-white/20' : 'bg-teal-50 text-teal-700'}`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="leading-tight">
                <span className="block text-xs font-bold">{grp.label}</span>
              </div>
            </button>
          );
        })}
      </div>

      {/* Filter and Search Bar */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-sm space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search camp by name, landmark, or vaccine..."
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-600 focus:bg-white"
            />
          </div>

          {/* Locality Dropdown */}
          <div>
            <select
              value={selectedLocality}
              onChange={(e) => setSelectedLocality(e.target.value)}
              className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-600"
            >
              <option value="all">All Mira Bhayandar Localities</option>
              {localities.filter(l => l !== 'all').map((loc) => (
                <option key={loc} value={loc}>
                  {loc}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between text-xs text-slate-500 pt-2 border-t border-slate-100">
          <span>Found <strong>{camps.length}</strong> upcoming vaccination camps</span>
          <span className="text-emerald-700 font-semibold flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            Instant Digital Token Generation with QR Pass
          </span>
        </div>
      </div>

      {/* Camps List Grid */}
      {loading ? (
        <div className="p-12 text-center text-slate-500 font-medium bg-white rounded-2xl border border-slate-200">
          Loading upcoming camp schedules...
        </div>
      ) : camps.length === 0 ? (
        <div className="p-12 text-center bg-white rounded-2xl border border-slate-200 space-y-3">
          <AlertCircle className="w-10 h-10 text-slate-400 mx-auto" />
          <h3 className="text-lg font-bold text-slate-800">No camps found matching criteria</h3>
          <p className="text-sm text-slate-500">Please try selecting a different target group or locality.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {camps.map((camp) => {
            const slotsPercent = Math.round((camp.availableSlots / camp.totalSlots) * 100);
            const isAlmostFull = camp.availableSlots <= 10;
            const isFull = camp.availableSlots === 0;

            return (
              <div
                key={camp.id}
                className="bg-white rounded-3xl p-6 border border-teal-200/80 shadow-sm hover:shadow-md transition-shadow flex flex-col justify-between space-y-5"
              >
                <div className="space-y-4">
                  {/* Top Status Badges */}
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <span className="px-3 py-1 bg-teal-100 text-teal-900 font-bold text-xs rounded-full uppercase tracking-wider">
                      {camp.targetGroup === 'elderly'
                        ? '👵 Senior Citizens (60+)'
                        : camp.targetGroup === 'children'
                        ? '👶 Infant Immunization'
                        : camp.targetGroup === 'pregnant_women'
                        ? '🤰 Maternal Health'
                        : '🌐 Open for All'}
                    </span>

                    {/* Real-Time Slots Remaining */}
                    <div
                      className={`px-3 py-1 rounded-full text-xs font-extrabold flex items-center gap-1.5 ${
                        isFull
                          ? 'bg-slate-100 text-slate-700'
                          : isAlmostFull
                          ? 'bg-amber-100 text-amber-900 border border-amber-300 animate-pulse'
                          : 'bg-emerald-100 text-emerald-900 border border-emerald-300'
                      }`}
                    >
                      <span className={`w-2 h-2 rounded-full ${isFull ? 'bg-slate-400' : isAlmostFull ? 'bg-amber-500' : 'bg-emerald-500'}`}></span>
                      {isFull ? 'Camp Full' : `${camp.availableSlots} of ${camp.totalSlots} Slots Available`}
                    </div>
                  </div>

                  {/* Camp Title & Address */}
                  <div>
                    <h2 className="text-xl font-bold text-slate-900 leading-snug">
                      {camp.name}
                    </h2>
                    <p className="text-xs text-teal-800 font-semibold mt-1 flex items-center gap-1">
                      <MapPin className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                      {camp.locality} • Landmark: {camp.landmark}
                    </p>
                  </div>

                  <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                    <strong>Address:</strong> {camp.address}
                  </p>

                  {/* Date & Time Grid */}
                  <div className="grid grid-cols-2 gap-3 text-xs bg-teal-50/50 p-3 rounded-2xl border border-teal-100">
                    <div className="flex items-center gap-2">
                      <Calendar className="w-4 h-4 text-teal-700 shrink-0" />
                      <div>
                        <span className="text-slate-500 block">Camp Date</span>
                        <strong className="text-slate-900 text-sm">{camp.date}</strong>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-teal-700 shrink-0" />
                      <div>
                        <span className="text-slate-500 block">Operating Hours</span>
                        <strong className="text-slate-900 text-sm">{camp.timeRange}</strong>
                      </div>
                    </div>
                  </div>

                  {/* Vaccines Offered Chips */}
                  <div>
                    <span className="text-xs font-bold text-slate-700 block mb-1.5">
                      Vaccines & Health Services Provided:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {camp.vaccinesOffered.map((v, i) => (
                        <span
                          key={i}
                          className="px-2.5 py-1 bg-teal-50 text-teal-900 border border-teal-200 rounded-lg text-xs font-semibold"
                        >
                          ✓ {v}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Card Actions Footer */}
                <div className="pt-4 border-t border-slate-100 flex items-center justify-between gap-3">
                  <div className="flex items-center gap-1.5 text-xs text-slate-600">
                    <Phone className="w-3.5 h-3.5 text-teal-700" />
                    <span>Inquiry: <strong>{camp.contactNumber}</strong></span>
                  </div>

                  <div className="flex items-center gap-2">
                    <a
                      href={camp.googleMapsUrl}
                      target="_blank"
                      rel="noreferrer"
                      className="px-3 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 font-semibold text-xs rounded-xl flex items-center gap-1 transition-colors"
                      title="Open Google Maps"
                    >
                      <MapPin className="w-3.5 h-3.5 text-teal-700" />
                      <span className="hidden sm:inline">Directions</span>
                    </a>

                    <Link
                      to={`/book-slot?type=camp&targetId=${camp.id}`}
                      className={`px-5 py-2.5 rounded-xl font-bold text-xs shadow-xs transition-all ${
                        isFull
                          ? 'bg-slate-200 text-slate-500 cursor-not-allowed pointer-events-none'
                          : 'bg-emerald-600 hover:bg-emerald-700 text-white active:scale-98'
                      }`}
                    >
                      {isFull ? 'Camp Full' : 'Book Free Slot'}
                    </Link>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
