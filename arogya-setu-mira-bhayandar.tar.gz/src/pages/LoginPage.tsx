import React, { useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import {
  Heart,
  Phone,
  User,
  MapPin,
  Globe,
  ShieldCheck,
  CheckCircle,
  ArrowRight,
  Sparkles,
  Lock,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

export const LoginPage: React.FC = () => {
  const { login, demoLogin } = useAuth();
  const { currentLang, t } = useLanguage();
  const navigate = useNavigate();
  const location = useLocation();

  const from = (location.state as any)?.from?.pathname || '/';

  const [isRegister, setIsRegister] = useState(false);
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [locality, setLocality] = useState('Bhayandar West');
  const [preferredLang, setPreferredLang] = useState(currentLang || 'mr');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const localities = [
    'Bhayandar West',
    'Bhayandar East',
    'Mira Road East',
    'Naya Nagar',
    'Kashimira',
    'Uttan Coastal',
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!phone || phone.length < 10) {
      setError('Please enter a valid 10-digit mobile number');
      return;
    }

    if (isRegister && !name.trim()) {
      setError('Please enter your full name');
      return;
    }

    setLoading(true);
    try {
      await login(phone, isRegister ? { name, locality, preferredLanguage: preferredLang } : undefined);
      navigate(from, { replace: true });
    } catch (err: any) {
      setError(err.message || 'Login failed. Please check details.');
    } finally {
      setLoading(false);
    }
  };

  const handleDemo = (role: 'resident' | 'admin') => {
    demoLogin(role);
    navigate(role === 'admin' ? '/admin' : from, { replace: true });
  };

  return (
    <div className="max-w-xl mx-auto px-4 py-10">
      <div className="bg-white rounded-3xl border border-slate-200 shadow-xl overflow-hidden">
        {/* Header */}
        <div className="p-6 sm:p-8 bg-linear-to-r from-teal-800 to-cyan-900 text-white space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/15 rounded-full text-xs font-bold uppercase tracking-wider backdrop-blur-xs">
            <ShieldCheck className="w-4 h-4 text-emerald-300" />
            Mira Bhayandar Resident Health ID Portal
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
            {isRegister ? 'Create Resident Account' : 'Resident & Patient Login'}
          </h1>
          <p className="text-sm text-teal-100/90 leading-relaxed font-normal">
            Access your saved vaccination passes, hospital OPD tokens, and personalized local health alerts in simple language.
          </p>
        </div>

        {/* Quick Demo Selector */}
        <div className="p-4 bg-teal-50/70 border-b border-teal-100 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
          <span className="font-semibold text-teal-950 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-teal-600" />
            Quick Demo Login (No SMS OTP required):
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleDemo('resident')}
              className="px-3 py-1.5 bg-teal-700 hover:bg-teal-800 text-white font-bold rounded-lg transition-colors shadow-2xs"
            >
              👵 Elderly Resident
            </button>
            <button
              onClick={() => handleDemo('admin')}
              className="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 font-black rounded-lg transition-colors shadow-2xs"
            >
              🛡️ MBMC Admin
            </button>
          </div>
        </div>

        {/* Form Body */}
        <div className="p-6 sm:p-8 space-y-6">
          {error && (
            <div className="p-3.5 bg-rose-50 border border-rose-200 rounded-xl text-rose-800 text-xs font-semibold">
              {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            {isRegister && (
              <div>
                <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                  Full Name / नाव *
                </label>
                <div className="relative">
                  <User className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    required
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    placeholder="e.g. Shakuntala Devi Sharma"
                    className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600 focus:bg-white"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Mobile Number / मोबाईल क्रमांक *
              </label>
              <div className="relative flex">
                <span className="inline-flex items-center px-3.5 bg-slate-100 border border-r-0 border-slate-200 rounded-l-xl text-xs font-bold text-slate-600">
                  +91
                </span>
                <input
                  type="tel"
                  required
                  maxLength={10}
                  value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                  placeholder="9820012345"
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-r-xl text-sm font-semibold tracking-wider focus:outline-none focus:ring-2 focus:ring-teal-600 focus:bg-white"
                />
              </div>
              <p className="text-[11px] text-slate-500 mt-1">
                Used to deliver token alerts and OPD appointment slips via SMS.
              </p>
            </div>

            {isRegister && (
              <>
                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                    Your Locality in Mira Bhayandar / परिसर *
                  </label>
                  <div className="relative">
                    <MapPin className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <select
                      value={locality}
                      onChange={(e) => setLocality(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-600"
                    >
                      {localities.map((loc) => (
                        <option key={loc} value={loc}>
                          {loc}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                    Preferred Language / पसंतीची भाषा
                  </label>
                  <div className="relative">
                    <Globe className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <select
                      value={preferredLang}
                      onChange={(e) => setPreferredLang(e.target.value)}
                      className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-600"
                    >
                      <option value="mr">मराठी (Marathi)</option>
                      <option value="hi">हिंदी (Hindi)</option>
                      <option value="gu">ગુજરાતી (Gujarati)</option>
                      <option value="ur">اردو (Urdu)</option>
                      <option value="en">English</option>
                    </select>
                  </div>
                </div>
              </>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full py-3.5 bg-teal-700 hover:bg-teal-800 text-white font-extrabold text-sm rounded-xl shadow-md transition-all flex items-center justify-center gap-2"
            >
              <span>{isRegister ? 'Register & Continue' : 'Verify & Continue'}</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          {/* Toggle Register / Login */}
          <div className="text-center pt-2">
            <button
              onClick={() => {
                setIsRegister(!isRegister);
                setError('');
              }}
              className="text-xs font-bold text-teal-700 hover:underline"
            >
              {isRegister
                ? 'Already have an account? Sign In'
                : "New to Arogya Setu? Register Free Account"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
