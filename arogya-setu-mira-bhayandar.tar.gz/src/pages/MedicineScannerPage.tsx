import React, { useState, useRef } from 'react';
import { createWorker } from 'tesseract.js';
import {
  Camera,
  UploadCloud,
  Pill,
  Sparkles,
  Volume2,
  VolumeX,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  FileText,
  Loader2,
  ShieldCheck,
  RefreshCw,
  Info,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useAccessibility } from '../context/AccessibilityContext';
import { MedicineInfo } from '../types';

export const MedicineScannerPage: React.FC = () => {
  const { t, currentLang } = useLanguage();
  const { speakText, stopSpeaking, isSpeaking } = useAccessibility();

  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [extractedText, setExtractedText] = useState<string>('');
  const [manualText, setManualText] = useState<string>('');
  const [ocrProgress, setOcrProgress] = useState<number>(0);
  const [ocrStatus, setOcrStatus] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [medicineInfo, setMedicineInfo] = useState<MedicineInfo | null>(null);
  const [error, setError] = useState<string | null>(null);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const sampleMedicines = [
    { label: 'Dolo 650 (Paracetamol)', text: 'DOLO 650 Paracetamol Tablets IP 650mg Micro Labs Fever Pain' },
    { label: 'Amoxicillin 500mg', text: 'Mox 500 Amoxicillin Capsules IP 500mg Ranbaxy Antibiotic' },
    { label: 'Glycomet 500 (Metformin)', text: 'Glycomet 500 Metformin Hydrochloride Tablets IP 500mg Sugar' },
    { label: 'Amlong 5 (Amlodipine)', text: 'Amlong 5 Amlodipine Besylate Tablets IP 5mg Micro Labs BP' },
    { label: 'Electral ORS Powder', text: 'Electral Oral Rehydration Salts WHO Formula FDC Dehydration' },
  ];

  // Process text with backend interpreter
  const interpretMedicine = async (rawText: string) => {
    try {
      setIsProcessing(true);
      setError(null);
      setOcrStatus('Analyzing active ingredients & generating plain-language guidance...');

      const res = await fetch('/api/scan-medicine', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ocrText: rawText,
          targetLang: currentLang,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Failed to interpret medicine.');
      }

      setMedicineInfo(data.medicineInfo);
    } catch (err: any) {
      setError(err.message || 'Error processing medicine information.');
    } finally {
      setIsProcessing(false);
      setOcrStatus('');
    }
  };

  // Run Tesseract OCR on selected image
  const processImageOCR = async (imageDataUrl: string) => {
    setIsProcessing(true);
    setError(null);
    setOcrProgress(0);
    setOcrStatus('Starting OCR engine...');

    try {
      const worker = await createWorker('eng');

      setOcrStatus('Reading text from medicine strip...');
      const ret = await worker.recognize(imageDataUrl);

      const text = ret.data.text.trim();
      setExtractedText(text);

      await worker.terminate();

      if (text.length < 3) {
        throw new Error('Could not clearly read text on this image. Please ensure good lighting or type the medicine name below.');
      }

      // Send extracted text to interpreter
      await interpretMedicine(text);
    } catch (err: any) {
      setError(err.message || 'OCR extraction failed. Please try typing the medicine name manually.');
      setIsProcessing(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const dataUrl = event.target?.result as string;
      setImageSrc(dataUrl);
      processImageOCR(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualText.trim()) return;
    setExtractedText(manualText);
    interpretMedicine(manualText);
  };

  const handleSampleClick = (sampleText: string) => {
    setManualText(sampleText);
    setExtractedText(sampleText);
    interpretMedicine(sampleText);
  };

  const handleReadAloud = () => {
    if (!medicineInfo) return;
    if (isSpeaking) {
      stopSpeaking();
    } else {
      const textToSpeak = `${medicineInfo.detectedMedicineName || 'Medicine'}. ${medicineInfo.simplePurpose}. Dosage notes: ${medicineInfo.dosageNotes}. Precautions: ${medicineInfo.precautions.join('. ')}. Disclaimer: ${medicineInfo.warningDisclaimer || ''}`;
      speakText(textToSpeak, currentLang);
    }
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-teal-800 via-emerald-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-700/80 rounded-full text-emerald-100 text-xs font-bold uppercase tracking-wider">
          <Pill className="w-4 h-4 text-emerald-300" />
          Smart OCR Medicine Reader for Elderly & Families
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-white">
          Scan Medicine Strip, Foil or Box
        </h1>
        <p className="text-sm sm:text-base text-teal-100/90 leading-relaxed font-normal max-w-3xl">
          Take a photo or upload an image of your medicine foil strip. Our scanner extracts the tablet name and explains its purpose, dosage timings, and safety warnings in simple words in your language.
        </p>
      </div>

      {/* Quick Sample Prescriptions / Strips */}
      <div className="bg-white rounded-2xl p-4 sm:p-5 border border-slate-200 shadow-2xs space-y-2">
        <span className="text-xs font-bold text-slate-700 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-teal-600" />
          Don't have a photo? Test with common Mira Bhayandar medicines:
        </span>
        <div className="flex flex-wrap gap-2">
          {sampleMedicines.map((m, idx) => (
            <button
              key={idx}
              onClick={() => handleSampleClick(m.text)}
              className="px-3 py-1.5 bg-teal-50/70 hover:bg-teal-100 text-teal-900 border border-teal-200 rounded-xl text-xs font-bold transition-colors"
            >
              💊 {m.label}
            </button>
          ))}
        </div>
      </div>

      {/* Main Upload / Camera & Text Card */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left Column: Image Upload & OCR */}
        <div className="md:col-span-6 bg-white rounded-3xl p-6 border border-slate-200 shadow-sm space-y-4">
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <Camera className="w-5 h-5 text-teal-700" />
            Upload Photo or Capture Strip
          </h2>

          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept="image/*"
            capture="environment"
            className="hidden"
          />

          {/* Upload Dropzone */}
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-teal-300 hover:border-teal-500 bg-teal-50/30 hover:bg-teal-50/60 rounded-2xl p-6 text-center cursor-pointer transition-all flex flex-col items-center justify-center gap-3 min-h-[200px]"
          >
            {imageSrc ? (
              <div className="relative w-full">
                <img
                  src={imageSrc}
                  alt="Medicine strip preview"
                  className="max-h-48 mx-auto rounded-xl object-contain border border-teal-200"
                />
                <p className="text-xs text-teal-700 font-bold mt-2">Click to replace photo</p>
              </div>
            ) : (
              <>
                <div className="w-14 h-14 rounded-full bg-teal-100 text-teal-700 flex items-center justify-center">
                  <UploadCloud className="w-7 h-7" />
                </div>
                <div>
                  <p className="text-sm font-bold text-slate-900">Click to capture / upload medicine strip</p>
                  <p className="text-xs text-slate-500 mt-0.5">Supports JPG, PNG, WEBP camera photos</p>
                </div>
                <button
                  type="button"
                  className="px-4 py-2 bg-teal-700 text-white rounded-xl text-xs font-bold shadow-xs hover:bg-teal-800 transition-colors"
                >
                  Open Camera / Browse
                </button>
              </>
            )}
          </div>

          {/* OCR Processing Status */}
          {isProcessing && (
            <div className="p-4 bg-teal-50 rounded-2xl border border-teal-200 space-y-2">
              <div className="flex items-center gap-2 text-teal-900 font-bold text-xs">
                <Loader2 className="w-4 h-4 animate-spin text-teal-700" />
                <span>{ocrStatus || 'Scanning medicine...'}</span>
              </div>
            </div>
          )}

          {/* Manual Text Input Fallback */}
          <div className="pt-3 border-t border-slate-100">
            <p className="text-xs text-slate-500 font-semibold mb-2">Or type the name printed on the box:</p>
            <form onSubmit={handleManualSubmit} className="flex gap-2">
              <input
                type="text"
                value={manualText}
                onChange={(e) => setManualText(e.target.value)}
                placeholder="e.g. Paracetamol 650 or Pantocid 40"
                className="flex-1 px-3.5 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
              <button
                type="submit"
                disabled={!manualText.trim() || isProcessing}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-900 disabled:opacity-50 text-white font-bold text-xs rounded-xl transition-colors"
              >
                Explain
              </button>
            </form>
          </div>
        </div>

        {/* Right Column: Plain Language Explanation */}
        <div className="md:col-span-6 space-y-4">
          {error && (
            <div className="p-4 bg-red-50 border border-red-200 rounded-2xl flex items-start gap-3 text-xs text-red-800">
              <AlertTriangle className="w-4 h-4 text-red-600 shrink-0 mt-0.5" />
              <span>{error}</span>
            </div>
          )}

          {medicineInfo ? (
            <div className="bg-white rounded-3xl p-6 border border-teal-300 shadow-md space-y-5 animate-in fade-in duration-300">
              {/* Header */}
              <div className="flex items-start justify-between gap-3 pb-4 border-b border-slate-100">
                <div>
                  <span className="px-2.5 py-0.5 bg-teal-100 text-teal-900 rounded-full text-xs font-bold uppercase">
                    {medicineInfo.category || 'Prescription Medicine'}
                  </span>
                  <h2 className="text-xl font-black text-slate-900 mt-1 leading-snug">
                    {medicineInfo.detectedMedicineName || medicineInfo.name}
                  </h2>
                </div>

                <button
                  onClick={handleReadAloud}
                  className={`flex items-center gap-1 px-3 py-1.5 rounded-xl text-xs font-bold transition-colors ${
                    isSpeaking
                      ? 'bg-amber-500 text-slate-950 font-bold'
                      : 'bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-200'
                  }`}
                  title="Listen to medicine instructions"
                >
                  {isSpeaking ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  <span>{isSpeaking ? 'Stop Voice' : 'Listen'}</span>
                </button>
              </div>

              {/* Plain Language Purpose */}
              <div className="p-4 bg-teal-50/80 rounded-2xl border border-teal-200 space-y-1.5">
                <span className="text-xs font-extrabold uppercase tracking-wider text-teal-900 flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-teal-600" />
                  What is this medicine used for (Simple Words):
                </span>
                <p className="text-sm text-slate-900 leading-relaxed font-medium">
                  {medicineInfo.simplePurpose}
                </p>
              </div>

              {/* Dosage & Usage Notes */}
              <div className="space-y-1.5">
                <span className="text-xs font-bold text-slate-800 block">
                  How to Take (Dosage Guidelines):
                </span>
                <p className="text-xs sm:text-sm text-slate-700 bg-slate-50 p-3 rounded-xl border border-slate-200 leading-relaxed">
                  {medicineInfo.dosageNotes}
                </p>
              </div>

              {/* Side Effects & Precautions */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-amber-50/70 rounded-xl border border-amber-200 space-y-1">
                  <span className="font-bold text-amber-900 block">Common Side Effects:</span>
                  <ul className="list-disc pl-4 space-y-0.5 text-slate-700">
                    {medicineInfo.commonSideEffects?.map((se, i) => (
                      <li key={i}>{se}</li>
                    ))}
                  </ul>
                </div>

                <div className="p-3 bg-emerald-50/70 rounded-xl border border-emerald-200 space-y-1">
                  <span className="font-bold text-emerald-900 block">Key Precautions:</span>
                  <ul className="list-disc pl-4 space-y-0.5 text-slate-700">
                    {medicineInfo.precautions?.map((p, i) => (
                      <li key={i}>{p}</li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Warning / Doctor Disclaimer */}
              <div className="p-3 bg-rose-50 rounded-xl border border-rose-200 text-xs text-rose-900 space-y-1">
                <p className="font-bold flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-rose-700" />
                  Important Health Safety Notice:
                </p>
                <p className="leading-relaxed">
                  {medicineInfo.warningDisclaimer || 'Never consume or change medicine doses without the advice of a registered MBMC medical practitioner.'}
                </p>
              </div>
            </div>
          ) : (
            /* Empty State Guidance */
            <div className="bg-white rounded-3xl p-8 border border-slate-200 text-center space-y-4 flex flex-col items-center justify-center min-h-[300px]">
              <div className="w-14 h-14 rounded-full bg-slate-100 text-slate-400 flex items-center justify-center">
                <Pill className="w-7 h-7" />
              </div>
              <div className="max-w-sm space-y-1">
                <h3 className="text-base font-bold text-slate-800">No Medicine Scanned Yet</h3>
                <p className="text-xs text-slate-500 leading-relaxed">
                  Upload a photo of your tablet strip or choose one of the sample medicines above to see its 5th-grade plain-language breakdown.
                </p>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
