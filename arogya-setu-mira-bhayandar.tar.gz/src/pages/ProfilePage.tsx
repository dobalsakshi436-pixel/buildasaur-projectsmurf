import React, { useState } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import {
  User,
  Phone,
  MapPin,
  Globe,
  Heart,
  ShieldCheck,
  CreditCard,
  Save,
  CheckCircle2,
  AlertCircle,
  Activity,
  Plus,
  Trash2,
  FileText,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLanguage } from '../context/LanguageContext';

export const ProfilePage: React.FC = () => {
  const { user, updateUser } = useAuth();
  const { t } = useLanguage();

  const [name, setName] = useState(user?.name || '');
  const [locality, setLocality] = useState(user?.locality || 'Bhayandar West');
  const [bloodGroup, setBloodGroup] = useState(user?.bloodGroup || 'B+');
  const [age, setAge] = useState<string>(user?.age ? String(user.age) : '62');
  const [gender, setGender] = useState(user?.gender || 'female');
  const [emergencyContact, setEmergencyContact] = useState(user?.emergencyContact || '9820011223');
  const [savedSuccess, setSavedSuccess] = useState(false);

  const bloodGroups = ['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'];
  const localities = [
    'Bhayandar West',
    'Bhayandar East',
    'Mira Road East',
    'Naya Nagar',
    'Kashimira',
    'Uttan Coastal',
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateUser({
      name,
      locality,
      bloodGroup,
      age: parseInt(age) || 0,
      gender,
      emergencyContact,
    });
    setSavedSuccess(true);
    setTimeout(() => setSavedSuccess(false), 3500);
  };

  const abhaNumber = `91-${user?.phone ? user.phone.slice(0, 4) : '9820'}-${user?.phone ? user.phone.slice(4, 8) : '0123'}-${user?.phone ? user.phone.slice(8, 10) : '45'}`;

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-teal-800 via-cyan-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-white/15 rounded-full text-xs font-bold uppercase tracking-wider backdrop-blur-xs">
              <ShieldCheck className="w-4 h-4 text-emerald-300" />
              Mira Bhayandar Resident Health ID
            </div>
            <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
              Resident Profile & Digital Health Pass
            </h1>
            <p className="text-sm text-teal-100/90 leading-relaxed font-normal">
              Keep your emergency contacts, health conditions, and locality updated for customized notifications.
            </p>
          </div>
        </div>
      </div>

      {savedSuccess && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-emerald-900 text-sm font-semibold flex items-center gap-2">
          <CheckCircle2 className="w-5 h-5 text-emerald-600" />
          <span>Profile and emergency preferences updated successfully!</span>
        </div>
      )}

      {/* Digital Health ID Card (ABHA Style) */}
      <div className="bg-linear-to-br from-teal-900 via-slate-900 to-cyan-950 text-white rounded-3xl p-6 sm:p-8 shadow-xl border border-teal-500/30 relative overflow-hidden">
        <div className="absolute top-0 right-0 w-64 h-64 bg-teal-500/10 rounded-full blur-3xl pointer-events-none"></div>

        <div className="relative z-10 space-y-6">
          <div className="flex flex-wrap items-center justify-between gap-4 pb-4 border-b border-white/15">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-white/10 flex items-center justify-center text-emerald-300 border border-white/20">
                <Heart className="w-7 h-7 fill-emerald-300/30" />
              </div>
              <div>
                <h3 className="font-extrabold text-lg tracking-tight">AROGYA MUNICIPAL HEALTH CARD</h3>
                <p className="text-xs text-teal-300 font-semibold">Mira Bhayandar Municipal Corporation</p>
              </div>
            </div>

            <span className="px-3 py-1 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-full text-xs font-black uppercase tracking-wider">
              Active Resident
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
            {/* Citizen Details */}
            <div className="md:col-span-8 space-y-4">
              <div>
                <span className="text-xs text-teal-200 block font-medium">Citizen Name / नागरिक नाव</span>
                <h4 className="text-xl sm:text-2xl font-black text-white">{name || 'Resident Name'}</h4>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-2.5 bg-white/10 rounded-xl border border-white/10">
                  <span className="text-teal-200 block">ABHA / Health ID</span>
                  <strong className="text-white font-mono text-sm">{abhaNumber}</strong>
                </div>
                <div className="p-2.5 bg-white/10 rounded-xl border border-white/10">
                  <span className="text-teal-200 block">Blood Group</span>
                  <strong className="text-emerald-300 text-sm font-black">{bloodGroup}</strong>
                </div>
                <div className="p-2.5 bg-white/10 rounded-xl border border-white/10">
                  <span className="text-teal-200 block">Age & Gender</span>
                  <strong className="text-white text-sm">{age} yrs, {gender}</strong>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-4 text-xs text-teal-100">
                <span className="flex items-center gap-1">
                  <MapPin className="w-3.5 h-3.5 text-teal-400" />
                  Locality: <strong>{locality}</strong>
                </span>
                <span className="flex items-center gap-1">
                  <Phone className="w-3.5 h-3.5 text-teal-400" />
                  Emergency Contact: <strong>{emergencyContact}</strong>
                </span>
              </div>
            </div>

            {/* QR Code */}
            <div className="md:col-span-4 flex flex-col items-center justify-center p-4 bg-white rounded-2xl border border-white/20 shadow-lg text-slate-900">
              <QRCodeSVG
                value={`MBMC-CITIZEN-ID:${user?.phone || '0000000000'}|${name}|${bloodGroup}|${locality}`}
                size={110}
                level="M"
              />
              <span className="text-[10px] font-bold text-slate-600 mt-2 text-center">
                Scan for Quick OPD Registration
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Edit Profile Form */}
      <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        <h3 className="text-lg font-bold text-slate-900 pb-3 border-b border-slate-100">
          Update Personal & Emergency Information
        </h3>

        <form onSubmit={handleSave} className="space-y-5">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Full Name
              </label>
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600 focus:bg-white"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Registered Mobile Number (Read-only)
              </label>
              <input
                type="text"
                disabled
                value={user?.phone || '+91-9820012345'}
                className="w-full px-4 py-2.5 bg-slate-100 border border-slate-200 rounded-xl text-sm font-mono text-slate-500 cursor-not-allowed"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Mira Bhayandar Locality / परिसर
              </label>
              <select
                value={locality}
                onChange={(e) => setLocality(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-600"
              >
                {localities.map((loc) => (
                  <option key={loc} value={loc}>
                    {loc}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Blood Group / रक्त गट
              </label>
              <select
                value={bloodGroup}
                onChange={(e) => setBloodGroup(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-600"
              >
                {bloodGroups.map((bg) => (
                  <option key={bg} value={bg}>
                    {bg}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Age (Years)
              </label>
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Gender
              </label>
              <select
                value={gender}
                onChange={(e) => setGender(e.target.value)}
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium text-slate-800 focus:outline-none focus:ring-2 focus:ring-teal-600"
              >
                <option value="female">Female (महिला)</option>
                <option value="male">Male (पुरुष)</option>
                <option value="other">Other</option>
              </select>
            </div>

            <div className="sm:col-span-2">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-700 mb-1.5">
                Emergency Contact Number (Family Member / Caregiver)
              </label>
              <input
                type="tel"
                value={emergencyContact}
                onChange={(e) => setEmergencyContact(e.target.value)}
                placeholder="e.g. 9820099887 (Son / Daughter / Spouse)"
                className="w-full px-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100 flex justify-end">
            <button
              type="submit"
              className="px-6 py-3 bg-teal-700 hover:bg-teal-800 text-white font-extrabold text-sm rounded-xl shadow-md transition-colors flex items-center gap-2"
            >
              <Save className="w-4 h-4" />
              <span>Save Profile Information</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
