import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import {
  Calendar,
  Clock,
  User,
  Phone,
  MapPin,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Building2,
  Sparkles,
  ArrowRight,
  Printer,
  QrCode,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useAuth } from '../context/AuthContext';
import { VaccinationCamp, Hospital, Booking } from '../types';
import { TokenSlipModal } from '../components/TokenSlipModal';

export const BookSlotPage: React.FC = () => {
  const { t } = useLanguage();
  const { user } = useAuth();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();

  const initialType = searchParams.get('type') === 'hospital' ? 'hospital' : 'camp';
  const initialTargetId = searchParams.get('targetId') || '';

  const [bookingType, setBookingType] = useState<'camp' | 'hospital'>(initialType);
  const [camps, setCamps] = useState<VaccinationCamp[]>([]);
  const [hospitals, setHospitals] = useState<Hospital[]>([]);
  const [selectedTargetId, setSelectedTargetId] = useState<string>(initialTargetId);

  // Form inputs
  const [slotDate, setSlotDate] = useState<string>('');
  const [slotTime, setSlotTime] = useState<string>('10:00 AM - 11:00 AM');
  const [userName, setUserName] = useState<string>(user?.name || '');
  const [userPhone, setUserPhone] = useState<string>(user?.emailOrPhone || '');
  const [userAge, setUserAge] = useState<string>(user?.age ? String(user.age) : '45');
  const [userGender, setUserGender] = useState<string>(user?.gender || 'Female');
  const [userLocality, setUserLocality] = useState<string>(user?.locality || 'Mira Road East');
  const [specialtyOrVaccine, setSpecialtyOrVaccine] = useState<string>('');

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmedBooking, setConfirmedBooking] = useState<Booking | null>(null);
  const [showTokenModal, setShowTokenModal] = useState(false);

  // Load camps & hospitals
  useEffect(() => {
    const loadTargets = async () => {
      try {
        const [cRes, hRes] = await Promise.all([
          fetch('/api/camps'),
          fetch('/api/hospitals'),
        ]);
        if (cRes.ok) {
          const cData = await cRes.json();
          setCamps(cData.camps || []);
          if (!selectedTargetId && bookingType === 'camp' && cData.camps?.length > 0) {
            setSelectedTargetId(cData.camps[0].id);
          }
        }
        if (hRes.ok) {
          const hData = await hRes.json();
          setHospitals(hData.hospitals || []);
          if (!selectedTargetId && bookingType === 'hospital' && hData.hospitals?.length > 0) {
            setSelectedTargetId(hData.hospitals[0].id);
          }
        }
      } catch (err) {
        console.error('Failed to load centers:', err);
      }
    };
    loadTargets();
  }, []);

  // Update target when bookingType changes
  useEffect(() => {
    if (bookingType === 'camp') {
      if (camps.length > 0) {
        const match = camps.find((c) => c.id === selectedTargetId);
        if (!match) setSelectedTargetId(camps[0].id);
      }
    } else {
      if (hospitals.length > 0) {
        const match = hospitals.find((h) => h.id === selectedTargetId);
        if (!match) setSelectedTargetId(hospitals[0].id);
      }
    }
  }, [bookingType, camps, hospitals]);

  // Set default date when target is chosen
  useEffect(() => {
    if (bookingType === 'camp') {
      const activeCamp = camps.find((c) => c.id === selectedTargetId);
      if (activeCamp) {
        setSlotDate(activeCamp.date);
        setSpecialtyOrVaccine(activeCamp.vaccinesOffered[0] || 'General Vaccine');
      }
    } else {
      const activeHosp = hospitals.find((h) => h.id === selectedTargetId);
      if (activeHosp) {
        const today = new Date().toISOString().split('T')[0];
        setSlotDate(today);
        setSpecialtyOrVaccine(activeHosp.specialties[0] || 'General Medicine (OPD)');
      }
    }
  }, [selectedTargetId, bookingType, camps, hospitals]);

  // Auto-sync logged in user info
  useEffect(() => {
    if (user) {
      if (!userName) setUserName(user.name);
      if (!userPhone) setUserPhone(user.emailOrPhone);
      if (user.age && (!userAge || userAge === '45')) setUserAge(String(user.age));
      if (user.gender) setUserGender(user.gender);
      if (user.locality) setUserLocality(user.locality);
    }
  }, [user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!userName.trim() || !userPhone.trim()) {
      setError('Please provide patient name and contact phone number.');
      return;
    }

    if (!selectedTargetId) {
      setError('Please select a vaccination camp or hospital.');
      return;
    }

    setLoading(true);

    try {
      const token = localStorage.getItem('arogya_jwt_token');
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }

      const res = await fetch('/api/bookings', {
        method: 'POST',
        headers,
        body: JSON.stringify({
          type: bookingType,
          targetId: selectedTargetId,
          slotDate,
          slotTime,
          userName: userName.trim(),
          userPhone: userPhone.trim(),
          userAge: Number(userAge) || 40,
          userGender,
          userLocality,
          specialtyOrVaccine,
        }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Booking failed');
      }

      setConfirmedBooking(data.booking);
      setShowTokenModal(true);
    } catch (err: any) {
      setError(err.message || 'Failed to generate booking token.');
    } finally {
      setLoading(false);
    }
  };

  const selectedCampObj = camps.find((c) => c.id === selectedTargetId);
  const selectedHospObj = hospitals.find((h) => h.id === selectedTargetId);

  const timeSlotOptions = [
    '09:00 AM - 10:00 AM',
    '10:00 AM - 11:00 AM',
    '11:00 AM - 12:00 PM',
    '12:00 PM - 01:00 PM',
    '02:00 PM - 03:00 PM',
    '03:00 PM - 04:00 PM',
    '04:00 PM - 05:00 PM',
  ];

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-8 space-y-8">
      {/* Header Banner */}
      <div className="bg-linear-to-r from-teal-800 to-emerald-900 text-white rounded-3xl p-6 sm:p-8 shadow-xl space-y-3">
        <div className="inline-flex items-center gap-2 px-3 py-1 bg-emerald-700/80 rounded-full text-emerald-100 text-xs font-bold uppercase tracking-wider">
          <ShieldCheck className="w-4 h-4 text-emerald-300" />
          Free Citizen Digital Health Pass
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
          Book Free Camp Token / Municipal Hospital OPD Slot
        </h1>
        <p className="text-sm text-teal-100/90 leading-relaxed font-normal">
          Instant digital token with QR verification. Avoid standing in long morning lines at Temba or Indira Gandhi Hospital.
        </p>
      </div>

      {/* Booking Type Switcher Tabs */}
      <div className="grid grid-cols-2 gap-3 bg-slate-100 p-1.5 rounded-2xl border border-slate-200">
        <button
          type="button"
          onClick={() => {
            setBookingType('camp');
            if (camps.length > 0) setSelectedTargetId(camps[0].id);
          }}
          className={`py-3 px-4 rounded-xl font-bold text-sm sm:text-base flex items-center justify-center gap-2 transition-all ${
            bookingType === 'camp'
              ? 'bg-teal-800 text-white shadow-md'
              : 'text-slate-700 hover:text-slate-950 hover:bg-white/60'
          }`}
        >
          <Calendar className="w-5 h-5 text-emerald-300" />
          <span>1. Vaccination & Health Camp</span>
        </button>

        <button
          type="button"
          onClick={() => {
            setBookingType('hospital');
            if (hospitals.length > 0) setSelectedTargetId(hospitals[0].id);
          }}
          className={`py-3 px-4 rounded-xl font-bold text-sm sm:text-base flex items-center justify-center gap-2 transition-all ${
            bookingType === 'hospital'
              ? 'bg-teal-800 text-white shadow-md'
              : 'text-slate-700 hover:text-slate-950 hover:bg-white/60'
          }`}
        >
          <Building2 className="w-5 h-5 text-cyan-300" />
          <span>2. Hospital OPD Appointment</span>
        </button>
      </div>

      {/* Error Message */}
      {error && (
        <div className="p-4 bg-red-50 border border-red-200 rounded-2xl flex items-center gap-3 text-sm text-red-800">
          <AlertCircle className="w-5 h-5 text-red-600 shrink-0" />
          <span>{error}</span>
        </div>
      )}

      {/* Main Form */}
      <form onSubmit={handleSubmit} className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-200 shadow-sm space-y-6">
        {/* Step 1: Select Facility / Camp */}
        <div className="space-y-3 pb-6 border-b border-slate-100">
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-teal-100 text-teal-800 text-xs flex items-center justify-center font-black">1</span>
            {bookingType === 'camp' ? 'Select Vaccination Camp:' : 'Select Municipal Hospital / OPD Center:'}
          </h2>

          <select
            value={selectedTargetId}
            onChange={(e) => setSelectedTargetId(e.target.value)}
            className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl text-sm font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-teal-600"
          >
            {bookingType === 'camp'
              ? camps.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name} ({c.locality} - {c.date}) [{c.availableSlots} slots left]
                  </option>
                ))
              : hospitals.map((h) => (
                  <option key={h.id} value={h.id}>
                    {h.name} ({h.locality} - {h.type})
                  </option>
                ))}
          </select>

          {/* Selected facility info preview box */}
          {bookingType === 'camp' && selectedCampObj && (
            <div className="p-3.5 bg-teal-50/70 rounded-xl border border-teal-100 text-xs space-y-1">
              <p className="font-bold text-teal-950">{selectedCampObj.name}</p>
              <p className="text-slate-600">📍 {selectedCampObj.address} (Landmark: {selectedCampObj.landmark})</p>
              <p className="text-teal-800 font-semibold">💉 Vaccines: {selectedCampObj.vaccinesOffered.join(', ')}</p>
              <p className="text-emerald-700 font-bold">⚡ Remaining Slots: {selectedCampObj.availableSlots} of {selectedCampObj.totalSlots}</p>
            </div>
          )}

          {bookingType === 'hospital' && selectedHospObj && (
            <div className="p-3.5 bg-cyan-50/70 rounded-xl border border-cyan-100 text-xs space-y-1">
              <p className="font-bold text-cyan-950">{selectedHospObj.name}</p>
              <p className="text-slate-600">📍 {selectedHospObj.address}</p>
              <p className="text-cyan-900">🩺 OPD Hours: {selectedHospObj.opdTimings} • 📞 {selectedHospObj.contactNumber}</p>
            </div>
          )}
        </div>

        {/* Step 2: Date, Time & Service */}
        <div className="space-y-4 pb-6 border-b border-slate-100">
          <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
            <span className="w-6 h-6 rounded-full bg-teal-100 text-teal-800 text-xs flex items-center justify-center font-black">2</span>
            Select Slot Date & Preferred Time:
          </h2>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Date (YYYY-MM-DD)
              </label>
              <input
                type="text"
                value={slotDate}
                onChange={(e) => setSlotDate(e.target.value)}
                placeholder="2025-06-15"
                required
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Preferred Time Slot
              </label>
              <select
                value={slotTime}
                onChange={(e) => setSlotTime(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
              >
                {timeSlotOptions.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                {bookingType === 'camp' ? 'Vaccine Name' : 'Medical Department'}
              </label>
              <input
                type="text"
                value={specialtyOrVaccine}
                onChange={(e) => setSpecialtyOrVaccine(e.target.value)}
                placeholder="e.g. Pneumococcal / Fever OPD"
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
            </div>
          </div>
        </div>

        {/* Step 3: Patient / Citizen Details */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-base font-bold text-slate-900 flex items-center gap-2">
              <span className="w-6 h-6 rounded-full bg-teal-100 text-teal-800 text-xs flex items-center justify-center font-black">3</span>
              Patient / Citizen Information:
            </h2>
            {user && (
              <span className="text-xs text-emerald-700 font-semibold flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5" />
                Auto-filled from profile
              </span>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Patient Full Name *
              </label>
              <input
                type="text"
                value={userName}
                onChange={(e) => setUserName(e.target.value)}
                placeholder="e.g. Ramesh Chandra Sharma"
                required
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Mobile Phone Number *
              </label>
              <input
                type="tel"
                value={userPhone}
                onChange={(e) => setUserPhone(e.target.value)}
                placeholder="e.g. 9820123456"
                required
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Age (Years)
                </label>
                <input
                  type="number"
                  min="0"
                  max="115"
                  value={userAge}
                  onChange={(e) => setUserAge(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Gender
                </label>
                <select
                  value={userGender}
                  onChange={(e) => setUserGender(e.target.value)}
                  className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
                >
                  <option value="Female">Female (महिला)</option>
                  <option value="Male">Male (पुरुष)</option>
                  <option value="Senior Citizen">Senior Citizen (ज्येष्ठ)</option>
                  <option value="Other">Other</option>
                </select>
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1">
                Locality / Ward
              </label>
              <select
                value={userLocality}
                onChange={(e) => setUserLocality(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm font-medium focus:outline-none focus:ring-2 focus:ring-teal-600"
              >
                <option value="Bhayandar West">Bhayandar West</option>
                <option value="Bhayandar East">Bhayandar East</option>
                <option value="Mira Road East">Mira Road East</option>
                <option value="Naya Nagar">Naya Nagar</option>
                <option value="Kashimira">Kashimira</option>
                <option value="Uttan Coastal">Uttan Coastal</option>
                <option value="Navghar">Navghar</option>
              </select>
            </div>
          </div>
        </div>

        {/* Submit Button */}
        <div className="pt-4 border-t border-slate-100">
          <button
            type="submit"
            disabled={loading}
            className="w-full py-4 bg-linear-to-r from-teal-700 to-emerald-700 hover:from-teal-800 hover:to-emerald-800 text-white font-extrabold text-base rounded-2xl shadow-md hover:shadow-lg transition-all flex items-center justify-center gap-2 active:scale-99 disabled:opacity-50"
          >
            {loading ? (
              <span>Generating Secure Digital Health Pass...</span>
            ) : (
              <>
                <CheckCircle2 className="w-5 h-5 text-emerald-300" />
                <span>Confirm & Generate Digital Token Pass</span>
              </>
            )}
          </button>
        </div>
      </form>

      {/* Confirmation Modal */}
      {confirmedBooking && (
        <TokenSlipModal
          booking={confirmedBooking}
          onClose={() => setShowTokenModal(false)}
        />
      )}
    </div>
  );
};
