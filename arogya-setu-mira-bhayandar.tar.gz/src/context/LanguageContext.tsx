import React, { createContext, useContext, useState, useEffect } from 'react';
import { Language } from '../types';

export const ALL_LANGUAGES: Language[] = [
  { code: 'en', name: 'English', native: 'English', isPinned: true },
  { code: 'hi', name: 'Hindi', native: 'हिन्दी', isPinned: true },
  { code: 'mr', name: 'Marathi', native: 'मराठी', isPinned: true },
  { code: 'gu', name: 'Gujarati', native: 'ગુજરાતી', isPinned: true },
  { code: 'ur', name: 'Urdu', native: 'اردو' },
  { code: 'bn', name: 'Bengali', native: 'বাংলা' },
  { code: 'ta', name: 'Tamil', native: 'தமிழ்' },
  { code: 'te', name: 'Telugu', native: 'తెలుగు' },
  { code: 'kn', name: 'Kannada', native: 'ಕನ್ನಡ' },
  { code: 'ml', name: 'Malayalam', native: 'മലയാളം' },
  { code: 'pa', name: 'Punjabi', native: 'ਪੰਜਾਬੀ' },
  { code: 'or', name: 'Odia', native: 'ଓଡ଼ିଆ' },
  { code: 'as', name: 'Assamese', native: 'অসমীয়া' },
  { code: 'sa', name: 'Sanskrit', native: 'संस्कृतम्' },
  { code: 'sd', name: 'Sindhi', native: 'سنڌي' },
  { code: 'ne', name: 'Nepali', native: 'नेपाली' },
  { code: 'kok', name: 'Konkani', native: 'कोंकणी' },
  { code: 'ar', name: 'Arabic', native: 'العربية' },
  { code: 'es', name: 'Spanish', native: 'Español' },
  { code: 'fr', name: 'French', native: 'Français' },
  { code: 'de', name: 'German', native: 'Deutsch' },
  { code: 'ja', name: 'Japanese', native: '日本語' },
  { code: 'ru', name: 'Russian', native: 'Русский' },
  { code: 'zh', name: 'Chinese', native: '中文' },
  { code: 'pt', name: 'Portuguese', native: 'Português' },
  { code: 'it', name: 'Italian', native: 'Italiano' },
  { code: 'tr', name: 'Turkish', native: 'Türkçe' },
  { code: 'fa', name: 'Persian', native: 'فارسی' },
  { code: 'id', name: 'Indonesian', native: 'Bahasa Indonesia' },
  { code: 'th', name: 'Thai', native: 'ไทย' },
  { code: 'vi', name: 'Vietnamese', native: 'Tiếng Việt' },
  { code: 'sw', name: 'Swahili', native: 'Kiswahili' },
  { code: 'pl', name: 'Polish', native: 'Polski' },
  { code: 'uk', name: 'Ukrainian', native: 'Українська' },
  { code: 'nl', name: 'Dutch', native: 'Nederlands' },
  { code: 'el', name: 'Greek', native: 'Ελληνικά' },
  { code: 'he', name: 'Hebrew', native: 'עברית' },
  { code: 'sv', name: 'Swedish', native: 'Svenska' },
  { code: 'ro', name: 'Romanian', native: 'Română' },
  { code: 'hu', name: 'Hungarian', native: 'Magyar' },
  { code: 'cs', name: 'Czech', native: 'Čeština' },
  { code: 'da', name: 'Danish', native: 'Dansk' },
  { code: 'fi', name: 'Finnish', native: 'Suomi' },
  { code: 'no', name: 'Norwegian', native: 'Norsk' },
  { code: 'sk', name: 'Slovak', native: 'Slovenčina' },
  { code: 'hr', name: 'Croatian', native: 'Hrvatski' },
  { code: 'bg', name: 'Bulgarian', native: 'Български' },
  { code: 'lt', name: 'Lithuanian', native: 'Lietuvių' },
  { code: 'sl', name: 'Slovenian', native: 'Slovenščina' },
  { code: 'lv', name: 'Latvian', native: 'Latviešu' },
  { code: 'et', name: 'Estonian', native: 'Eesti' },
  { code: 'ms', name: 'Malay', native: 'Bahasa Melayu' },
  { code: 'tl', name: 'Filipino', native: 'Filipino' },
  { code: 'af', name: 'Afrikaans', native: 'Afrikaans' },
];

const UI_DICTIONARY: Record<string, Record<string, string>> = {
  appName: {
    en: 'Arogya Setu Mira Bhayandar',
    hi: 'आरोग्य सेतु मीरा भाईंदर',
    mr: 'आरोग्य सेतू मीरा भाईंदर',
    gu: 'આરોગ્ય સેતુ મીરા ભાયંદર',
    ur: 'آروگیہ سیتو میرا بھائیندر',
  },
  appTagline: {
    en: 'Community Health Portal for Mira Bhayandar Residents',
    hi: 'मीरा भाईंदर के नागरिकों के लिए सरल व सुलभ स्वास्थ्य सेवा',
    mr: 'मीरा भाईंदरकरांसाठी मोफत आणि सोपे सार्वजनिक आरोग्य पोर्टल',
    gu: 'મીરા ભાયંદરના નાગરિકો માટે સરળ અને મફત આરોગ્ય સેવા',
  },
  navHome: { en: 'Home', hi: 'मुख्य पृष्ठ', mr: 'मुख्य पान', gu: 'હોમ' },
  navAdvisories: { en: 'Health Alerts', hi: 'स्वास्थ्य अलर्ट', mr: 'आरोग्य सूचना', gu: 'આરોગ્ય ચેતવણી' },
  navCamps: { en: 'Vaccination Camps', hi: 'टीकाकरण शिविर', mr: 'लसीकरण शिबिरे', gu: 'રસીકરણ કેમ્પ' },
  navHospitals: { en: 'Nearby Hospitals', hi: 'नजदीकी अस्पताल', mr: 'जवळची रुग्णालये', gu: 'નજીકની હોસ્પિટલ' },
  navTranslate: { en: 'Translate Advice', hi: 'भाषा अनुवाद', mr: 'भाषांतर', gu: 'અનુવાદ' },
  navScanner: { en: 'Scan Medicine', hi: 'दवा स्कैनर', mr: 'औषध स्कॅन', gu: 'દવા સ્કેનર' },
  navPharmacies: { en: 'Medicine Availability', hi: 'दवा उपलब्धता', mr: 'औषध साठा शोधा', gu: 'દવા સ્ટોક' },
  navChatbot: { en: 'Ask Health Bot', hi: 'स्वास्थ्य मित्र चैट', mr: 'आरोग्य मित्र बॉट', gu: 'આરોગ્ય મિત્ર' },
  navBookSlot: { en: 'Book a Slot', hi: 'स्लॉट बुक करें', mr: 'स्लॉट बुक करा', gu: 'સ્લોટ બુક કરો' },
  navMyBookings: { en: 'My Bookings', hi: 'मेरी बुकिंग्स', mr: 'माझी बुकिंग', gu: 'મારી બુકિંગ્સ' },
  navAbout: { en: 'Helplines & Info', hi: 'हेल्पलाइन व संपर्क', mr: 'मदत व संपर्क', gu: 'સંપર્ક અને માહિતી' },
  navLogin: { en: 'Login / Sign Up', hi: 'लॉग इन / खाता बनाएं', mr: 'लॉगिन / नोंदणी', gu: 'લૉગિન / સાઇન અપ' },
  navAdmin: { en: 'Admin Panel', hi: 'व्यवस्थापक', mr: 'प्रशासन', gu: 'એડમિન' },
  emergencyAmbulance: { en: 'Emergency Ambulance: 108', hi: 'आपातकालीन एम्बुलेंस: 108', mr: 'रुग्णवाहिका: १०८', gu: 'ઇમરજન્સી એમ્બ્યુલન્સ: 108' },
  simpleLanguageToggle: { en: 'Simple Plain Language', hi: 'सरल भाषा में समझें', mr: 'सोप्या भाषेत समजून घ्या', gu: 'સરળ ભાષામાં સમજો' },
  medicalLanguageToggle: { en: 'Standard Medical Text', hi: 'विस्तृत चिकित्सा विवरण', mr: 'वैद्यकीय तपशील', gu: 'તબીબી વિગત' },
  bookNowBtn: { en: 'Book Free Slot', hi: 'मुफ्त स्लॉट बुक करें', mr: 'मोफत स्लॉट बुक करा', gu: 'મફત સ્લોટ બુક કરો' },
  callNowBtn: { en: 'Call Now', hi: 'अभी कॉल करें', mr: 'कॉल करा', gu: 'હમણાં કૉલ કરો' },
  directionsBtn: { en: 'Get Directions', hi: 'रास्ता देखें', mr: 'दिशा / नकाशा', gu: 'દિશા જુઓ' },
  readAloudBtn: { en: 'Listen / Read Aloud', hi: 'बोलकर सुनें', mr: 'ऐका', gu: 'સાંભળો' },
  stopReadBtn: { en: 'Stop Audio', hi: 'आवाज रोकें', mr: 'थांबवा', gu: 'રોકો' },
  searchPlaceholder: { en: 'Search by locality, symptom, or hospital name...', hi: 'इलाका, लक्षण या अस्पताल खोजें...', mr: 'परिसर, लक्षणे किंवा रुग्णालय शोधा...', gu: 'વિસ્તાર અથવા લક્ષણો શોધો...' },
};

interface LanguageContextType {
  currentLang: string;
  currentLanguageObj: Language;
  setLanguage: (code: string) => void;
  t: (key: string, defaultText?: string) => string;
  isModalOpen: boolean;
  setIsModalOpen: (open: boolean) => void;
  allLanguages: Language[];
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentLang, setCurrentLangState] = useState<string>(() => {
    return localStorage.getItem('arogya_lang') || 'hi';
  });
  const [isModalOpen, setIsModalOpen] = useState(false);

  const setLanguage = (code: string) => {
    setCurrentLangState(code);
    localStorage.setItem('arogya_lang', code);
  };

  const currentLanguageObj = ALL_LANGUAGES.find((l) => l.code === currentLang) || {
    code: currentLang,
    name: 'Selected Language',
    native: currentLang.toUpperCase(),
  };

  const t = (key: string, defaultText?: string): string => {
    if (UI_DICTIONARY[key]) {
      const entry = UI_DICTIONARY[key];
      if (entry[currentLang]) return entry[currentLang];
      if (entry.en) return entry.en;
    }
    return defaultText || key;
  };

  return (
    <LanguageContext.Provider
      value={{
        currentLang,
        currentLanguageObj,
        setLanguage,
        t,
        isModalOpen,
        setIsModalOpen,
        allLanguages: ALL_LANGUAGES,
      }}
    >
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) throw new Error('useLanguage must be used within LanguageProvider');
  return context;
};
