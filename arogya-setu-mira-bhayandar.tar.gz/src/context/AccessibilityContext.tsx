import React, { createContext, useContext, useState, useEffect } from 'react';

type FontScale = 'normal' | 'large' | 'xlarge';

interface AccessibilityContextType {
  fontScale: FontScale;
  setFontScale: (scale: FontScale) => void;
  increaseFont: () => void;
  decreaseFont: () => void;
  resetFont: () => void;
  highContrast: boolean;
  toggleHighContrast: () => void;
  isSpeaking: boolean;
  speakText: (text: string, langCode?: string) => void;
  stopSpeaking: () => void;
}

const AccessibilityContext = createContext<AccessibilityContextType | undefined>(undefined);

export const AccessibilityProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [fontScale, setFontScale] = useState<FontScale>(() => {
    return (localStorage.getItem('arogya_font_scale') as FontScale) || 'normal';
  });

  const [highContrast, setHighContrast] = useState<boolean>(() => {
    return localStorage.getItem('arogya_high_contrast') === 'true';
  });

  const [isSpeaking, setIsSpeaking] = useState<boolean>(false);

  useEffect(() => {
    localStorage.setItem('arogya_font_scale', fontScale);
    const root = document.documentElement;
    root.classList.remove('font-scale-normal', 'font-scale-large', 'font-scale-xlarge');
    root.classList.add(`font-scale-${fontScale}`);

    if (fontScale === 'large') {
      root.style.fontSize = '18px';
    } else if (fontScale === 'xlarge') {
      root.style.fontSize = '20px';
    } else {
      root.style.fontSize = '16px';
    }
  }, [fontScale]);

  useEffect(() => {
    localStorage.setItem('arogya_high_contrast', String(highContrast));
    if (highContrast) {
      document.documentElement.classList.add('high-contrast');
    } else {
      document.documentElement.classList.remove('high-contrast');
    }
  }, [highContrast]);

  const toggleHighContrast = () => {
    setHighContrast((prev) => !prev);
  };

  const increaseFont = () => {
    if (fontScale === 'normal') setFontScale('large');
    else if (fontScale === 'large') setFontScale('xlarge');
  };

  const decreaseFont = () => {
    if (fontScale === 'xlarge') setFontScale('large');
    else if (fontScale === 'large') setFontScale('normal');
  };

  const resetFont = () => {
    setFontScale('normal');
  };

  const stopSpeaking = () => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
    }
  };

  const speakText = (text: string, langCode: string = 'hi') => {
    if (!('speechSynthesis' in window)) {
      alert('Speech synthesis is not supported on your browser.');
      return;
    }

    stopSpeaking();

    const utterance = new SpeechSynthesisUtterance(text);
    // map to speech lang
    const codeMap: Record<string, string> = {
      hi: 'hi-IN',
      mr: 'mr-IN',
      gu: 'gu-IN',
      en: 'en-IN',
      ur: 'ur-PK',
      bn: 'bn-IN',
      ta: 'ta-IN',
      te: 'te-IN',
    };
    utterance.lang = codeMap[langCode] || 'hi-IN';
    utterance.rate = 0.88; // slightly slower for elderly clarity
    utterance.pitch = 1.0;

    utterance.onstart = () => setIsSpeaking(true);
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
  };

  return (
    <AccessibilityContext.Provider
      value={{
        fontScale,
        setFontScale,
        increaseFont,
        decreaseFont,
        resetFont,
        highContrast,
        toggleHighContrast,
        isSpeaking,
        speakText,
        stopSpeaking,
      }}
    >
      {children}
    </AccessibilityContext.Provider>
  );
};

export const useAccessibility = () => {
  const context = useContext(AccessibilityContext);
  if (!context) throw new Error('useAccessibility must be used within AccessibilityProvider');
  return context;
};
