import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { LanguageProvider } from './context/LanguageContext';
import { AccessibilityProvider } from './context/AccessibilityContext';
import { AuthProvider } from './context/AuthContext';

import { Navbar } from './components/layout/Navbar';
import { Footer } from './components/layout/Footer';
import { MobileBottomNav } from './components/layout/MobileBottomNav';
import { Breadcrumbs } from './components/layout/Breadcrumbs';
import { FloatingChatbot } from './components/FloatingChatbot';

import { HomePage } from './pages/HomePage';
import { AdvisoriesPage } from './pages/AdvisoriesPage';
import { CampsPage } from './pages/CampsPage';
import { HospitalsPage } from './pages/HospitalsPage';
import { BookSlotPage } from './pages/BookSlotPage';
import { MedicineScannerPage } from './pages/MedicineScannerPage';
import { MedicineAvailabilityPage } from './pages/MedicineAvailabilityPage';
import { TranslatePage } from './pages/TranslatePage';
import { ChatbotPage } from './pages/ChatbotPage';
import { MyBookingsPage } from './pages/MyBookingsPage';
import { ProfilePage } from './pages/ProfilePage';
import { AboutPage } from './pages/AboutPage';
import { AboutHelplinesPage } from './pages/AboutHelplinesPage';
import { AdminPage } from './pages/AdminPage';
import { LoginPage } from './pages/LoginPage';
import { SignupPage } from './pages/SignupPage';
import { LanguageModal } from './components/LanguageModal';

export default function App() {
  return (
    <LanguageProvider>
      <AccessibilityProvider>
        <AuthProvider>
          <BrowserRouter>
            <div className="min-h-screen flex flex-col bg-slate-50/70 text-slate-900 font-sans selection:bg-teal-200 selection:text-teal-900">
              {/* Header Navigation */}
              <Navbar />

              {/* Main Breadcrumbs & Page Viewport */}
              <main className="flex-1 pb-20 md:pb-12">
                <Breadcrumbs />
                <Routes>
                  <Route path="/" element={<HomePage />} />
                  <Route path="/advisories" element={<AdvisoriesPage />} />
                  <Route path="/camps" element={<CampsPage />} />
                  <Route path="/hospitals" element={<HospitalsPage />} />
                  <Route path="/book-slot" element={<BookSlotPage />} />
                  <Route path="/scan-medicine" element={<MedicineScannerPage />} />
                  <Route path="/medicines" element={<MedicineAvailabilityPage />} />
                  <Route path="/pharmacies" element={<MedicineAvailabilityPage />} />
                  <Route path="/translate" element={<TranslatePage />} />
                  <Route path="/chatbot" element={<ChatbotPage />} />
                  <Route path="/my-bookings" element={<MyBookingsPage />} />
                  <Route path="/profile" element={<ProfilePage />} />
                  <Route path="/about" element={<AboutHelplinesPage />} />
                  <Route path="/admin" element={<AdminPage />} />
                  <Route path="/login" element={<LoginPage />} />
                  <Route path="/signup" element={<SignupPage />} />
                  <Route path="*" element={<Navigate to="/" replace />} />
                </Routes>
              </main>

              {/* Footer */}
              <Footer />

              {/* Mobile Fixed Bottom Bar */}
              <MobileBottomNav />

              {/* 24/7 Floating AI Health Guide */}
              <FloatingChatbot />

              {/* 100+ Languages Selection Modal */}
              <LanguageModal />
            </div>
          </BrowserRouter>
        </AuthProvider>
      </AccessibilityProvider>
    </LanguageProvider>
  );
}
