import React from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { X, Printer, CheckCircle, Calendar, Clock, MapPin, Phone, User as UserIcon, ShieldCheck, Download } from 'lucide-react';
import { Booking } from '../types';

interface TokenSlipModalProps {
  booking: Booking | null;
  onClose: () => void;
}

export const TokenSlipModal: React.FC<TokenSlipModalProps> = ({ booking, onClose }) => {
  if (!booking) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden border border-slate-200 flex flex-col max-h-[90vh]">
        {/* Header Bar */}
        <div className="p-4 bg-linear-to-r from-teal-700 to-emerald-800 text-white flex items-center justify-between no-print">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-emerald-300" />
            <div>
              <h2 className="font-bold text-lg leading-tight">Official Booking Token Slip</h2>
              <p className="text-xs text-emerald-100">MBMC Public Health Department</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Card Area */}
        <div id="printable-token" className="p-6 overflow-y-auto flex-1 bg-slate-50/50">
          {/* Header */}
          <div className="text-center pb-4 border-b border-dashed border-slate-300">
            <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-emerald-100 text-emerald-700 mb-2">
              <CheckCircle className="w-7 h-7" />
            </div>
            <h3 className="text-xl font-extrabold text-slate-900">AROGYA SETU MIRA BHAYANDAR</h3>
            <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
              {booking.type === 'camp' ? 'Vaccination Camp Entry Pass' : 'Hospital OPD Appointment Pass'}
            </p>
            <div className="mt-3 inline-block px-4 py-1.5 bg-teal-800 text-white font-mono font-black text-lg tracking-widest rounded-lg shadow-xs">
              {booking.tokenNumber}
            </div>
          </div>

          {/* QR Code & Essential Details */}
          <div className="py-5 flex flex-col items-center justify-center gap-4 bg-white rounded-xl p-4 my-4 border border-slate-200 shadow-2xs">
            <div className="p-2 bg-white rounded-lg border border-slate-200 shadow-2xs">
              <QRCodeSVG
                value={`MBMC-HEALTH-PASS:${booking.tokenNumber}|${booking.userName}|${booking.slotDate}|${booking.targetName}`}
                size={140}
                level="M"
              />
            </div>
            <p className="text-xs text-center text-slate-500 max-w-xs">
              Show this QR Code at the registration desk or present token number: <span className="font-bold text-slate-800">{booking.tokenNumber}</span>
            </p>
          </div>

          {/* Details Table */}
          <div className="space-y-3 bg-white p-4 rounded-xl border border-slate-200 text-sm">
            <div className="flex items-start gap-2.5">
              <MapPin className="w-4 h-4 text-teal-700 mt-0.5 shrink-0" />
              <div>
                <span className="text-xs text-slate-500 font-medium block">Center / Facility</span>
                <span className="font-bold text-slate-800">{booking.targetName}</span>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-100">
              <div className="flex items-start gap-2">
                <Calendar className="w-4 h-4 text-teal-700 mt-0.5 shrink-0" />
                <div>
                  <span className="text-xs text-slate-500 font-medium block">Date</span>
                  <span className="font-semibold text-slate-800">{booking.slotDate}</span>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Clock className="w-4 h-4 text-teal-700 mt-0.5 shrink-0" />
                <div>
                  <span className="text-xs text-slate-500 font-medium block">Time Slot</span>
                  <span className="font-semibold text-slate-800">{booking.slotTime}</span>
                </div>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2 border-t border-slate-100">
              <div className="flex items-start gap-2">
                <UserIcon className="w-4 h-4 text-teal-700 mt-0.5 shrink-0" />
                <div>
                  <span className="text-xs text-slate-500 font-medium block">Patient Name</span>
                  <span className="font-semibold text-slate-800">{booking.userName} ({booking.userAge}y, {booking.userGender})</span>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <Phone className="w-4 h-4 text-teal-700 mt-0.5 shrink-0" />
                <div>
                  <span className="text-xs text-slate-500 font-medium block">Phone / Locality</span>
                  <span className="font-semibold text-slate-800">{booking.userPhone} • {booking.userLocality}</span>
                </div>
              </div>
            </div>

            {booking.specialtyOrVaccine && (
              <div className="pt-2 border-t border-slate-100">
                <span className="text-xs text-slate-500 font-medium block">Service / Vaccine</span>
                <span className="font-semibold text-teal-800">{booking.specialtyOrVaccine}</span>
              </div>
            )}
          </div>

          {/* Instructions */}
          <div className="mt-4 p-3 bg-amber-50/80 rounded-xl border border-amber-200 text-xs text-amber-900">
            <p className="font-bold mb-1">Important Instructions for Patient / Citizen:</p>
            <ul className="list-disc pl-4 space-y-0.5">
              <li>Please arrive 15 minutes before your allotted time slot.</li>
              <li>Bring a photo ID (Aadhaar / Voter ID / Senior Citizen Card) and previous medical prescription if available.</li>
              <li>For senior citizens and pregnant women, dedicated seating and fast-track counters are available.</li>
            </ul>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-100 border-t border-slate-200 flex items-center justify-between no-print">
          <button
            onClick={onClose}
            className="px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-200 rounded-xl transition-colors"
          >
            Close
          </button>
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrint}
              className="flex items-center gap-2 px-5 py-2.5 bg-teal-700 hover:bg-teal-800 text-white font-bold text-sm rounded-xl shadow-sm transition-all"
            >
              <Printer className="w-4 h-4" />
              Print / Save Slip
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
