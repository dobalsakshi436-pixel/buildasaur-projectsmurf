import React, { useState, useRef, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import {
  MessageSquare,
  X,
  Send,
  Bot,
  User,
  Sparkles,
  Volume2,
  Minimize2,
  Maximize2,
  ExternalLink,
  Loader2,
} from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';
import { useAccessibility } from '../context/AccessibilityContext';

interface Message {
  id: string;
  sender: 'user' | 'bot';
  text: string;
  suggestedActions?: { label: string; action: string }[];
  time: string;
}

export const FloatingChatbot: React.FC = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [messages, setMessages] = useState<Message[]>([
    {
      id: 'm_welcome',
      sender: 'bot',
      text: 'Namaste! I am your Arogya Mitra health assistant for Mira Bhayandar. How can I help you today?',
      suggestedActions: [
        { label: 'Dengue & Fever Guide', action: '/advisories' },
        { label: 'Vaccination Camps', action: '/camps' },
        { label: 'Find Nearby Hospitals', action: '/hospitals' },
      ],
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    },
  ]);

  const { currentLang } = useLanguage();
  const { speakText } = useAccessibility();
  const navigate = useNavigate();
  const location = useLocation();
  const chatEndRef = useRef<HTMLDivElement>(null);

  // If already on full chatbot page, hide the floating button
  if (location.pathname === '/chatbot') return null;

  useEffect(() => {
    if (isOpen) {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const handleSend = async (textToSend?: string) => {
    const text = (textToSend || input).trim();
    if (!text || loading) return;

    const userMsg: Message = {
      id: `usr_${Date.now()}`,
      sender: 'user',
      text,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const res = await fetch('/api/chatbot', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          lang: currentLang,
        }),
      });

      const data = await res.json();
      const botMsg: Message = {
        id: `bot_${Date.now()}`,
        sender: 'bot',
        text: data.reply || 'Thank you. Please consult your local MBMC health officer for detailed guidance.',
        suggestedActions: data.suggestedActions || [],
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      };
      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        {
          id: `bot_err_${Date.now()}`,
          sender: 'bot',
          text: 'Unable to reach health bot server right now. For urgent medical help, call 108 or MBMC Health Desk 022-28112233.',
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        },
      ]);
    } finally {
      setLoading(false);
    }
  };

  const handleActionClick = (action: string) => {
    if (action.startsWith('tel:')) {
      window.location.href = action;
    } else {
      setIsOpen(false);
      navigate(action);
    }
  };

  return (
    <div className="fixed bottom-20 md:bottom-6 right-4 z-40 no-print">
      {/* Expanded Floating Box */}
      {isOpen ? (
        <div className="bg-white rounded-2xl shadow-2xl border border-slate-200 w-80 sm:w-96 flex flex-col h-[480px] overflow-hidden animate-in slide-in-from-bottom-5 duration-200">
          {/* Header */}
          <div className="p-3.5 bg-linear-to-r from-teal-700 to-cyan-800 text-white flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
                <Bot className="w-4 h-4 text-teal-100" />
              </div>
              <div>
                <h4 className="font-bold text-sm leading-tight">Arogya Mitra 24x7</h4>
                <p className="text-[10px] text-teal-100 flex items-center gap-1">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400"></span>
                  MBMC Health Assistant
                </p>
              </div>
            </div>
            <div className="flex items-center gap-1">
              <button
                onClick={() => {
                  setIsOpen(false);
                  navigate('/chatbot');
                }}
                className="p-1 text-teal-100 hover:text-white rounded hover:bg-white/10"
                title="Open Full Screen Chat"
              >
                <Maximize2 className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1 text-teal-100 hover:text-white rounded hover:bg-white/10"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Messages Area */}
          <div className="p-3.5 flex-1 overflow-y-auto space-y-3 bg-slate-50 text-xs">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex flex-col ${msg.sender === 'user' ? 'items-end' : 'items-start'}`}
              >
                <div
                  className={`max-w-[85%] rounded-2xl px-3 py-2 leading-relaxed shadow-2xs ${
                    msg.sender === 'user'
                      ? 'bg-teal-700 text-white rounded-br-none'
                      : 'bg-white text-slate-800 border border-slate-200 rounded-bl-none'
                  }`}
                >
                  <p>{msg.text}</p>
                  {msg.sender === 'bot' && (
                    <div className="mt-1.5 flex items-center justify-between text-[10px] text-slate-400">
                      <span>{msg.time}</span>
                      <button
                        onClick={() => speakText(msg.text, currentLang)}
                        className="p-0.5 hover:text-teal-700 text-slate-400"
                        title="Listen"
                      >
                        <Volume2 className="w-3 h-3" />
                      </button>
                    </div>
                  )}
                </div>

                {/* Suggested Action Chips */}
                {msg.suggestedActions && msg.suggestedActions.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-2">
                    {msg.suggestedActions.map((act, i) => (
                      <button
                        key={i}
                        onClick={() => handleActionClick(act.action)}
                        className="px-2 py-1 bg-teal-50 hover:bg-teal-100 text-teal-900 border border-teal-200 rounded-lg text-[11px] font-semibold flex items-center gap-1 transition-colors"
                      >
                        <span>{act.label}</span>
                        <ExternalLink className="w-2.5 h-2.5 text-teal-600" />
                      </button>
                    ))}
                  </div>
                )}
              </div>
            ))}

            {loading && (
              <div className="flex items-center gap-2 text-slate-500 bg-white p-2 rounded-xl border border-slate-200 w-fit">
                <Loader2 className="w-3.5 h-3.5 animate-spin text-teal-600" />
                <span>Checking health database...</span>
              </div>
            )}
            <div ref={chatEndRef} />
          </div>

          {/* Quick Starter Chips */}
          <div className="px-2.5 py-1.5 bg-slate-100 border-t border-slate-200 flex gap-1.5 overflow-x-auto scrollbar-none">
            <button
              onClick={() => handleSend('Dengue precautions')}
              className="px-2 py-0.5 bg-white hover:bg-teal-50 text-slate-700 border border-slate-200 rounded-full text-[10px] whitespace-nowrap"
            >
              🦟 Dengue Care
            </button>
            <button
              onClick={() => handleSend('Temba Hospital OPD timings')}
              className="px-2 py-0.5 bg-white hover:bg-teal-50 text-slate-700 border border-slate-200 rounded-full text-[10px] whitespace-nowrap"
            >
              🏥 Temba OPD
            </button>
            <button
              onClick={() => handleSend('Free baby vaccine')}
              className="px-2 py-0.5 bg-white hover:bg-teal-50 text-slate-700 border border-slate-200 rounded-full text-[10px] whitespace-nowrap"
            >
              💉 Baby Vaccines
            </button>
          </div>

          {/* Input Box */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="p-2.5 bg-white border-t border-slate-200 flex gap-1.5"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask about symptoms, camps..."
              className="flex-1 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:outline-none focus:ring-1 focus:ring-teal-600 focus:bg-white"
            />
            <button
              type="submit"
              disabled={!input.trim() || loading}
              className="p-2 bg-teal-700 hover:bg-teal-800 disabled:opacity-50 text-white rounded-xl transition-colors"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>
      ) : (
        /* Floating Trigger Button */
        <button
          onClick={() => setIsOpen(true)}
          className="flex items-center gap-2 px-4 py-3 bg-linear-to-r from-teal-700 to-cyan-800 hover:from-teal-800 hover:to-cyan-900 text-white rounded-full shadow-xl hover:shadow-2xl border-2 border-white transition-all transform hover:scale-105 active:scale-95 group"
        >
          <div className="relative">
            <MessageSquare className="w-5 h-5" />
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 absolute -top-1 -right-1 ring-2 ring-white animate-pulse"></span>
          </div>
          <div className="text-left hidden sm:block">
            <span className="block text-xs font-extrabold leading-none">Ask Health Bot</span>
            <span className="text-[10px] text-teal-200 leading-none">24x7 MBMC Mitra</span>
          </div>
        </button>
      )}
    </div>
  );
};
