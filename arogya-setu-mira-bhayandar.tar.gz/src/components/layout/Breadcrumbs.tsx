import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { ChevronRight, Home, ArrowLeft } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

interface BreadcrumbsProps {
  title?: string;
  subtitle?: string;
}

export const Breadcrumbs: React.FC<BreadcrumbsProps> = ({ title, subtitle }) => {
  const location = useLocation();
  const { t } = useLanguage();

  if (location.pathname === '/') return null;

  const pathMap: Record<string, string> = {
    '/advisories': t('navAdvisories', 'Health Advisories & Alerts'),
    '/camps': t('navCamps', 'Vaccination & Health Camps'),
    '/hospitals': t('navHospitals', 'Nearby Municipal & Trust Hospitals'),
    '/translate': t('navTranslate', 'Multilingual Health Text Translator'),
    '/scan-medicine': t('navScanner', 'Medicine Strip & Label Scanner'),
    '/pharmacies': t('navPharmacies', 'Medicine Stock & Jan Aushadhi Finder'),
    '/chatbot': t('navChatbot', '24/7 Arogya Mitra Health Bot'),
    '/book-slot': t('navBookSlot', 'Book Camp / Hospital OPD Slot'),
    '/my-bookings': t('navMyBookings', 'My Health Bookings & Tokens'),
    '/profile': 'My Health Profile',
    '/about': 'About MBMC Health & Helplines',
    '/login': 'Resident / Admin Login',
    '/signup': 'Create Citizen Account',
    '/forgot-password': 'Password Assistance',
    '/admin': 'MBMC Health Administration Dashboard',
  };

  const currentTitle = title || pathMap[location.pathname] || 'Health Information';

  return (
    <div className="bg-gradient-to-r from-teal-800/10 via-cyan-700/5 to-transparent border-b border-slate-200 py-3.5 px-4 sm:px-6">
      <div className="max-w-7xl mx-auto flex flex-col sm:flex-row sm:items-center justify-between gap-2">
        {/* Trail */}
        <nav aria-label="Breadcrumb" className="flex items-center space-x-1 text-xs text-slate-500">
          <Link to="/" className="flex items-center gap-1 text-teal-800 hover:underline font-semibold">
            <Home className="w-3.5 h-3.5" />
            Home
          </Link>
          <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
          <span className="text-slate-800 font-bold truncate">{currentTitle}</span>
        </nav>

        {/* Page Identifier for elderly readability */}
        <div className="flex items-center gap-2">
          <span className="inline-block w-2 h-2 rounded-full bg-teal-600"></span>
          <span className="text-xs text-slate-600 font-medium">
            Mira Bhayandar Resident Portal • <strong className="text-slate-900">{currentTitle}</strong>
          </span>
        </div>
      </div>
    </div>
  );
};
