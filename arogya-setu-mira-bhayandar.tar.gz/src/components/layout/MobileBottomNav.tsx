import React from 'react';
import { NavLink } from 'react-router-dom';
import { Languages, Camera, MessageSquare, Calendar, MapPin } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export const MobileBottomNav: React.FC = () => {
  const { t } = useLanguage();

  const navItems = [
    {
      to: '/translate',
      label: t('navTranslate', 'Translate'),
      icon: Languages,
    },
    {
      to: '/scan-medicine',
      label: t('navScanner', 'Scan Strip'),
      icon: Camera,
      highlight: true,
    },
    {
      to: '/chatbot',
      label: t('navChatbot', 'Health Bot'),
      icon: MessageSquare,
    },
    {
      to: '/camps',
      label: t('navCamps', 'Camps'),
      icon: Calendar,
    },
    {
      to: '/hospitals',
      label: t('navHospitals', 'Hospitals'),
      icon: MapPin,
    },
  ];

  return (
    <div className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-slate-200 shadow-2xl py-1 px-2 no-print">
      <div className="flex items-center justify-around">
        {navItems.map((item) => {
          const Icon = item.icon;
          return (
            <NavLink
              key={item.to}
              to={item.to}
              className={({ isActive }) =>
                `flex flex-col items-center justify-center py-1 px-2 rounded-xl transition-all relative ${
                  isActive
                    ? 'text-teal-800 font-extrabold'
                    : 'text-slate-500 hover:text-slate-800 font-medium'
                }`
              }
            >
              {({ isActive }) => (
                <>
                  {item.highlight ? (
                    <div className="w-10 h-10 rounded-full bg-linear-to-r from-teal-700 to-emerald-700 text-white flex items-center justify-center -mt-4 shadow-md shadow-teal-700/30 border-2 border-white">
                      <Icon className="w-5 h-5" />
                    </div>
                  ) : (
                    <Icon className={`w-5 h-5 ${isActive ? 'text-teal-700 stroke-[2.5]' : 'text-slate-500'}`} />
                  )}
                  <span className={`text-[10px] mt-0.5 text-center leading-tight ${isActive ? 'font-bold text-teal-800' : ''}`}>
                    {item.label}
                  </span>
                  {isActive && !item.highlight && (
                    <span className="w-1 h-1 rounded-full bg-teal-700 absolute bottom-0.5"></span>
                  )}
                </>
              )}
            </NavLink>
          );
        })}
      </div>
    </div>
  );
};
