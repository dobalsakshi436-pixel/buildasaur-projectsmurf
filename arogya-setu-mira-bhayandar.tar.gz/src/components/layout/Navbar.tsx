import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import {
  Heart,
  Globe,
  Sliders,
  Sun,
  Moon,
  Volume2,
  VolumeX,
  Menu,
  X,
  User as UserIcon,
  LogOut,
  Calendar,
  Shield,
  Activity,
  PlusCircle,
  FileText,
  MapPin,
  Camera,
  Languages,
  MessageSquare,
  Search,
  Sparkles,
} from 'lucide-react';
import { useLanguage, ALL_LANGUAGES } from '../../context/LanguageContext';
import { useAccessibility } from '../../context/AccessibilityContext';
import { useAuth } from '../../context/AuthContext';

export const Navbar: React.FC = () => {
  const { currentLang, setLanguage, setIsModalOpen, t } = useLanguage();
  const {
    fontScale,
    increaseFont,
    decreaseFont,
    resetFont,
    highContrast,
    toggleHighContrast,
    isSpeaking,
    stopSpeaking,
    speakText,
  } = useAccessibility();
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const navLinks = [
    { to: '/', label: t('navHome', 'Home') },
    { to: '/advisories', label: t('navAdvisories', 'Health Alerts') },
    { to: '/camps', label: t('navCamps', 'Vaccination Camps') },
    { to: '/hospitals', label: t('navHospitals', 'Nearby Hospitals') },
    { to: '/scan-medicine', label: t('navScanner', 'Scan Medicine') },
    { to: '/translate', label: t('navTranslate', 'Translate') },
    { to: '/pharmacies', label: t('navPharmacies', 'Medicine Stock') },
    { to: '/chatbot', label: t('navChatbot', 'Health Bot') },
    { to: '/about', label: t('navAbout', 'Helplines') },
  ];

  const pinnedLangs = ALL_LANGUAGES.filter((l) => l.isPinned);

  const handleAudioAssistance = () => {
    if (isSpeaking) {
      stopSpeaking();
    } else {
      speakText(
        'Welcome to Arogya Setu Mira Bhayandar. Click any section to view health advisories, upcoming vaccination camps, or find nearby municipal hospitals in Bhayandar and Mira Road.',
        currentLang
      );
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-2xs">
      {/* Top Utility & Accessibility Bar */}
      <div className="bg-slate-900 text-slate-100 text-xs px-4 py-1.5 border-b border-slate-800">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          {/* Emergency Tag */}
          <div className="flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full bg-red-600/90 text-white font-bold tracking-wide">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></span>
              24x7 Emergency
            </span>
            <span className="text-slate-300 hidden sm:inline">
              MBMC Health Helpline: <strong className="text-teal-300">022-28112233</strong> • Ambulance: <strong className="text-amber-300">108</strong>
            </span>
          </div>

          {/* Accessibility & Quick Language Buttons */}
          <div className="flex items-center gap-3">
            {/* Audio Assistance */}
            <button
              onClick={handleAudioAssistance}
              className={`flex items-center gap-1 px-2 py-0.5 rounded transition-colors ${
                isSpeaking
                  ? 'bg-amber-500 text-slate-900 font-bold animate-pulse'
                  : 'bg-slate-800 hover:bg-slate-700 text-slate-200'
              }`}
              title="Audio speech guidance for elderly citizens"
            >
              {isSpeaking ? <VolumeX className="w-3.5 h-3.5" /> : <Volume2 className="w-3.5 h-3.5 text-teal-400" />}
              <span className="hidden md:inline">{isSpeaking ? 'Stop Voice' : 'Voice Guide'}</span>
            </button>

            {/* Font Resize (A- / A / A+) */}
            <div className="flex items-center bg-slate-800 rounded px-1.5 py-0.5 gap-1" title="Adjust text size for easier reading">
              <button
                onClick={decreaseFont}
                className={`px-1.5 py-0.5 rounded hover:bg-slate-700 ${
                  fontScale === 'normal' ? 'text-slate-500 cursor-not-allowed' : 'text-slate-200 font-bold'
                }`}
                disabled={fontScale === 'normal'}
                title="Smaller Font"
              >
                A-
              </button>
              <button
                onClick={resetFont}
                className={`px-1.5 py-0.5 rounded hover:bg-slate-700 ${
                  fontScale === 'normal' ? 'bg-teal-600 text-white font-bold' : 'text-slate-300'
                }`}
                title="Normal Font"
              >
                A
              </button>
              <button
                onClick={increaseFont}
                className={`px-1.5 py-0.5 rounded hover:bg-slate-700 ${
                  fontScale === 'xlarge' ? 'text-slate-500 cursor-not-allowed' : 'text-slate-200 font-bold'
                }`}
                disabled={fontScale === 'xlarge'}
                title="Larger Font (Elderly Friendly)"
              >
                A+
              </button>
            </div>

            {/* High Contrast Mode */}
            <button
              onClick={toggleHighContrast}
              className={`flex items-center gap-1 px-2 py-0.5 rounded transition-colors ${
                highContrast ? 'bg-yellow-400 text-slate-950 font-bold' : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
              }`}
              title="Toggle High Contrast Mode for visually impaired residents"
            >
              <Sun className="w-3.5 h-3.5" />
              <span className="hidden md:inline">{highContrast ? 'Normal Contrast' : 'High Contrast'}</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Navbar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="flex items-center justify-between h-16 sm:h-20">
          {/* Logo & Municipal Identity */}
          <Link to="/" className="flex items-center gap-3 group focus:outline-none">
            <div className="w-11 h-11 sm:w-13 sm:h-13 rounded-2xl bg-linear-to-br from-teal-600 to-cyan-800 flex items-center justify-center text-white shadow-md shadow-teal-700/20 group-hover:scale-105 transition-transform">
              <Heart className="w-6 h-6 sm:w-7 sm:h-7 text-emerald-300 fill-emerald-300/30" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-base sm:text-xl font-extrabold text-slate-900 tracking-tight leading-tight">
                  Arogya Setu
                </span>
                <span className="px-1.5 py-0.5 bg-teal-100 text-teal-800 text-[10px] sm:text-xs font-bold rounded-md">
                  MBMC
                </span>
              </div>
              <p className="text-xs text-slate-600 font-medium">
                Mira Bhayandar Public Health • <span className="text-teal-700 font-semibold">आरोग्य सेतू</span>
              </p>
            </div>
          </Link>

          {/* Desktop Language Switcher (Pinned + 100+ modal button) */}
          <div className="hidden lg:flex items-center bg-slate-100/90 p-1 rounded-xl border border-slate-200/80">
            {pinnedLangs.map((lang) => {
              const isSelected = currentLang === lang.code;
              return (
                <button
                  key={lang.code}
                  onClick={() => setLanguage(lang.code)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                    isSelected
                      ? 'bg-teal-700 text-white shadow-xs'
                      : 'text-slate-700 hover:text-teal-800 hover:bg-white/80'
                  }`}
                >
                  {lang.native}
                </button>
              );
            })}
            <button
              onClick={() => setIsModalOpen(true)}
              className="flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-medium text-teal-800 hover:bg-teal-50 transition-colors ml-1 border-l border-slate-200"
              title="Select from 100+ world languages"
            >
              <Globe className="w-3.5 h-3.5 text-teal-600" />
              <span>More (100+)</span>
            </button>
          </div>

          {/* Right Action Buttons */}
          <div className="hidden md:flex items-center gap-3">
            <Link
              to="/book-slot"
              className="flex items-center gap-1.5 px-4 py-2 bg-linear-to-r from-teal-700 to-emerald-700 hover:from-teal-800 hover:to-emerald-800 text-white font-bold text-sm rounded-xl shadow-sm hover:shadow-md transition-all active:scale-98"
            >
              <PlusCircle className="w-4 h-4 text-emerald-200" />
              {t('navBookSlot', 'Book a Slot')}
            </Link>

            {/* Auth Profile / Login Menu */}
            {user ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                  className="flex items-center gap-2 p-1.5 pr-3 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-sm font-semibold transition-colors border border-slate-200"
                >
                  <div className="w-8 h-8 rounded-lg bg-teal-700 text-white flex items-center justify-center font-bold text-xs">
                    {user.name.charAt(0).toUpperCase()}
                  </div>
                  <div className="text-left leading-tight hidden lg:block">
                    <span className="block text-xs font-bold text-slate-900 truncate max-w-28">{user.name}</span>
                    <span className="text-[10px] text-teal-700 font-medium capitalize">{user.role}</span>
                  </div>
                </button>

                {userDropdownOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-2xl shadow-xl border border-slate-200 py-2 z-50 animate-in fade-in zoom-in-95">
                    <div className="px-4 py-2 border-b border-slate-100">
                      <p className="text-xs text-slate-500 font-medium">Signed in as</p>
                      <p className="text-sm font-bold text-slate-800 truncate">{user.name}</p>
                      <p className="text-xs text-slate-500">{user.locality}</p>
                    </div>

                    <Link
                      to="/my-bookings"
                      onClick={() => setUserDropdownOpen(false)}
                      className="flex items-center gap-2.5 px-4 py-2.5 text-sm text-slate-700 hover:bg-teal-50 hover:text-teal-900 font-medium transition-colors"
                    >
                      <Calendar className="w-4 h-4 text-teal-700" />
                      My Health Bookings
                    </Link>

                    <Link
                      to="/profile"
                      onClick={() => setUserDropdownOpen(false)}
                      className="flex items-center gap-2.5 px-4 py-2.5 text-sm text-slate-700 hover:bg-teal-50 hover:text-teal-900 font-medium transition-colors"
                    >
                      <UserIcon className="w-4 h-4 text-teal-700" />
                      My Profile & Health ID
                    </Link>

                    {user.role === 'admin' && (
                      <Link
                        to="/admin"
                        onClick={() => setUserDropdownOpen(false)}
                        className="flex items-center gap-2.5 px-4 py-2.5 text-sm text-amber-900 bg-amber-50/70 hover:bg-amber-100/70 font-semibold transition-colors border-y border-amber-100"
                      >
                        <Shield className="w-4 h-4 text-amber-700" />
                        Admin Dashboard
                      </Link>
                    )}

                    <button
                      onClick={() => {
                        setUserDropdownOpen(false);
                        logout();
                        navigate('/');
                      }}
                      className="w-full flex items-center gap-2.5 px-4 py-2.5 text-sm text-red-600 hover:bg-red-50 font-medium transition-colors text-left"
                    >
                      <LogOut className="w-4 h-4 text-red-500" />
                      Log Out
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <Link
                to="/login"
                className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 font-bold text-sm rounded-xl border border-slate-200 transition-colors"
              >
                <UserIcon className="w-4 h-4 text-slate-600" />
                {t('navLogin', 'Login / Sign Up')}
              </Link>
            )}
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center gap-2 md:hidden">
            <button
              onClick={() => setIsModalOpen(true)}
              className="p-2 rounded-xl bg-teal-50 text-teal-800 border border-teal-200"
              title="Languages"
            >
              <Globe className="w-5 h-5" />
            </button>
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 rounded-xl bg-slate-100 text-slate-700 hover:bg-slate-200"
              aria-label="Toggle navigation menu"
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Desktop Navigation Links Bar */}
      <nav className="hidden md:block bg-teal-900 text-teal-50 px-4 border-t border-teal-800/60 shadow-xs">
        <div className="max-w-7xl mx-auto flex items-center justify-between overflow-x-auto scrollbar-none py-1">
          <div className="flex items-center space-x-1 sm:space-x-2">
            {navLinks.map((link) => {
              const isActive = location.pathname === link.to;
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  className={`px-3 py-2 rounded-lg text-sm font-semibold whitespace-nowrap transition-colors ${
                    isActive
                      ? 'bg-teal-700 text-white shadow-xs'
                      : 'text-teal-100 hover:bg-teal-800/80 hover:text-white'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
          </div>

          {user?.role === 'admin' && (
            <Link
              to="/admin"
              className="flex items-center gap-1 px-3 py-1 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold text-xs rounded-lg transition-colors shadow-xs"
            >
              <Shield className="w-3.5 h-3.5" />
              Admin Portal
            </Link>
          )}
        </div>
      </nav>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-slate-200 px-4 pt-3 pb-6 space-y-3 shadow-xl animate-in slide-in-from-top-4 duration-200">
          {/* Language Selection Bar inside Mobile Menu */}
          <div className="p-3 bg-teal-50 rounded-xl border border-teal-100">
            <p className="text-xs font-bold text-teal-900 mb-2">Select Language / भाषा:</p>
            <div className="grid grid-cols-2 gap-2">
              {pinnedLangs.map((lang) => (
                <button
                  key={lang.code}
                  onClick={() => {
                    setLanguage(lang.code);
                    setMobileMenuOpen(false);
                  }}
                  className={`p-2 rounded-lg text-xs font-bold text-left transition-colors ${
                    currentLang === lang.code
                      ? 'bg-teal-700 text-white'
                      : 'bg-white text-slate-800 border border-teal-200'
                  }`}
                >
                  {lang.native} ({lang.name})
                </button>
              ))}
            </div>
            <button
              onClick={() => {
                setMobileMenuOpen(false);
                setIsModalOpen(true);
              }}
              className="mt-2 w-full py-1.5 bg-teal-800 text-white text-xs font-bold rounded-lg flex items-center justify-center gap-1"
            >
              <Globe className="w-3.5 h-3.5" />
              Explore All 100+ Languages
            </button>
          </div>

          {/* Links list */}
          <div className="space-y-1">
            {navLinks.map((link) => {
              const isActive = location.pathname === link.to;
              return (
                <Link
                  key={link.to}
                  to={link.to}
                  onClick={() => setMobileMenuOpen(false)}
                  className={`block px-4 py-2.5 rounded-xl text-base font-semibold transition-colors ${
                    isActive ? 'bg-teal-700 text-white' : 'text-slate-800 hover:bg-slate-100'
                  }`}
                >
                  {link.label}
                </Link>
              );
            })}
            <Link
              to="/book-slot"
              onClick={() => setMobileMenuOpen(false)}
              className="block px-4 py-2.5 bg-emerald-600 text-white rounded-xl text-base font-bold text-center shadow-xs"
            >
              {t('navBookSlot', 'Book a Slot')}
            </Link>
          </div>

          {/* User Auth Section Mobile */}
          <div className="pt-3 border-t border-slate-200">
            {user ? (
              <div className="space-y-2">
                <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-xl">
                  <div className="w-10 h-10 rounded-full bg-teal-700 text-white flex items-center justify-center font-bold">
                    {user.name.charAt(0)}
                  </div>
                  <div>
                    <p className="font-bold text-slate-900">{user.name}</p>
                    <p className="text-xs text-slate-500">{user.locality} • {user.role}</p>
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-2">
                  <Link
                    to="/my-bookings"
                    onClick={() => setMobileMenuOpen(false)}
                    className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold text-center"
                  >
                    My Bookings
                  </Link>
                  <Link
                    to="/profile"
                    onClick={() => setMobileMenuOpen(false)}
                    className="p-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-bold text-center"
                  >
                    My Profile
                  </Link>
                </div>
                {user.role === 'admin' && (
                  <Link
                    to="/admin"
                    onClick={() => setMobileMenuOpen(false)}
                    className="block p-2.5 bg-amber-100 text-amber-900 rounded-xl text-xs font-bold text-center"
                  >
                    Admin Dashboard
                  </Link>
                )}
                <button
                  onClick={() => {
                    setMobileMenuOpen(false);
                    logout();
                    navigate('/');
                  }}
                  className="w-full p-2.5 bg-red-50 text-red-700 hover:bg-red-100 rounded-xl text-xs font-bold text-center"
                >
                  Log Out
                </button>
              </div>
            ) : (
              <Link
                to="/login"
                onClick={() => setMobileMenuOpen(false)}
                className="block w-full py-3 bg-slate-800 hover:bg-slate-900 text-white rounded-xl text-center font-bold"
              >
                {t('navLogin', 'Login / Sign Up')}
              </Link>
            )}
          </div>
        </div>
      )}
    </header>
  );
};
