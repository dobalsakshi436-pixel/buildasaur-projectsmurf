import React from 'react';
import { Link } from 'react-router-dom';
import { Heart, Phone, MapPin, Shield, LifeBuoy, Clock, ExternalLink, Activity } from 'lucide-react';
import { useLanguage } from '../../context/LanguageContext';

export const Footer: React.FC = () => {
  const { t } = useLanguage();

  return (
    <footer className="bg-slate-900 text-slate-300 pt-12 pb-24 md:pb-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 pb-10 border-b border-slate-800">
          {/* Identity & Mission */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-10 h-10 rounded-xl bg-teal-600 flex items-center justify-center text-white shadow-sm">
                <Heart className="w-6 h-6 text-emerald-200 fill-emerald-200/20" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white leading-tight">Arogya Setu</h3>
                <p className="text-xs text-teal-400 font-semibold">Mira Bhayandar Municipal Corp</p>
              </div>
            </div>
            <p className="text-sm text-slate-400 leading-relaxed">
              Dedicated community health portal for elderly citizens, women, and low-income families in Mira Bhayandar. Access plain-language advisories, vaccination camps, and nearby hospitals in your mother tongue.
            </p>
            <div className="p-3 bg-slate-800/80 rounded-xl border border-slate-700/60 text-xs space-y-1">
              <p className="font-semibold text-white flex items-center gap-1.5">
                <Shield className="w-3.5 h-3.5 text-teal-400" />
                MBMC Public Health Cell
              </p>
              <p className="text-slate-400">Head Office: Indira Gandhi Bhavan, Chhatrapati Shivaji Maharaj Marg, Bhayandar West 401101</p>
            </div>
          </div>

          {/* Quick Helpline Numbers */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
              <Phone className="w-4 h-4 text-emerald-400" />
              Emergency Helplines
            </h4>
            <ul className="space-y-2 text-sm">
              <li className="p-2.5 bg-slate-800/60 rounded-xl border border-slate-700/50 flex items-center justify-between">
                <div>
                  <span className="text-slate-400 text-xs block">National Ambulance</span>
                  <span className="font-bold text-white">108 (Toll Free)</span>
                </div>
                <a href="tel:108" className="px-2.5 py-1 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-lg transition-colors">
                  Call 108
                </a>
              </li>

              <li className="p-2.5 bg-slate-800/60 rounded-xl border border-slate-700/50 flex items-center justify-between">
                <div>
                  <span className="text-slate-400 text-xs block">MBMC Health Control Room</span>
                  <span className="font-bold text-white">022-28112233</span>
                </div>
                <a href="tel:02228112233" className="px-2.5 py-1 bg-teal-600 hover:bg-teal-700 text-white font-bold text-xs rounded-lg transition-colors">
                  Call
                </a>
              </li>

              <li className="p-2.5 bg-slate-800/60 rounded-xl border border-slate-700/50 flex items-center justify-between">
                <div>
                  <span className="text-slate-400 text-xs block">Senior Citizen Elderline</span>
                  <span className="font-bold text-white">14567</span>
                </div>
                <a href="tel:14567" className="px-2.5 py-1 bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs rounded-lg transition-colors">
                  Call
                </a>
              </li>

              <li className="p-2.5 bg-slate-800/60 rounded-xl border border-slate-700/50 flex items-center justify-between">
                <div>
                  <span className="text-slate-400 text-xs block">Women Helpline</span>
                  <span className="font-bold text-white">1091 / 181</span>
                </div>
                <a href="tel:1091" className="px-2.5 py-1 bg-slate-700 hover:bg-slate-600 text-white font-bold text-xs rounded-lg transition-colors">
                  Call
                </a>
              </li>
            </ul>
          </div>

          {/* Localities & Ward Coverage */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
              <MapPin className="w-4 h-4 text-cyan-400" />
              Ward Health Posts
            </h4>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2 bg-slate-800/50 rounded-lg border border-slate-700/40">
                <span className="font-semibold text-slate-200 block">Ward 1 (Bhayandar W)</span>
                <span className="text-slate-400">Temba Hospital Post</span>
              </div>
              <div className="p-2 bg-slate-800/50 rounded-lg border border-slate-700/40">
                <span className="font-semibold text-slate-200 block">Ward 2 (Bhayandar E)</span>
                <span className="text-slate-400">Jesal Park Health Post</span>
              </div>
              <div className="p-2 bg-slate-800/50 rounded-lg border border-slate-700/40">
                <span className="font-semibold text-slate-200 block">Ward 3 (Naya Nagar)</span>
                <span className="text-slate-400">UPHC Maternity Home</span>
              </div>
              <div className="p-2 bg-slate-800/50 rounded-lg border border-slate-700/40">
                <span className="font-semibold text-slate-200 block">Ward 4 (Shanti Nagar)</span>
                <span className="text-slate-400">Indira Gandhi Civil Post</span>
              </div>
              <div className="p-2 bg-slate-800/50 rounded-lg border border-slate-700/40">
                <span className="font-semibold text-slate-200 block">Ward 5 (Kashimira)</span>
                <span className="text-slate-400">Trauma & Anti-Rabies</span>
              </div>
              <div className="p-2 bg-slate-800/50 rounded-lg border border-slate-700/40">
                <span className="font-semibold text-slate-200 block">Ward 6 (Uttan Coastal)</span>
                <span className="text-slate-400">Rural Seacoast Clinic</span>
              </div>
            </div>
          </div>

          {/* Quick Links & Feedback */}
          <div className="space-y-3">
            <h4 className="text-sm font-bold uppercase tracking-wider text-white flex items-center gap-2">
              <LifeBuoy className="w-4 h-4 text-amber-400" />
              Citizen Services
            </h4>
            <ul className="space-y-2 text-sm text-slate-300">
              <li>
                <Link to="/camps" className="hover:text-teal-300 transition-colors flex items-center gap-1.5">
                  • Book Free Vaccination Slot
                </Link>
              </li>
              <li>
                <Link to="/scan-medicine" className="hover:text-teal-300 transition-colors flex items-center gap-1.5">
                  • Scan Medicine Strip / Box
                </Link>
              </li>
              <li>
                <Link to="/translate" className="hover:text-teal-300 transition-colors flex items-center gap-1.5">
                  • Multilingual Health Translator
                </Link>
              </li>
              <li>
                <Link to="/pharmacies" className="hover:text-teal-300 transition-colors flex items-center gap-1.5">
                  • Find Jan Aushadhi & Chemist Stock
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-teal-300 transition-colors flex items-center gap-1.5">
                  • Send Feedback / Grievance to MBMC
                </Link>
              </li>
              <li>
                <Link to="/login" className="hover:text-teal-300 transition-colors flex items-center gap-1.5">
                  • Resident Login & Profile
                </Link>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom copyright & disclaimer */}
        <div className="pt-6 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p>
            © {new Date().getFullYear()} Arogya Setu Mira Bhayandar • Public Health & Sanitation Department, Mira Bhayandar Municipal Corporation.
          </p>
          <p className="text-slate-400 text-center md:text-right">
            Medical Disclaimer: Health information provided on this platform is for public community guidance. In severe medical emergencies, immediately consult a registered doctor or call 108.
          </p>
        </div>
      </div>
    </footer>
  );
};
