import React, { useState, useMemo } from 'react';
import { Search, X, Globe, Check, Sparkles } from 'lucide-react';
import { useLanguage } from '../context/LanguageContext';

export const LanguageModal: React.FC = () => {
  const { isModalOpen, setIsModalOpen, currentLang, setLanguage, allLanguages } = useLanguage();
  const [searchQuery, setSearchQuery] = useState('');

  const pinnedLanguages = useMemo(() => {
    return allLanguages.filter((l) => l.isPinned);
  }, [allLanguages]);

  const filteredLanguages = useMemo(() => {
    if (!searchQuery.trim()) return allLanguages;
    const q = searchQuery.toLowerCase().trim();
    return allLanguages.filter(
      (l) =>
        l.name.toLowerCase().includes(q) ||
        l.native.toLowerCase().includes(q) ||
        l.code.toLowerCase().includes(q)
    );
  }, [allLanguages, searchQuery]);

  if (!isModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden border border-slate-200">
        {/* Modal Header */}
        <div className="p-4 sm:p-6 bg-linear-to-r from-teal-700 to-cyan-800 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-white/15 flex items-center justify-center">
              <Globe className="w-6 h-6 text-teal-100" />
            </div>
            <div>
              <h2 className="text-xl font-bold">Choose Your Language / भाषा निवडा</h2>
              <p className="text-xs text-teal-100/90">
                100+ Languages Supported • Supported for entire website
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsModalOpen(false)}
            className="p-2 rounded-lg bg-white/10 hover:bg-white/20 text-white transition-colors"
            aria-label="Close language selector"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Pinned Quick Selection */}
        <div className="p-4 bg-teal-50/70 border-b border-teal-100">
          <p className="text-xs font-semibold text-teal-900 mb-2 flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-teal-600" />
            Mira Bhayandar Primary Languages (प्राथमिक स्थानिक भाषा):
          </p>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {pinnedLanguages.map((lang) => {
              const isSelected = currentLang === lang.code;
              return (
                <button
                  key={lang.code}
                  onClick={() => {
                    setLanguage(lang.code);
                    setIsModalOpen(false);
                  }}
                  className={`p-2.5 rounded-xl text-left font-medium text-sm flex items-center justify-between transition-all ${
                    isSelected
                      ? 'bg-teal-700 text-white shadow-sm ring-2 ring-teal-600 ring-offset-1'
                      : 'bg-white text-slate-800 border border-teal-200 hover:border-teal-400 hover:bg-teal-50'
                  }`}
                >
                  <div>
                    <span className="block font-bold text-base leading-tight">{lang.native}</span>
                    <span className={`text-xs ${isSelected ? 'text-teal-100' : 'text-slate-500'}`}>
                      {lang.name}
                    </span>
                  </div>
                  {isSelected && <Check className="w-4 h-4 text-white" />}
                </button>
              );
            })}
          </div>
        </div>

        {/* Search Input */}
        <div className="p-4 border-b border-slate-100">
          <div className="relative">
            <Search className="w-5 h-5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by language name (e.g. Urdu, Bengali, Tamil, Spanish...)"
              className="w-full pl-10 pr-4 py-2.5 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-teal-600 focus:bg-white transition-all"
            />
          </div>
        </div>

        {/* Language Grid */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 max-h-96 divide-y divide-slate-100">
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
            {filteredLanguages.map((lang) => {
              const isSelected = currentLang === lang.code;
              return (
                <button
                  key={lang.code}
                  onClick={() => {
                    setLanguage(lang.code);
                    setIsModalOpen(false);
                  }}
                  className={`p-3 rounded-xl text-left flex items-center justify-between transition-all text-sm ${
                    isSelected
                      ? 'bg-teal-700 text-white font-semibold shadow-xs'
                      : 'bg-slate-50/70 hover:bg-teal-50/50 text-slate-700 border border-transparent hover:border-teal-200'
                  }`}
                >
                  <div className="truncate pr-2">
                    <span className="font-semibold block truncate">{lang.native}</span>
                    <span className={`text-xs ${isSelected ? 'text-teal-100' : 'text-slate-500'}`}>
                      {lang.name}
                    </span>
                  </div>
                  {isSelected && <Check className="w-4 h-4 text-white shrink-0" />}
                </button>
              );
            })}
          </div>

          {filteredLanguages.length === 0 && (
            <div className="py-8 text-center text-slate-500 text-sm">
              No language found matching "{searchQuery}".
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-3 sm:p-4 bg-slate-50 border-t border-slate-200 flex justify-between items-center text-xs text-slate-600">
          <span>Active: <strong className="text-teal-700">{allLanguages.find(l => l.code === currentLang)?.name} ({currentLang.toUpperCase()})</strong></span>
          <button
            onClick={() => setIsModalOpen(false)}
            className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 text-slate-800 rounded-lg font-medium transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
