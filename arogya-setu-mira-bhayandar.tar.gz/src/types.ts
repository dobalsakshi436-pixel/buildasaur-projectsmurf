export interface User {
  id: string;
  name: string;
  emailOrPhone: string;
  role: 'resident' | 'admin';
  preferredLanguage: string;
  locality: string;
  age?: number;
  gender?: string;
  emergencyContact?: string;
  createdAt: string;
}

export interface HealthAdvisory {
  id: string;
  title: string;
  titleHi?: string;
  titleMr?: string;
  titleGu?: string;
  locality: string;
  category: 'outbreak' | 'monsoon' | 'vaccination' | 'maternal' | 'elderly' | 'general';
  severity: 'urgent' | 'warning' | 'info';
  date: string;
  medicalText: string;
  simpleText: string;
  simpleTextHi?: string;
  simpleTextMr?: string;
  simpleTextGu?: string;
  symptoms: string[];
  precautions: string[];
  actionHelpline: string;
}

export interface VaccinationCamp {
  id: string;
  name: string;
  locality: string;
  address: string;
  landmark: string;
  date: string;
  timeRange: string;
  targetGroup: 'all' | 'elderly' | 'children' | 'pregnant_women';
  vaccinesOffered: string[];
  totalSlots: number;
  availableSlots: number;
  contactNumber: string;
  googleMapsUrl: string;
  status: 'upcoming' | 'ongoing' | 'completed';
}

export interface HospitalAppointmentSlot {
  slotId: string;
  time: string;
  date: string;
  doctorName: string;
  specialty: string;
  isAvailable: boolean;
}

export interface Hospital {
  id: string;
  name: string;
  type: 'Municipal Hospital (MBMC)' | 'Community Health Center' | 'Maternity Home' | 'Trust Hospital' | 'Private Hospital';
  locality: string;
  address: string;
  landmark: string;
  latitude: number;
  longitude: number;
  contactNumber: string;
  emergencyNumber: string;
  specialties: string[];
  facilities: string[];
  opdTimings: string;
  isFreeGovt: boolean;
  appointmentSlots: HospitalAppointmentSlot[];
}

export interface MedicineStockItem {
  medicineId: string;
  name: string;
  genericName: string;
  category: string;
  status: 'In Stock' | 'Low Stock' | 'Out of Stock';
  price: string;
  discountGovt?: string;
}

export interface Pharmacy {
  id: string;
  name: string;
  locality: string;
  address: string;
  contactNumber: string;
  timings: string;
  is24Hours: boolean;
  hasJanAushadhiScheme: boolean;
  distanceKm: number;
  inventory: MedicineStockItem[];
  matchingItems?: MedicineStockItem[];
}

export interface MedicineInfo {
  detectedMedicineName?: string;
  name?: string;
  genericName?: string;
  category?: string;
  simplePurpose: string;
  dosageNotes: string;
  commonSideEffects: string[];
  precautions: string[];
  requiresDoctorPrescription: boolean;
  warningDisclaimer: string;
  disclaimer?: string;
}

export interface Booking {
  id: string;
  tokenNumber: string;
  type: 'camp' | 'hospital';
  targetId: string;
  targetName: string;
  slotDate: string;
  slotTime: string;
  specialtyOrVaccine?: string;
  doctorName?: string;
  userName: string;
  userPhone: string;
  userEmail?: string;
  userAge: number;
  userGender: string;
  userLocality: string;
  userId?: string;
  status: 'confirmed' | 'attended' | 'cancelled' | 'no_show';
  createdAt: string;
}

export interface Feedback {
  id: string;
  name: string;
  phoneOrEmail: string;
  locality: string;
  category: 'camps' | 'hospitals' | 'medicine_availability' | 'translation' | 'general';
  rating: number;
  message: string;
  createdAt: string;
}

export interface Language {
  code: string;
  name: string;
  native: string;
  isPinned?: boolean;
}
