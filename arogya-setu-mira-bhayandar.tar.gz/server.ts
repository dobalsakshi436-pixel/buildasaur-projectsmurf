import express from 'express';
import path from 'path';
import cookieParser from 'cookie-parser';
import { createServer as createViteServer } from 'vite';
import { verifyAuthToken } from './server/auth';
import authRoutes from './server/routes/auth';
import advisoryRoutes from './server/routes/advisories';
import campRoutes from './server/routes/camps';
import bookingRoutes from './server/routes/bookings';
import hospitalRoutes from './server/routes/hospitals';
import pharmacyRoutes from './server/routes/pharmacies';
import translateRoutes from './server/routes/translate';
import scanMedicineRoutes from './server/routes/scanMedicine';
import chatbotRoutes from './server/routes/chatbot';
import feedbackRoutes from './server/routes/feedback';
import adminRoutes from './server/routes/admin';

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Middlewares
  app.use(express.json({ limit: '15mb' }));
  app.use(express.urlencoded({ extended: true, limit: '15mb' }));
  app.use(cookieParser());
  app.use(verifyAuthToken);

  // Health check endpoint
  app.get('/api/health', (req, res) => {
    res.json({
      status: 'ok',
      service: 'Arogya Setu Mira Bhayandar API',
      timestamp: new Date().toISOString(),
    });
  });

  // REST API Routes
  app.use('/api/auth', authRoutes);
  app.use('/api/advisories', advisoryRoutes);
  app.use('/api/camps', campRoutes);
  app.use('/api/bookings', bookingRoutes);
  app.use('/api/hospitals', hospitalRoutes);
  app.use('/api/pharmacies', pharmacyRoutes);
  app.use('/api/translate', translateRoutes);
  app.use('/api/scan-medicine', scanMedicineRoutes);
  app.use('/api/chatbot', chatbotRoutes);
  app.use('/api/feedback', feedbackRoutes);
  app.use('/api/admin', adminRoutes);

  // Vite middleware in dev, static files in production
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`[Arogya Setu Mira Bhayandar] Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
